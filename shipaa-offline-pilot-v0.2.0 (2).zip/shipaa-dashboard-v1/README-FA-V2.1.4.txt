SHIPAA Dashboard 2.1.4 — first-frame mobile geometry hotfix.
Based on v2.1.3. Adds critical inline mobile layout in wp_head, removes 100vw breakout, removes delayed host-fit recalculation. Watch-progress and admin improvements retained. This is a hypothesized mitigation pending real-device verification.
