SHIPAA Dashboard v2.0.2 — one-click update. See README-FA-V2.txt.
