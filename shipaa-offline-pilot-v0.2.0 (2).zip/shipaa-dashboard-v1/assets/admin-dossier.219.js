(function(){'use strict';
function init(root){
 if(root.dataset.kind!=='admin' || root.dataset.sd13Ready==='1')return;root.dataset.sd13Ready='1';
 const layer=root.querySelector('[data-drawer]'),shell=root.querySelector('[data-drawer-shell]'),content=root.querySelector('[data-drawer-content]');
 if(!layer||!shell||!content)return;
 let uid=0,lastFocus=null,detailSeq=0,searchSeq=0,activeTab='overview',busy=false;
 const notify=msg=>{const toast=root.querySelector('.sv-toast');if(toast){toast.textContent=msg;toast.hidden=false;setTimeout(()=>{toast.hidden=true;},4500)} };
 async function api(action,data){
  if(!window.SHIPAA_V1||!SHIPAA_V1.ajax||!SHIPAA_V1.nonce)throw Error('ارتباط پنل مدیریت آماده نیست؛ صفحه را دوباره بارگذاری کنید.');
  const payload=new URLSearchParams({action:'shipaa_v1_'+action,nonce:SHIPAA_V1.nonce});
  Object.entries(data||{}).forEach(([key,val])=>payload.set(key,String(val)));
  const response=await fetch(SHIPAA_V1.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:payload.toString()});
  let json;try{json=await response.json()}catch(e){throw Error('پاسخ سرور معتبر نیست. دوباره تلاش کنید.')}
  if(!response.ok||!json.success)throw Error(json?.data?.message||'در ارتباط با سرور خطایی رخ داد.');return json.data;
 }
 function tabs(name){
  activeTab=name;
  content.querySelectorAll('[data-dossier-view]').forEach(el=>{el.hidden=el.dataset.dossierView!==name});
  content.querySelectorAll('[data-dossier-tab]').forEach(el=>{const selected=el.dataset.dossierTab===name;el.setAttribute('aria-selected',selected?'true':'false');el.tabIndex=selected?0:-1});
 }
 function swap(html,tab){content.innerHTML=html;tabs(tab||activeTab);shell.scrollTop=0;}
 function lockScroll(on){document.documentElement.classList.toggle('sd13-modal-open',on);}
 function close(){if(busy)return;detailSeq++;layer.hidden=true;uid=0;lockScroll(false);if(lastFocus&&lastFocus.isConnected)lastFocus.focus();}
 async function refresh(tab){const seq=++detailSeq;const data=await api('dossier',{user_id:uid});if(seq!==detailSeq||layer.hidden)return;swap(data.html,tab);return data;}
 async function open(personId,trigger){
  uid=Number(personId);if(!uid)return;
  activeTab='overview';lastFocus=trigger||document.activeElement;layer.hidden=false;lockScroll(true);
  content.innerHTML='<div class="sd13-loading" role="status">در حال دریافت پرونده مخاطب…</div>';shell.focus();
  try{await refresh('overview')}catch(err){content.innerHTML='<div class="sd13-error" role="alert"></div>';content.firstElementChild.textContent=err.message;}
 }
 const TEXT={
  approve:{t:'تأیید نهایی رسید',c:'رسید و مبلغ را مستقلاً در ایتا و سوابق بانکی بررسی کرده‌ام.',ok:'تأیید و باز کردن دوره'},
  revise:{t:'درخواست اصلاح رسید',ok:'ثبت درخواست اصلاح'},
  revoke:{t:'لغو دسترسی دوره',c:'می‌دانم سفارش‌های تکمیل‌شده این دوره برای این مخاطب «لغو» می‌شوند.',ok:'لغو دسترسی'},
  grant:{t:'اعطای دسترسی مستقیم',ok:'باز کردن دوره'}
 };
 function confirmAction(id,mode,label){
  const modal=layer.querySelector('[data-dossier-confirm]');if(!modal)return;
  let name=label||'';
  if(mode==='approve'||mode==='revise'){const order=content.querySelector('[data-dossier-order="'+id+'"]');if(!order)return;name=order.querySelector('.sd13-order-head strong')?.textContent||('سفارش #'+id);}
  modal.dataset.mode=mode;modal.dataset.targetId=id;
  const tx=TEXT[mode];modal.querySelector('[data-confirm-title]').textContent=tx.t;
  const desc={approve:name+' — سفارش در ووکامرس تکمیل می‌شود و دسترسی دوره در استادیار و پلیر شیپا همان لحظه باز و راستی‌آزمایی می‌شود.',
   revise:name+' — دلیل را بنویسید؛ سفارش معلق می‌ماند و مخاطب «نیاز به اصلاح رسید» را می‌بیند.',
   revoke:'«'+name+'» — دسترسی این مخاطب در استادیار، ووکامرس و پلیر شیپا بسته می‌شود.',
   grant:'«'+name+'» — یک سفارش صفرتومانی تکمیل‌شده با برچسب «دسترسی دستی» ساخته می‌شود و دوره بلافاصله برای مخاطب باز می‌شود.'}[mode];
  modal.querySelector('[data-confirm-desc]').textContent=desc;
  const needCheck=mode==='approve'||mode==='revoke';
  modal.querySelector('[data-confirm-check-wrap]').hidden=!needCheck;
  const ct=modal.querySelector('[data-confirm-check-text]');if(ct&&tx.c)ct.textContent=tx.c;
  modal.querySelector('[data-confirm-note-wrap]').hidden=mode!=='revise';
  const shw=modal.querySelector('[data-confirm-share-wrap]');if(shw){shw.hidden=mode!=='revise';shw.querySelector('input').checked=true;}
  modal.querySelector('[data-confirm-check]').checked=false;modal.querySelector('[data-confirm-note]').value='';
  const sub=modal.querySelector('[data-confirm-submit]');sub.textContent=tx.ok;sub.classList.toggle('is-danger',mode==='revoke');
  modal.hidden=false;
  (modal.querySelector(needCheck?'[data-confirm-check]':mode==='revise'?'[data-confirm-note]':'[data-confirm-submit]')).focus();
 }
 function closeConfirm(){const modal=layer.querySelector('[data-dossier-confirm]');if(modal&&!busy)modal.hidden=true;}
 async function commit(){
  const modal=layer.querySelector('[data-dossier-confirm]');if(!modal||busy)return;
  const id=Number(modal.dataset.targetId),mode=modal.dataset.mode;
  if((mode==='approve'||mode==='revoke')&&!modal.querySelector('[data-confirm-check]').checked){notify('ابتدا کادر تأیید را علامت بزنید.');return;}
  const note=modal.querySelector('[data-confirm-note]').value.trim();
  if(mode==='revise'&&note.length<4){notify('دلیل اصلاح را دست‌کم با ۴ نویسه بنویسید.');return;}
  busy=true;const b=modal.querySelector('[data-confirm-submit]');b.disabled=true;
  try{
   let data;
   if(mode==='approve')data=await api('approve',{order_id:id,confirmed:'yes'});
   else if(mode==='revise')data=await api('request_changes',{order_id:id,note,share:modal.querySelector('[data-confirm-share]')?.checked?'yes':'no'});
   else if(mode==='grant')data=await api('grant_access',{user_id:uid,course:id});
   else data=await api('revoke_access',{user_id:uid,course:id,confirmed:'yes'});
   modal.hidden=true;
   if(mode==='approve')root.querySelectorAll('.sv-request[data-order-id="'+id+'"]').forEach(el=>{el.classList.add('is-leaving');setTimeout(()=>el.remove(),420);});
   if(data&&data.html)swap(data.html,'courses');else await refresh(mode==='approve'?'courses':'orders');
   notify(data.message||'تغییرات ثبت شد.');
  }catch(err){notify(err.message)}finally{busy=false;b.disabled=false;}
 }
 root.addEventListener('click',async evt=>{
  const b=evt.target.closest('button');if(!b||!root.contains(b))return;
  if(b.hasAttribute('data-person-id')){evt.preventDefault();await open(b.dataset.personId,b);return;}
  if(b.hasAttribute('data-close-drawer')){evt.preventDefault();close();return;}
  if(b.hasAttribute('data-dossier-tab')){tabs(b.dataset.dossierTab);return;}
  if(b.hasAttribute('data-dossier-open-order')){tabs('orders');const target=content.querySelector('[data-dossier-order="'+b.dataset.dossierOpenOrder+'"]');if(target)target.scrollIntoView({block:'center',behavior:'smooth'});return;}
  if(b.hasAttribute('data-dossier-edit')){const form=content.querySelector('[data-dossier-edit-form]');if(form){form.hidden=!form.hidden;b.setAttribute('aria-expanded',String(!form.hidden));if(!form.hidden)form.querySelector('input')?.focus();}return;}
  if(b.hasAttribute('data-dossier-cancel-edit')){const form=content.querySelector('[data-dossier-edit-form]');if(form)form.hidden=true;return;}
  if(b.hasAttribute('data-dossier-copy')){try{await navigator.clipboard.writeText(b.dataset.dossierCopy);notify('شماره تلفن کپی شد.')}catch(e){notify('کپی خودکار در این مرورگر در دسترس نیست.')}return;}
  if(b.hasAttribute('data-dossier-approve')){confirmAction(b.dataset.dossierApprove,'approve');return;}
  if(b.hasAttribute('data-dossier-revise')){confirmAction(b.dataset.dossierRevise,'revise');return;}
  if(b.hasAttribute('data-dossier-revoke')){confirmAction(b.dataset.dossierRevoke,'revoke',b.dataset.courseTitle);return;}
  if(b.hasAttribute('data-confirm-cancel')){closeConfirm();return;}
  if(b.hasAttribute('data-confirm-submit')){await commit();return;}
 });
 const backdrop=layer.querySelector('.sd13-backdrop');backdrop.addEventListener('click',close);
 document.addEventListener('keydown',e=>{
  if(layer.hidden)return;
  if(e.key==='Escape'){const modal=layer.querySelector('[data-dossier-confirm]');if(modal&&!modal.hidden)closeConfirm();else close();e.preventDefault();return;}
  if(e.key==='Tab'){
   const panel=layer.querySelector('[data-dossier-confirm]:not([hidden])')||shell;
   const focusable=[...panel.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),[tabindex="0"]')].filter(el=>!el.hidden&&el.getClientRects().length);
   if(!focusable.length)return;
   const first=focusable[0],last=focusable[focusable.length-1];if(e.shiftKey&&document.activeElement===first){last.focus();e.preventDefault()}else if(!e.shiftKey&&document.activeElement===last){first.focus();e.preventDefault()}
  }
 });
 root.addEventListener('submit',async evt=>{
  const form=evt.target;
  if(form.matches('[data-dossier-grant-form]')){evt.preventDefault();const sel=form.querySelector('select');if(!sel.value){notify('ابتدا دوره را انتخاب کنید.');sel.focus();return;}confirmAction(sel.value,'grant',sel.options[sel.selectedIndex].text);return;}if(!form.matches('[data-dossier-edit-form], [data-dossier-note-form]'))return;
  evt.preventDefault();if(busy)return;busy=true;
  const b=form.querySelector('[type="submit"]');if(b)b.disabled=true;
  const values=Object.fromEntries(new FormData(form).entries());values.user_id=uid;
  const isNote=form.hasAttribute('data-dossier-note-form');
  try{const res=await api(isNote?'add_note':'save_profile',values);swap(res.html,isNote?'history':'overview');notify(res.message)}catch(err){notify(err.message)}finally{busy=false;if(b&&b.isConnected)b.disabled=false;}
 });
 const search=root.querySelector('[data-dossier-search]'),list=root.querySelector('[data-dossier-people]'),status=root.querySelector('[data-dossier-search-status]');
 if(search&&list){let timeout;search.addEventListener('input',()=>{
  const q=search.value.trim(),seq=++searchSeq;clearTimeout(timeout);
  if(q.length===1){status.textContent='حداقل دو حرف وارد کن';return;}
  status.textContent='در حال جست‌وجو…';timeout=setTimeout(async()=>{
   try{const data=await api('people_search',{q});if(seq!==searchSeq)return;list.innerHTML=data.html;status.textContent=data.count+' نتیجه';}catch(err){if(seq===searchSeq)status.textContent=err.message;}
  },280);
 });}
}
function start(){document.querySelectorAll('.shipaa-v1[data-kind="admin"]').forEach(init)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
