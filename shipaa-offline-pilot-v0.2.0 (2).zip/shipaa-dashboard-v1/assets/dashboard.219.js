/* SHIPAA Command Center 1.5 — ناوبری ثابت، انیمیشن‌ها و برگه تأیید (به‌جای confirm/prompt مرورگر) */
(function(){'use strict';
var RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
var ORDER=['overview','requests','people','courses'];
function fa(n){try{return Number(n).toLocaleString('fa-IR');}catch(e){return String(n);}}
async function request(action,params){
 var body=new URLSearchParams();body.set('action','shipaa_v1_'+action);body.set('nonce',SHIPAA_V1.nonce);
 Object.entries(params||{}).forEach(function(x){body.set(x[0],x[1]);});
 var r=await fetch(SHIPAA_V1.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()});
 var json;try{json=await r.json();}catch(e){throw Error('پاسخ سرور قابل خواندن نبود.');}
 if(!json.success)throw Error(json.data&&json.data.message||'خطا در ارتباط با سرور');return json.data;
}
function init(root){
 if(root.dataset.svReady)return;root.dataset.svReady='1';
 var current='overview',toastT=0;
 function toast(msg,ms){var b=root.querySelector('.sv-toast');if(!b)return;b.textContent=msg;b.hidden=true;void b.offsetWidth;b.hidden=false;clearTimeout(toastT);toastT=setTimeout(function(){b.hidden=true;},ms||4600);}
 root.svToast=toast;
 function indicators(){
  var nav=root.querySelector('.sv-nav'),ni=root.querySelector('.sv-nav-ind'),na=nav&&nav.querySelector('[aria-pressed="true"]');
  if(ni&&na){ni.style.setProperty('--y',na.offsetTop+'px');ni.style.height=na.offsetHeight+'px';}
  var bot=root.querySelector('.sv-bottom'),bi=root.querySelector('.sv-bottom-ind'),ba=bot&&bot.querySelector('[aria-pressed="true"]');
  if(bi&&ba){var w=Math.min(68,ba.offsetWidth-8);bi.style.setProperty('--w',w+'px');bi.style.setProperty('--x',(ba.offsetLeft+(ba.offsetWidth-w)/2)+'px');}
 }
 addEventListener('resize',indicators);
 function countUp(panel){panel.querySelectorAll('[data-sv-count]').forEach(function(el){if(el.dataset.svDone||RM)return;el.dataset.svDone='1';var to=parseInt(el.dataset.svCount,10)||0,t0=performance.now();(function s(t){var k=Math.min(1,(t-t0)/900),e=1-Math.pow(1-k,3);el.textContent=fa(Math.round(to*e));if(k<1)requestAnimationFrame(s);})(t0);});}
 function tab(name,push){
  if(ORDER.indexOf(name)<0)name='overview';var dir=ORDER.indexOf(name)>=ORDER.indexOf(current)?1:-1;
  root.querySelectorAll('[data-panel]').forEach(function(el){var on=el.getAttribute('data-panel')===name;el.hidden=!on;el.classList.toggle('is-active',on);if(on&&name!==current){el.classList.remove('is-entering');el.style.setProperty('--dir',dir);void el.offsetWidth;el.classList.add('is-entering');countUp(el);}});
  root.querySelectorAll('.sv-nav button[data-tab],.sv-bottom button[data-tab]').forEach(function(el){el.setAttribute('aria-pressed',el.getAttribute('data-tab')===name?'true':'false');});
  if(name!==current)scrollTo({top:0,behavior:'auto'});
  current=name;indicators();
  if(push&&location.hash!=='#'+name)try{history.replaceState(null,'','#'+name);}catch(e){}
  if(push&&navigator.vibrate&&matchMedia('(pointer:coarse)').matches)try{navigator.vibrate(8);}catch(e){}
 }
 /* ریپل */
 root.addEventListener('pointerdown',function(e){var el=e.target.closest('.sv-button,.sv-navbutton,.sv-bottom button,.sv-quick>*,.sd13-action');if(!el||RM)return;var r=el.getBoundingClientRect(),d=Math.max(r.width,r.height),s=document.createElement('span');s.className='sv-ripple';s.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';if(getComputedStyle(el).position==='static')el.style.position='relative';el.style.overflow='hidden';el.appendChild(s);setTimeout(function(){s.remove();},650);},{passive:true});
 /* برگه تأیید */
 var sheet=root.querySelector('[data-sv-sheet]'),sheetState=null,busy=false,lastFocus=null;
 function openSheet(mode,id,trigger){
  if(!sheet)return;var card=root.querySelector('.sv-request[data-order-id="'+id+'"]');var who=card?card.querySelector('h3').textContent.trim():'سفارش #'+id;
  sheetState={mode:mode,id:id};lastFocus=trigger;
  sheet.querySelector('[data-sv-sheet-title]').textContent=mode==='approve'?'تأیید نهایی رسید':'درخواست اصلاح رسید';
  sheet.querySelector('[data-sv-sheet-desc]').textContent=mode==='approve'?who+' — با تأیید، سفارش ووکامرس تکمیل و دوره در استادیار برای مخاطب باز می‌شود.':who+' — سفارش معلق می‌ماند و مخاطب در صفحه ثبت‌نام‌ها «نیاز به اصلاح رسید» را می‌بیند.';
  sheet.querySelector('[data-sv-sheet-check-wrap]').hidden=mode!=='approve';sheet.querySelector('[data-sv-sheet-note-wrap]').hidden=mode!=='revise';var sw=sheet.querySelector('[data-sv-sheet-share-wrap]');if(sw){sw.hidden=mode!=='revise';sw.querySelector('input').checked=true;}
  sheet.querySelector('[data-sv-sheet-check]').checked=false;sheet.querySelector('[data-sv-sheet-note]').value='';
  var ok=sheet.querySelector('[data-sv-sheet-ok]');ok.textContent=mode==='approve'?'تأیید و باز کردن دوره':'ثبت درخواست اصلاح';
  sheet.hidden=false;document.documentElement.classList.add('sd13-modal-open');
  setTimeout(function(){sheet.querySelector(mode==='approve'?'[data-sv-sheet-check]':'[data-sv-sheet-note]').focus();},60);
 }
 function closeSheet(){if(!sheet||busy)return;sheet.hidden=true;document.documentElement.classList.remove('sd13-modal-open');if(lastFocus&&lastFocus.isConnected)lastFocus.focus();}
 async function commit(){
  if(!sheetState||busy)return;var m=sheetState.mode,id=sheetState.id;
  if(m==='approve'&&!sheet.querySelector('[data-sv-sheet-check]').checked){toast('ابتدا تأیید کنید که رسید را واقعاً بررسی کرده‌اید.');return;}
  var note=sheet.querySelector('[data-sv-sheet-note]').value.trim();if(m==='revise'&&note.length<4){toast('دلیل اصلاح را دست‌کم با ۴ نویسه بنویسید.');return;}
  busy=true;var ok=sheet.querySelector('[data-sv-sheet-ok]');ok.disabled=true;
  try{
   var d=await request(m==='approve'?'approve':'request_changes',m==='approve'?{order_id:id,confirmed:'yes'}:{order_id:id,note:note,share:(sheet.querySelector('[data-sv-sheet-share]')||{}).checked?'yes':'no'});
   busy=false;closeSheet();toast(d.message,d.tone==='warn'?9000:5600);
   root.querySelectorAll('.sv-request[data-order-id="'+id+'"]').forEach(function(el){
    if(m==='approve'){el.classList.add('is-leaving');setTimeout(function(){el.remove();updateCounts();},420);}
    else{var st=el.querySelector('.sv-status');if(st){st.className='sv-status is-lilac';st.textContent='نیازمند اصلاح';}el.className=el.className.replace(/tone-\w+/,'tone-lilac');var old=el.querySelector('.sv-req-note');if(old)old.remove();var sh=sheet.querySelector('[data-sv-sheet-share]');if(sh&&sh.checked){var n=document.createElement('small');n.className='sv-req-note';n.textContent='پیام به مخاطب: «'+note+'»';var meta=el.querySelector('.sv-req-meta');if(meta)meta.before(n);}}
   });
  }catch(e){toast(e.message);}finally{busy=false;ok.disabled=false;}
 }
 function updateCounts(){var n=root.querySelectorAll('#sv-requests .sv-request').length;root.querySelectorAll('.sv-badge').forEach(function(b){if(n)b.textContent=fa(n);else b.remove();});var chip=root.querySelector('.sv-count-chip');if(chip)chip.textContent=fa(n)+' مورد';if(!n){var l=root.querySelector('#sv-requests');if(l&&!l.querySelector('.sv-empty'))l.insertAdjacentHTML('beforeend','<div class="sv-empty"><strong>صف تأیید خالی است ✓</strong><span>همه ثبت‌نام‌ها بررسی شدند.</span></div>');}}
 root.addEventListener('click',function(evt){
  var el=evt.target.closest('button');if(!el||!root.contains(el))return;
  if(el.dataset.tab){tab(el.dataset.tab,true);return;}
  if(el.hasAttribute('data-sv-gate')){var on=el.getAttribute('aria-pressed')!=='true';el.disabled=true;request('gate',{on:on?'yes':'no'}).then(function(d){el.classList.toggle('is-on',d.on);el.setAttribute('aria-pressed',d.on?'true':'false');el.querySelector('[data-sv-gate-tx]').textContent='تأیید دستی ثبت‌نام‌ها: '+(d.on?'روشن':'خاموش');toast(d.message,6000);}).catch(function(e){toast(e.message);}).finally(function(){el.disabled=false;});return;}
  if(el.dataset.approve){openSheet('approve',el.dataset.approve,el);return;}
  if(el.dataset.revise){openSheet('revise',el.dataset.revise,el);return;}
  if(el.hasAttribute('data-sv-sheet-close')){closeSheet();return;}
  if(el.hasAttribute('data-sv-sheet-ok')){commit();return;}
  if(el.dataset.svFilter){root.querySelectorAll('[data-sv-filter]').forEach(function(b){b.classList.toggle('is-on',b===el);});var f=el.dataset.svFilter;root.querySelectorAll('#sv-requests .sv-request').forEach(function(r){var st=r.querySelector('.sv-status');r.hidden=f!=='all'&&!(st&&st.classList.contains(f));});return;}
 });
 if(sheet){sheet.querySelector('.sv-sheet-back').addEventListener('click',closeSheet);}
 document.addEventListener('keydown',function(e){if(sheet&&!sheet.hidden&&e.key==='Escape'){closeSheet();e.preventDefault();}});
 var top=root.querySelector('.sv-top');addEventListener('scroll',function(){if(top)top.classList.toggle('is-scrolled',scrollY>6);},{passive:true});
 /* بررسی زنده صف: هر ۲۰ ثانیه و هنگام برگشت به زبانه */
 var polling=false;
 function setBadge(n){
  root.querySelectorAll('[data-tab="requests"] .sv-nav-ic').forEach(function(ic){var b=ic.querySelector('.sv-badge');if(!n){if(b)b.remove();return;}if(!b){b=document.createElement('b');b.className='sv-badge';ic.appendChild(b);}b.textContent=fa(n);});
  var chip=root.querySelector('.sv-count-chip');if(chip)chip.textContent=fa(n)+' مورد';
 }
 function poll(){
  if(polling||busy||document.hidden||(sheet&&!sheet.hidden)||document.documentElement.classList.contains('sd13-modal-open'))return;
  var list=root.querySelector('#sv-requests');if(!list)return;polling=true;
  request('queue',{}).then(function(d){
   var old=(list.dataset.svIds||'').split(',').filter(Boolean),now=(d.ids||[]).map(String);
   if(old.join(',')===now.join(','))return;
   var added=now.filter(function(x){return old.indexOf(x)<0;});
   list.innerHTML=d.list;list.dataset.svIds=now.join(',');
   var pv=root.querySelector('[data-sv-preview]');if(pv)pv.innerHTML=d.preview;
   setBadge(d.count);
   added.forEach(function(id){root.querySelectorAll('.sv-request[data-order-id="'+id+'"]').forEach(function(el){el.classList.add('is-new');});});
   var f=root.querySelector('[data-sv-filter].is-on');if(f&&f.dataset.svFilter!=='all')f.click();
   if(added.length){toast('🔔 '+fa(added.length)+' ثبت‌نام تازه رسید',6000);if(navigator.vibrate)try{navigator.vibrate([10,40,10]);}catch(e){}}
  }).catch(function(){}).finally(function(){polling=false;});
 }
 setInterval(poll,20000);
 document.addEventListener('visibilitychange',function(){if(!document.hidden)poll();});
 var dt=root.querySelector('[data-sv-date]');if(dt)try{dt.textContent='· '+new Intl.DateTimeFormat('fa-IR-u-ca-persian',{weekday:'long',day:'numeric',month:'long'}).format(new Date());}catch(e){}
 var start=(location.hash||'').replace('#','');tab(ORDER.indexOf(start)>=0?start:'overview',false);
 var first=root.querySelector('[data-panel]:not([hidden])');if(first){first.classList.add('is-entering');countUp(first);}
 setTimeout(indicators,300);
}
function load(){document.querySelectorAll('[data-sh-v1]').forEach(init);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',load);else load();
})();
