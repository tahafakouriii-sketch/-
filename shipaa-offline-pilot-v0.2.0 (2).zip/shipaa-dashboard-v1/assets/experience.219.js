/* SHIPAA Experience 1.8: progressive improvements on top of original navigation and player. */
(function(){'use strict';
var root=document.querySelector('[data-sp-root]');
if(!root)return;
var conf=window.SHIPAA_EXP180||{}, form=root.querySelector('[data-sip-root]');
var input=form&&form.querySelector('[data-sip-upload]'),status=form&&form.querySelector('[data-sp-photo-status]');
var photoTargets=function(){return Array.prototype.slice.call(root.querySelectorAll('.sp-avatar-hero,.sip-avatar-main,.sip-avatar-preview'));};
function send(action,file){
 var fd=new FormData();fd.append('action','shipaa_avatar180_'+action);fd.append('nonce',conf.nonce||'');
 if(file)fd.append('shipaa_avatar_upload',file,file.name);
 return fetch(conf.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json().catch(function(){throw new Error('پاسخ سرور معتبر نیست.');}).then(function(j){if(!r.ok||!j.success)throw new Error((j.data&&j.data.message)||'در ذخیره تصویر مشکلی پیش آمد.');return j.data||{};});});
}
function showMessage(t,isError){if(!status)return;status.textContent=t;status.classList.toggle('is-error',!!isError);}
function replacePhoto(url,symbol){photoTargets().forEach(function(el){
 var isHero=el.classList.contains('sp-avatar-hero');
 if(url){var img;if(el.tagName.toLowerCase()==='img'){el.src=url+(url.indexOf('?')===-1?'?':'&')+'shavatar='+Date.now();return;}
 img=document.createElement('img');img.src=url;img.alt='تصویر پروفایل شما';img.className=isHero?'sip-avatar-img sp-avatar-hero':'sip-avatar-img '+(el.classList.contains('sip-avatar-main')?'sip-avatar-main':'sip-avatar-preview');el.replaceWith(img);
 }else{if(el.tagName.toLowerCase()==='img'){var span=document.createElement('span');span.className='sip-avatar-fallback '+(isHero?'sp-avatar-hero':el.classList.contains('sip-avatar-main')?'sip-avatar-main':'sip-avatar-preview');span.textContent=symbol||'👤';el.replaceWith(span);}else el.textContent=symbol||'👤';}
 });}
if(input){
 input.setAttribute('accept','image/jpeg,image/png,image/webp');
 input.addEventListener('change',function(){
  var file=input.files&&input.files[0];if(!file)return;
  if(!/^image\/(jpeg|png|webp)$/.test(file.type)||file.size>3*1024*1024||file.size<=0){showMessage('فقط JPG، PNG یا WebP تا ۳ مگابایت مجاز است.',true);input.value='';return;}
  showMessage('در حال ذخیره تصویر…');input.disabled=true;
  send('upload',file).then(function(data){showMessage(data.message||'تصویر ذخیره شد');replacePhoto(data.url);input.value='';}).catch(function(err){showMessage(err.message,true);}).finally(function(){input.disabled=false;});
 });
}
var remove=form&&form.querySelector('[data-sp-photo-remove]');
if(remove)remove.addEventListener('click',function(){
 remove.disabled=true;showMessage('در حال حذف تصویر…');
 send('remove').then(function(data){replacePhoto('',data.symbol);showMessage(data.message||'تصویر حذف شد');if(input)input.value='';}).catch(function(err){showMessage(err.message,true);}).finally(function(){remove.disabled=false;});
});
// Floating menu labels are announced, while buttons remain the original routed anchors.
root.querySelectorAll('.sp-rail-nav a').forEach(function(a){
 var label=a.querySelector('.sp-nav-tx');if(label)a.setAttribute('aria-label',label.textContent.trim());
});
})();
