/* SHIPAA host-fit 1.6.0 — هماهنگی با هدر و نوار پایین قالب سایت
   - اگر هدر اصلی سایت دیده می‌شود، هدر داخلی برنامه پنهان می‌شود (جلوگیری از هدر دوگانه).
   - ارتفاع هدر چسبان سایت در --host-top ثبت می‌شود تا پلیر و فهرست زیر آن بچسبند.
   - نوار پایین قالب حفظ می‌شود و منوی شیپا بالای آن قرار می‌گیرد. */
(function(){'use strict';
var SEL='[data-sp-root],[data-sh-v1]';
function visible(el){var cs=getComputedStyle(el);if(cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0)return false;var r=el.getBoundingClientRect();return r.width>0&&r.height>0;}
function fit(){
 document.querySelectorAll(SEL).forEach(function(app){
  var vw=innerWidth,vh=innerHeight,headTop=0,hasHead=false;
  document.querySelectorAll('header,[id*="header" i],[class*="header" i],[class*="topbar" i],[class*="navbar" i]').forEach(function(h){
   if(app.contains(h)||h.contains(app)||!visible(h))return;
   var r=h.getBoundingClientRect(),cs=getComputedStyle(h);
   if(r.height<30||r.height>220||r.width<vw*.6)return;
   var absTop=r.top+scrollY;if(absTop>app.getBoundingClientRect().top+scrollY+5)return; // فقط بالای برنامه
   hasHead=true;
   if((cs.position==='fixed'||cs.position==='sticky')&&r.top<=2)headTop=Math.max(headTop,Math.round(r.bottom));
  });
  app.classList.toggle('has-host-header',hasHead);
  app.style.setProperty('--host-top',headTop+'px');
  // نوار پایین قالب دست نمی‌خورد؛ فقط ارتفاعش اندازه گرفته می‌شود تا منوی شیپا روی آن نیفتد
  var bottom=0;
  if(vw<=1024)document.querySelectorAll('body *').forEach(function(el){
   if(app.contains(el)||el.contains(app))return;
   var cs=getComputedStyle(el);if(cs.position!=='fixed'||cs.display==='none'||cs.visibility==='hidden')return;
   var r=el.getBoundingClientRect();
   if(r.width>=vw*.6&&r.height>=36&&r.height<=110&&r.bottom>=vh-6&&r.top>vh*.6)bottom=Math.max(bottom,Math.round(vh-r.top));
  });
  app.style.setProperty('--host-bottom',bottom+'px');
  app.classList.toggle('has-host-bottom',bottom>0);
 });
}
var t=0;function later(){clearTimeout(t);t=setTimeout(fit,150);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fit);else fit();
addEventListener('load',fit);addEventListener('resize',later);addEventListener('orientationchange',later);
// Removed delayed 1200ms re-fit to prevent visible post-load layout shift.
})();
