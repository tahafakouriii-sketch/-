(function(){'use strict';
function init(){
 var root=document.getElementById('shipaa-packs-v2');if(!root)return;
 var cfg=window.SHIPAA_PACKS_V2||{};var data={};try{data=JSON.parse(document.getElementById('spm-config').textContent||'{}')}catch(e){}
 var course=root.querySelector('#spm-course'),lesson=root.querySelector('#spm-lesson'),editor=root.querySelector('#spm-editor'),
 desc=root.querySelector('#spm-description'),rows=root.querySelector('#spm-rows'),status=root.querySelector('#spm-state'),intro=root.querySelector('#spm-intro');
 var loadID=0,dirty=false,acceptedCourse='',acceptedLesson='';
 function note(s,error){status.textContent=s||'';status.classList.toggle('is-error',!!error);}
 function request(mode,fields){
  var body=new FormData();body.append('action','shipaa_packs_v2');body.append('nonce',cfg.nonce||'');body.append('course',course.value);body.append('lesson',lesson.value);body.append('mode',mode);
  Object.keys(fields||{}).forEach(function(k){body.append(k,fields[k]);});
  return fetch(cfg.ajax,{method:'POST',body:body,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(json){if(!json.success)throw Error(json.data&&json.data.message||'خطا در ارتباط با سایت');return json.data;});
 }
 function row(item){item=item||{};var el=document.createElement('div');el.className='spm-row';
  var a=document.createElement('input');a.className='spm-row-title';a.placeholder='عنوان محتوا';a.setAttribute('aria-label','عنوان محتوا');a.value=item.title||'';
  var b=document.createElement('input');b.className='spm-row-url';b.placeholder='https://…';b.type='url';b.dir='ltr';b.setAttribute('aria-label','آدرس فایل');b.value=item.url||'';
  var c=document.createElement('select');c.setAttribute('aria-label','نوع محتوا');
  [['note','جزوه'],['slide','پاورپوینت'],['audio','صوت'],['image','عکس‌نوشت'],['summary','خلاصه'],['video','ویدئوی تکمیلی'],['file','سایر فایل‌ها']].forEach(function(pair){var o=document.createElement('option');o.value=pair[0];o.textContent=pair[1];c.append(o)});c.value=item.type||'file';
  var rm=document.createElement('button');rm.type='button';rm.className='button spm-row-remove';rm.textContent='×';rm.setAttribute('aria-label','حذف این فایل');rm.addEventListener('click',function(){el.remove();dirty=true;});
  el.append(a,b,c,rm);rows.append(el);[a,b,c].forEach(function(field){field.addEventListener('input',function(){dirty=true;});});return el;
 }
 function populateLessons(){
  lesson.replaceChildren();var blank=document.createElement('option');blank.value='';blank.textContent='انتخاب جلسه';lesson.append(blank);
  var item=(data.courses||[]).find(function(x){return String(x.id)===course.value;});
  (item&&item.lessons||[]).forEach(function(l){var opt=document.createElement('option');opt.value=l.key;opt.textContent=l.name;lesson.append(opt);});
  lesson.disabled=!item||!item.lessons.length;editor.hidden=true;intro.hidden=false;note('');
 }
 function openLesson(){
  var id=++loadID;editor.hidden=true;intro.hidden=!lesson.value;if(!lesson.value)return;
  note('در حال دریافت…');
  request('read').then(function(v){
   if(id!==loadID)return;
   desc.value=v.description||'';rows.replaceChildren();(v.items||[]).forEach(row);
   root.querySelector('#spm-session-title').textContent=lesson.selectedOptions[0].textContent;
   editor.hidden=false;intro.hidden=true;dirty=false;note('');
  }).catch(function(e){if(id===loadID)note(e.message,true);});
 }
 course.addEventListener('change',function(){
  if(dirty&&!window.confirm('تغییرات ذخیره‌نشده این جلسه از بین می‌رود. ادامه می‌دهید؟')){course.value=acceptedCourse;return;}
  dirty=false;acceptedCourse=course.value;acceptedLesson='';loadID++;populateLessons();
 });
 lesson.addEventListener('change',function(){
  if(dirty&&!window.confirm('تغییرات ذخیره‌نشده این جلسه از بین می‌رود. ادامه می‌دهید؟')){lesson.value=acceptedLesson;return;}
  dirty=false;acceptedLesson=lesson.value;openLesson();
 });
 desc.addEventListener('input',function(){dirty=true;});
 root.querySelector('#spm-add').addEventListener('click',function(){row({});dirty=true;});
 root.querySelector('#spm-media').addEventListener('click',function(){
  if(!window.wp||!wp.media){note('کتابخانه رسانه بارگذاری نشده است.',true);return;}
  var frame=wp.media({title:'انتخاب محتوا برای این جلسه',button:{text:'افزودن به جلسه'},multiple:true});
  frame.on('select',function(){frame.state().get('selection').each(function(m){var a=m.toJSON();row({title:a.title||a.filename,url:a.url,type:a.type==='audio'?'audio':a.type==='image'?'image':a.type==='video'?'video':'file'});dirty=true;});});frame.open();
 });
 root.querySelector('#spm-save').addEventListener('click',function(){
  if(!lesson.value)return;var items=[];var invalid=false;
  rows.querySelectorAll('.spm-row').forEach(function(el){var title=el.querySelector('.spm-row-title').value.trim(),url=el.querySelector('.spm-row-url').value.trim(),type=el.querySelector('select').value;
   if(!url){if(title)invalid=true;return;}if(!/^https?:\/\//i.test(url)){invalid=true;return;}items.push({title:title,url:url,type:type});
  });
  if(invalid){note('نشانی برخی فایل‌ها خالی یا نامعتبر است.',true);return;}if(items.length>40){note('برای هر جلسه حداکثر ۴۰ فایل ثبت می‌شود.',true);return;}
  var save=root.querySelector('#spm-save');save.disabled=true;note('در حال ذخیره…');var when=loadID;
  request('save',{description:desc.value,items:JSON.stringify(items)}).then(function(){if(when!==loadID)return;note('✓ محتوای این جلسه ذخیره شد.');dirty=false;}).catch(function(e){note(e.message,true);}).finally(function(){save.disabled=false;});
 });
 var initial=String(data.selected||'');
 (data.courses||[]).forEach(function(item){var option=document.createElement('option');option.value=item.id;option.textContent=item.name;course.append(option)});
 if(initial){course.value=initial;acceptedCourse=initial;populateLessons();}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
