(function(){
  var root=document.querySelector('[data-sip-root]');
  if(!root) return;
  var mapEl=root.parentNode.querySelector('.sip-city-map') || root.querySelector('.sip-city-map');
  var cityMap={};
  if(mapEl){ try{ cityMap=JSON.parse(mapEl.textContent||'{}'); }catch(e){} }
  var province=root.querySelector('[data-sip-province]');
  var cityInput=root.querySelector('[data-sip-city]');
  var dataList=root.parentNode.querySelector('#shipaa-city-suggestions') || root.querySelector('#shipaa-city-suggestions');
  function fillCities(){
    if(!province || !dataList) return;
    var key=province.value||'';
    var list=cityMap[key]||[];
    dataList.innerHTML='';
    list.forEach(function(name){
      var opt=document.createElement('option');
      opt.value=name;
      dataList.appendChild(opt);
    });
    if(cityInput){ cityInput.placeholder=list.length?'از پیشنهادها انتخاب کنید یا بنویسید':'نام شهرستان را وارد کنید'; }
  }
  if(province){ province.addEventListener('change',fillCities); fillCities(); }

  var fileInput=root.querySelector('[data-sip-upload]');
  var box=root.querySelector('.sip-preview-box');
  var initial=box?box.innerHTML:'';
  if(fileInput && box)fileInput.addEventListener('change',function(){
    var file=fileInput.files && fileInput.files[0];
    if(!file){box.innerHTML=initial;return;}
    if(file.type.indexOf('image/')!==0)return;
    var reader=new FileReader();
    reader.onload=function(e){var img=document.createElement('img');img.className='sip-avatar-img sip-avatar-preview';img.alt='پیش‌نمایش تصویر';img.src=e.target.result;box.replaceChildren(img);};
    reader.readAsDataURL(file);
  });
})();
