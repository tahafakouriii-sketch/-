/* SHIPAA Learner App 1.5 — مسیریابی، انیمیشن‌ها و پلیر جلسه‌های استادیار */
(function(){'use strict';
var CFG=window.SHIPAA_APP||{};
var RM=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
var COARSE=window.matchMedia&&matchMedia('(pointer: coarse)').matches;
var ORDER=['home','courses','learn','requests','account'];
var NAMES={home:'خانه',courses:'دوره‌های من',learn:'کلاس من',requests:'ثبت‌نام‌ها',account:'پروفایل من'};
var RATES=[1,1.25,1.5,1.75,2,0.75];
var IC={
 play:'<path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/>',
 pause:'<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor" stroke="none"/>',
 back10:'<path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4v4.5h4.5"/><text x="12" y="15.5" font-size="7" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700">10</text>',
 fwd10:'<path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20 4v4.5h-4.5"/><text x="12" y="15.5" font-size="7" text-anchor="middle" fill="currentColor" stroke="none" font-weight="700">10</text>',
 full:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
 pip:'<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1" fill="currentColor"/>',
 vol:'<path d="M4 9.5h4L13 5v14l-5-4.5H4z"/><path d="M16.5 9a4 4 0 0 1 0 6"/>',
 mute:'<path d="M4 9.5h4L13 5v14l-5-4.5H4z"/><path d="m17 9.5 4 5M21 9.5l-4 5"/>',
 headphones:'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3.5" y="13.5" width="4.5" height="7" rx="2"/><rect x="16" y="13.5" width="4.5" height="7" rx="2"/>',
 file:'<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h4"/>',
 ext:'<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
 book:'<path d="M12 6.5C9.5 4.8 6.5 4.5 3.5 5.3v13.4c3-.8 6-.5 8.5 1.3 2.5-1.8 5.5-2.1 8.5-1.3V5.3c-3-.8-6-.5-8.5 1.2z"/><path d="M12 6.5V20"/>',
 leaf:'<path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14z"/><path d="M5 19 13 11"/>',
 retry:'<path d="M20 12a8 8 0 1 1-2.4-5.7"/><path d="M20 4v4.5h-4.5"/>'
};
function svg(k){return '<svg class="sp-i" aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(IC[k]||'')+'</svg>';}
function fa(n){try{return Number(n).toLocaleString('fa-IR');}catch(e){return String(n);}}
function clock(s){s=Math.max(0,Math.floor(s||0));var h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60;var t=(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(r).padStart(2,'0');return t.replace(/\d/g,function(d){return '۰۱۲۳۴۵۶۷۸۹'[d];});}
function esc(s){var d=document.createElement('div');d.textContent=s==null?'':String(s);return d.innerHTML;}
function store(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v);}catch(e){return null;}}
function buzz(){if(COARSE&&navigator.vibrate)try{navigator.vibrate(8);}catch(e){}}

function init(root){
 if(root.dataset.spReady)return;root.dataset.spReady='1';
 var boot={};try{boot=JSON.parse((root.querySelector('[data-sp-boot]')||{}).textContent||'{}');}catch(e){}
 var current='',toastTimer=0;

 /* ---------- پیام کوتاه ---------- */
 function toast(msg,actLabel,actFn,ms){
  var box=root.querySelector('.sp-toast');if(!box)return;
  var tx=box.querySelector('[data-sp-toast-tx]'),act=box.querySelector('[data-sp-toast-act]');
  tx.textContent=msg;box.hidden=true;void box.offsetWidth;box.hidden=false;
  if(actLabel&&actFn){act.hidden=false;act.textContent=actLabel;act.onclick=function(){box.hidden=true;actFn();};}else{act.hidden=true;act.onclick=null;}
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){box.hidden=true;},ms||3800);
 }

 /* ---------- ریپل و لمس ---------- */
 root.addEventListener('pointerdown',function(e){
  var el=e.target.closest('.sp-btn,.sp-tab,.sp-rail-btn,.sp-q,.sp-lesson,.sp-filters button');if(!el||RM)return;
  var r=el.getBoundingClientRect(),d=Math.max(r.width,r.height),s=document.createElement('span');
  s.className='sp-ripple';s.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';
  if(getComputedStyle(el).position==='static')el.style.position='relative';el.style.overflow='hidden';
  el.appendChild(s);setTimeout(function(){s.remove();},650);
 },{passive:true});

 /* ---------- نشانگر منو ---------- */
 function moveIndicators(){
  var rail=root.querySelector('.sp-rail-nav'),ri=root.querySelector('.sp-rail-ind'),ra=rail&&rail.querySelector('[aria-current="page"]');
  if(ri){if(ra){ri.style.opacity=1;ri.style.setProperty('--y',ra.offsetTop+'px');ri.style.height=ra.offsetHeight+'px';}else ri.style.opacity=0;}
  var bar=root.querySelector('.sp-tabbar'),ti=root.querySelector('.sp-tab-ind'),ta=bar&&bar.querySelector('[aria-current="page"]');
  if(ti&&bar){if(ta&&!ta.classList.contains('sp-tab-fab')){var w=Math.min(64,ta.offsetWidth-6);ti.style.opacity=1;ti.style.setProperty('--w',w+'px');ti.style.setProperty('--x',(ta.offsetLeft+(ta.offsetWidth-w)/2)+'px');}else ti.style.opacity=0;}
 }
 addEventListener('resize',moveIndicators);

 /* ---------- شمارنده و حلقه‌ها ---------- */
 function animateScreen(sc){
  sc.querySelectorAll('[data-sp-count]').forEach(function(el){
   if(el.dataset.spDone)return;el.dataset.spDone='1';var to=parseInt(el.dataset.spCount,10)||0;
   if(RM||!to){el.textContent=fa(to);return;}
   var t0=performance.now(),dur=900;(function step(t){var k=Math.min(1,(t-t0)/dur),e=1-Math.pow(1-k,3);el.textContent=fa(Math.round(to*e));if(k<1)requestAnimationFrame(step);})(t0);
  });
  sc.querySelectorAll('.sp-ring.is-pre').forEach(function(r){requestAnimationFrame(function(){requestAnimationFrame(function(){r.classList.remove('is-pre');});});});
 }
 root.querySelectorAll('.sp-ring').forEach(function(r){r.classList.add('is-pre');});
 root.querySelectorAll('[data-sp-screen]').forEach(function(sc){var i=0;sc.querySelectorAll('[data-sp-reveal]').forEach(function(el){el.style.setProperty('--i',Math.min(i++,8));});});

 /* ---------- مسیریابی ---------- */
 function parse(){
  var h=location.hash||'';
  var legacy=h.match(/^#shipaa-(home|courses|requests|account|learning)(?:-(\d+))?$/);
  if(legacy)return {s:legacy[1]==='learning'?'learn':legacy[1],c:legacy[2]||'',k:''};
  var m=h.match(/^#\/(home|courses|learn|requests|account)(?:\/(\d+))?(?:\/([\w-]+))?$/);
  return m?{s:m[1],c:m[2]||'',k:m[3]||''}:{s:'home',c:'',k:''};
 }
 function show(name,first){
  var screens=root.querySelectorAll('[data-sp-screen]'),changed=name!==current;
  var dir=ORDER.indexOf(name)>=ORDER.indexOf(current)?1:-1;
  screens.forEach(function(sc){var on=sc.dataset.spScreen===name;sc.hidden=!on;sc.classList.toggle('is-on',on);if(on&&changed&&!first){sc.classList.remove('is-entering');sc.style.setProperty('--dir',dir);void sc.offsetWidth;sc.classList.add('is-entering');}});
  root.querySelectorAll('[data-sp-nav]').forEach(function(a){if(a.closest('.sp-rail-nav,.sp-tabbar')){if(a.dataset.spNav===name)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');}});
  var crumb=root.querySelector('[data-sp-crumb]');if(crumb&&crumb.textContent!==NAMES[name]){crumb.textContent=NAMES[name];crumb.classList.remove('is-swap');void crumb.offsetWidth;crumb.classList.add('is-swap');}
  moveIndicators();
  var sc=root.querySelector('[data-sp-screen="'+name+'"]');if(sc)animateScreen(sc);
  if(changed&&!first){scrollTo({top:0,behavior:'auto'});var h1=sc&&Array.prototype.find.call(sc.querySelectorAll('h1'),function(h){return h.offsetParent!==null;});if(h1)try{h1.focus({preventScroll:true});}catch(e){}}
  current=name;
 }
 function route(first){
  var r=parse();
  if(r.s==='learn'){
   var pick=root.querySelector('[data-sp-learn-pick]');
   var sections=root.querySelectorAll('[data-sp-learn]');
   if(r.c){
    var sec=root.querySelector('[data-sp-learn="'+r.c+'"]');
    if(!sec){toast('این دوره هنوز برای شما باز نشده است؛ وضعیت ثبت‌نام را ببینید.','ثبت‌نام‌ها',function(){location.hash='#/requests';});location.replace('#/courses');return;}
    if(pick)pick.hidden=true;sections.forEach(function(s){s.hidden=s!==sec;});
    show('learn',first);
    var meta={};try{meta=JSON.parse(sec.querySelector('[data-sp-first]').textContent||'{}');}catch(e){}
    var key=r.k||meta.last||meta.first;
    if(key&&(Player.course!==r.c||Player.key!==key))Player.load(sec,r.c,key,!first&&!!r.k);
    return;
   }
   if(pick)pick.hidden=false;sections.forEach(function(s){s.hidden=true;});
  }
  if(r.s!=='learn')Player.pauseAll();
  show(r.s,first);
 }
 addEventListener('hashchange',function(){route(false);});

 root.addEventListener('click',function(e){
  var el=e.target.closest('[data-sp-open],[data-sp-resume],[data-sp-resume-nav],[data-sp-nav],[data-sp-lesson],[data-sp-prev],[data-sp-next],[data-sp-filter-btn],[data-sp-install-btn]');
  if(!el||!root.contains(el))return;
  if(el.hasAttribute('data-sp-resume-nav')&&current==='learn'&&Player.course){e.preventDefault();return;}
  if(el.hasAttribute('data-sp-resume-nav')&&boot.resume&&current!=='learn'){e.preventDefault();buzz();location.hash='#/learn/'+boot.resume.course+'/'+boot.resume.key;return;}
  if(el.hasAttribute('data-sp-nav')){buzz();if(location.hash===el.getAttribute('href')){e.preventDefault();route(false);}return;}
  if(el.hasAttribute('data-sp-open')){e.preventDefault();location.hash='#/learn/'+el.dataset.spOpen;return;}
  if(el.hasAttribute('data-sp-resume')){e.preventDefault();if(boot.resume)location.hash='#/learn/'+boot.resume.course+'/'+boot.resume.key;return;}
  if(el.hasAttribute('data-sp-lesson')){var sec=el.closest('[data-sp-learn]');Player.load(sec,el.dataset.spCourse,el.dataset.spLesson,true);if(innerWidth<=1024){var p=sec.querySelector('[data-sp-player]');if(p)p.scrollIntoView({behavior:RM?'auto':'smooth',block:'start'});}return;}
  if(el.hasAttribute('data-sp-prev')){Player.step(-1);return;}
  if(el.hasAttribute('data-sp-next')){Player.step(1);return;}
  if(el.hasAttribute('data-sp-filter-btn')){root.querySelectorAll('[data-sp-filter-btn]').forEach(function(b){b.classList.toggle('is-on',b===el);});filter();return;}
  if(el.hasAttribute('data-sp-install-btn')){install();return;}
 });

 /* ---------- جست‌وجو و فیلتر ---------- */
 var search=root.querySelector('[data-sp-search]');
 function norm(v){return String(v||'').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/[‌‍]/g,' ').replace(/\s+/g,' ').trim().toLowerCase();}
 function filter(){
  var q=norm(search&&search.value),f=(root.querySelector('[data-sp-filter-btn].is-on')||{dataset:{}}).dataset.spFilterBtn||'all',n=0;
  root.querySelectorAll('[data-sp-grid] [data-sp-card]').forEach(function(c){var ok=(f==='all'||c.dataset.spFilter===f)&&norm(c.dataset.spTitle).indexOf(q)!==-1;var was=!c.classList.contains('is-hiding');c.classList.toggle('is-hiding',!ok);if(ok){n++;if(!was){c.classList.remove('is-show');void c.offsetWidth;c.classList.add('is-show');}}});
  var em=root.querySelector('[data-sp-search-empty]');if(em)em.hidden=n>0;
 }
 if(search)search.addEventListener('input',filter);

 /* ---------- نوار بالا ---------- */
 var bar=root.querySelector('[data-sp-appbar]');
 addEventListener('scroll',function(){if(bar)bar.classList.toggle('is-scrolled',scrollY>6);},{passive:true});

 /* ---------- نصب روی گوشی ---------- */
 var deferred=null,installCard=root.querySelector('[data-sp-install]');
 var standalone=matchMedia('(display-mode: standalone)').matches||navigator.standalone;
 addEventListener('beforeinstallprompt',function(e){deferred=e;if(installCard&&!standalone)installCard.hidden=false;});
 var IOS=/iphone|ipad|ipod/i.test(navigator.userAgent);
 if(installCard&&!standalone&&COARSE){installCard.hidden=false;}
 function install(){
  if(deferred){deferred.prompt();deferred.userChoice.finally(function(){deferred=null;});return;}
  if(IOS)toast('در سافاری: دکمه «اشتراک‌گذاری» ⬆︎ و سپس «Add to Home Screen» را بزنید.',null,null,7000);
  else toast('در کروم: منوی ⋮ بالای صفحه و سپس «نصب برنامه» یا «افزودن به صفحه اصلی» را بزنید.',null,null,7000);
 }

 /* ---------- پیام ذخیره پروفایل ---------- */
 var qs=new URLSearchParams(location.search);
 if(qs.get('shipaa_profile_status')==='saved'){toast('تغییرات پروفایل شما ذخیره شد ✓');}
 if(qs.get('shipaa_profile_status')){try{qs.delete('shipaa_profile_status');qs.delete('shipaa_profile_message');history.replaceState(null,'',location.pathname+(qs.toString()?'?'+qs:'')+location.hash);}catch(e){}}

 /* ======================= پلیر ======================= */
 var Player={course:'',key:'',data:null,sec:null,media:null,seq:0,lastSave:0,ended:false,endTimer:0,
  api:function(action,params,keep){
   var body=new URLSearchParams({action:'shipaa_l3_'+action,nonce:CFG.nonce||''});Object.keys(params).forEach(function(k){if(params[k]!==undefined&&params[k]!==null)body.set(k,params[k]);});
   return fetch(CFG.ajax,{method:'POST',credentials:'same-origin',keepalive:!!keep,headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
    .then(function(r){return r.json().catch(function(){throw Error('پاسخ سرور قابل خواندن نبود.');});})
    .then(function(j){if(!j||!j.success)throw Error(j&&j.data&&j.data.message||'ارتباط با سرور برقرار نشد.');return j.data;});
  },
  pauseAll:function(){if(this.media&&!this.media.paused){this.media.pause();}},
  save:function(extra,keep){
   if(!this.course||!this.key)return Promise.resolve();
   var m=this.media,p={course:this.course,lesson:this.key};
   if(this.watchPending){p.watch=Math.min(20,Math.floor(this.watchPending));this.watchPending-=p.watch;}
   if(m&&isFinite(m.duration)&&m.duration>0){p.pos=Math.floor(m.currentTime);p.dur=Math.floor(m.duration);}
   if(extra)Object.keys(extra).forEach(function(k){p[k]=extra[k];});
   this.lastSave=Date.now();var self=this;var key=this.key,course=this.course;
   try{store('sp-pos-'+course+'-'+key,p.pos||0);}catch(e){}
   return this.api('progress',p,keep).then(function(d){self.applyProgress(course,key,d);return d;}).catch(function(err){if(extra&&'done' in extra)toast('ذخیره نشد؛ اتصال اینترنت را بررسی کنید.');});
  },
  applyProgress:function(course,key,d){
   if(!d)return;var sec=root.querySelector('[data-sp-learn="'+course+'"]');
   if(sec){var row=sec.querySelector('[data-sp-lesson="'+key+'"]');if(row)row.classList.toggle('is-done',!!d.done);}
   if(key===this.key&&course===this.course){var b=this.sec&&this.sec.querySelector('[data-sp-auto-seen]');if(b){b.classList.toggle('is-done',!!d.done);b.querySelector('span').textContent=d.done?'مشاهده ثبت شد ✓':'ثبت مشاهده خودکار';}}
   if(d.course){var pct=d.course.percent;
    root.querySelectorAll('[data-sp-ring="'+course+'"]').forEach(function(r){r.style.setProperty('--p',pct);var n=r.querySelector('[data-sp-ring-num]');if(n)n.textContent=fa(pct);});
    root.querySelectorAll('[data-sp-course-bar="'+course+'"]').forEach(function(b){b.style.setProperty('--w',pct+'%');});
    root.querySelectorAll('[data-sp-course-pct="'+course+'"]').forEach(function(n){n.textContent=fa(pct);});
    root.querySelectorAll('[data-sp-course-count="'+course+'"]').forEach(function(c){c.textContent=fa(d.course.done)+' از '+fa(d.course.total)+' جلسه';});
   }
  },
  step:function(dir){var d=this.data;if(!d)return;var k=dir>0?d.next:d.prev;if(k)this.load(this.sec,this.course,k,true);else if(dir>0)this.finishCourse();},
  load:function(sec,course,key,autoplay){
   if(!sec)return;var self=this;
   if(this.media&&this.course){this.save(null,true);this.media.pause();}
   clearTimeout(this.endTimer);this.ended=false;
   this.sec=sec;this.course=String(course);this.key=key;this.data=null;this.media=null;var seq=++this.seq;
   var player=sec.querySelector('[data-sp-player]'),stage=sec.querySelector('[data-sp-stage]');
   var oldPack=sec.querySelector('[data-sp-pack]');if(oldPack)oldPack.hidden=true;
   player.className='sp-player';player.querySelectorAll('.sp-endcard,.sp-confetti').forEach(function(x){x.remove();});stage.innerHTML='<div class="sp-skel"><div><div class="sp-spin"></div>در حال آماده‌سازی جلسه…</div></div>';
   sec.querySelectorAll('[data-sp-lesson]').forEach(function(b){var on=b.dataset.spLesson===key;b.classList.toggle('is-current',on);b.classList.remove('is-playing');if(on){b.setAttribute('aria-current','true');var d=b.closest('details');if(d)d.open=true;}else b.removeAttribute('aria-current');});
   var row=sec.querySelector('[data-sp-lesson="'+key+'"]');
   if(row&&innerWidth>1024){var list=sec.querySelector('.sp-playlist');if(list){var top=row.offsetTop-list.clientHeight/2;list.scrollTo({top:top,behavior:RM?'auto':'smooth'});}}
   var title=sec.querySelector('[data-sp-lesson-title]');if(title&&row){title.textContent=row.querySelector('strong').textContent;}
   try{history.replaceState(null,'','#/learn/'+course+'/'+key);}catch(e){}
   this.api('lesson',{course:course,lesson:key}).then(function(d){
    if(seq!==self.seq)return;self.data=d;boot.resume={course:course,key:key};self.render(sec,d,autoplay);
   }).catch(function(err){
    if(seq!==self.seq)return;
    stage.innerHTML='<div class="sp-player-idle"><span class="sp-idle-ic">'+svg('retry')+'</span><strong>'+esc(err.message)+'</strong><small><button type="button" class="sp-btn sp-btn-soft sp-btn-sm" data-sp-retry>تلاش دوباره</button></small></div>';
    var r=stage.querySelector('[data-sp-retry]');if(r)r.onclick=function(){self.course='';self.load(sec,course,key,true);};
   });
  },
  render:function(sec,d,autoplay){
   var self=this,player=sec.querySelector('[data-sp-player]'),stage=sec.querySelector('[data-sp-stage]'),m=d.media||{};
   var courseTitle=sec.dataset.spCourseTitle||'',cover=sec.dataset.spCover||'';
   var title=sec.querySelector('[data-sp-lesson-title]');if(title){title.textContent=d.title;title.classList.remove('is-swap');void title.offsetWidth;title.classList.add('is-swap');}
   var meta=sec.querySelector('[data-sp-lesson-meta]');if(meta)meta.textContent=(d.module?d.module+' · ':'')+'جلسه '+fa(d.index)+' از '+fa(d.total);
   sec.querySelector('[data-sp-prev]').disabled=!d.prev;
   sec.querySelector('[data-sp-next]').disabled=false;
   this.applyProgress(this.course,d.key,{done:d.done,course:d.course});
   var origin=sec.querySelector('[data-sp-origin]');if(origin&&m.page)origin.href=m.page;
   var packBox=sec.querySelector('[data-sp-pack]');
   if(packBox){
     var pack=m.pack||{},desc=packBox.querySelector('[data-sp-pack-description]'),links=packBox.querySelector('[data-sp-pack-links]');
     desc.textContent=pack.description||'';desc.hidden=!desc.textContent.trim();
     links.replaceChildren();
     (pack.items||[]).forEach(function(it){
       if(!it||!/^https?:\/\//i.test(it.url||''))return;
       var link=document.createElement('a');link.className='sp-pack-v2-link';link.href=it.url;
       link.target='_blank';link.rel='noopener noreferrer';
       var label=document.createElement('span');label.className='sp-pack-v2-badge';
       label.textContent=({note:'جزوه',slide:'اسلاید',audio:'صوت',image:'عکس‌نوشت',summary:'خلاصه',video:'ویدئو',file:'فایل'})[it.type]||'فایل';
       var title=document.createElement('span');title.className='sp-pack-v2-label';title.textContent=it.title||'محتوای همراه';
       link.append(label,title);links.appendChild(link);
     });
     packBox.hidden=!(desc.textContent.trim()||links.childElementCount);
   }
   var files=sec.querySelector('[data-sp-files]');files.innerHTML='';(m.files||[]).forEach(function(f){var a=document.createElement('a');a.className='sp-file';a.href=f.url;a.target='_blank';a.rel='noopener';a.innerHTML=svg('file')+'<span></span>';a.querySelector('span').textContent=f.name||'فایل جلسه';files.appendChild(a);});files.hidden=!(m.files&&m.files.length);
   var notes=sec.querySelector('[data-sp-notes]'),nb=sec.querySelector('[data-sp-notes-body]');nb.innerHTML=m.html||'';notes.hidden=!m.html;notes.open=m.kind==='text';
   var kind=m.kind;
   if(kind==='hls'){var probe=document.createElement('video');kind=probe.canPlayType('application/vnd.apple.mpegurl')?'video':'link';}
   if(kind==='video'||kind==='audio'){
    var el=document.createElement(kind==='video'?'video':'audio');
    el.preload='metadata';el.src=m.src;el.setAttribute('playsinline','');el.setAttribute('webkit-playsinline','');
    if(kind==='video'&&cover)el.poster=cover;
    stage.innerHTML='';player.classList.toggle('is-audio',kind==='audio');
    if(kind==='audio'){var art=document.createElement('div');art.className='sp-audio-art';art.innerHTML='<div class="sp-audio-disc"'+(cover?' style="background-image:url(\''+encodeURI(cover).replace(/'/g,'%27')+'\')"':'')+'>'+(cover?'':svg('headphones'))+'</div>';stage.appendChild(art);}
    stage.appendChild(el);this.media=el;Controls(player,el,kind,this);
    this.watchPending=0;var saved=d.resume||parseInt(store('sp-pos-'+this.course+'-'+d.key)||'0',10);
    el.addEventListener('loadedmetadata',function(){if(saved>5&&saved<el.duration-8){el.currentTime=saved;toast('از دقیقه '+clock(saved)+' ادامه می‌دهیم.','از اول',function(){el.currentTime=0;},5200);}},{once:true});
    if(autoplay){var pr=el.play();if(pr&&pr.catch)pr.catch(function(){});}
    this.session(d,courseTitle,cover);
   } else if(kind==='embed'){
    stage.innerHTML='<iframe src="'+esc(m.src)+'" allow="autoplay; fullscreen; picture-in-picture; encrypted-media" allowfullscreen loading="lazy" title="'+esc(d.title)+'"></iframe>';
   } else {
    player.classList.add(kind==='text'?'is-text':'is-link');
    var tx=kind==='text'?'<strong>متن و منابع این جلسه زیر همین کادر آمده است.</strong><p>بعد از مطالعه، «این جلسه را دیدم» را بزنید تا پیشرفتتان ثبت شود.</p>'
     :'<strong>محتوای این جلسه در صفحه استادیار باز می‌شود.</strong><p>پس از دیدن جلسه، به اینجا برگردید و «این جلسه را دیدم» را بزنید.</p><a class="sp-btn sp-btn-main" href="'+esc(m.page)+'" target="_blank" rel="noopener">باز کردن جلسه '+svg('ext')+'</a>';
    stage.innerHTML='<div class="sp-reader"><span class="sp-empty-ic">'+svg(kind==='text'?'book':'ext')+'</span>'+tx+'</div>';
   }
  },
  session:function(d,course,cover){
   if(!('mediaSession' in navigator))return;var self=this;
   try{navigator.mediaSession.metadata=new MediaMetadata({title:d.title,artist:'شیپا · '+course,album:course,artwork:cover?[{src:cover,sizes:'512x512'}]:[]});
    var a=function(n,f){try{navigator.mediaSession.setActionHandler(n,f);}catch(e){}};
    a('play',function(){self.media&&self.media.play();});a('pause',function(){self.media&&self.media.pause();});
    a('seekbackward',function(){if(self.media)self.media.currentTime-=10;});a('seekforward',function(){if(self.media)self.media.currentTime+=10;});
    a('previoustrack',d.prev?function(){self.step(-1);}:null);a('nexttrack',d.next?function(){self.step(1);}:null);
   }catch(e){}
  },
  onEnded:function(player){
   var self=this,d=this.data;if(!d||this.ended)return;this.ended=true;
   this.save();
   var card=document.createElement('div');card.className='sp-endcard';
   if(d.next){
    card.innerHTML='<small>آفرین! این جلسه تمام شد 🌱</small><div class="sp-ring" style="--p:0"><svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18"/><circle class="sp-ring-v" cx="22" cy="22" r="18" pathLength="100" style="transition:stroke-dashoffset 6s linear"/></svg><b data-n>'+fa(6)+'</b></div><span>جلسه بعد</span><strong></strong><div class="sp-endcard-actions"><button type="button" class="sp-btn sp-btn-main sp-btn-sm" data-go>پخش الان</button><button type="button" class="sp-btn sp-btn-ghost sp-btn-sm" data-stay>همین‌جا می‌مانم</button></div>';
    card.querySelector('strong').textContent=d.nextTitle||'';
    player.appendChild(card);var ring=card.querySelector('.sp-ring'),num=card.querySelector('[data-n]'),left=6;
    requestAnimationFrame(function(){requestAnimationFrame(function(){ring.style.setProperty('--p',100);});});
    var tick=function(){left--;num.textContent=fa(Math.max(left,0));if(left<=0){if(document.visibilityState==='visible')self.step(1);}else self.endTimer=setTimeout(tick,1000);};
    this.endTimer=setTimeout(tick,1000);
    card.querySelector('[data-go]').onclick=function(){clearTimeout(self.endTimer);self.step(1);};
    card.querySelector('[data-stay]').onclick=function(){clearTimeout(self.endTimer);card.remove();};
   } else this.finishCourse(player);
  },
  finishCourse:function(player){
   player=player||(this.sec&&this.sec.querySelector('[data-sp-player]'));if(!player)return;
   var card=document.createElement('div');card.className='sp-endcard';
   card.innerHTML='<small>پایان دوره</small><strong>تبریک! همه جلسه‌های این دوره را دیدید 🌱</strong><span>یادگیری، نقطه آغاز حرکت است؛ حالا وقت به‌کار بستن است.</span><div class="sp-endcard-actions"><a class="sp-btn sp-btn-main sp-btn-sm" href="#/courses">دوره‌های من</a><button type="button" class="sp-btn sp-btn-ghost sp-btn-sm" data-stay>بستن</button></div>';
   player.appendChild(card);card.querySelector('[data-stay]').onclick=function(){card.remove();};
   if(!RM){var c=document.createElement('div');c.className='sp-confetti';var cols=['#5cb946','#a98be6','#52b9ea','#ffffff','#2c8538'];for(var i=0;i<46;i++){var p=document.createElement('i');p.style.left=Math.random()*100+'%';p.style.background=cols[i%cols.length];p.style.animationDelay=(Math.random()*.6)+'s';p.style.animationDuration=(1.8+Math.random()*1.4)+'s';c.appendChild(p);}player.appendChild(c);setTimeout(function(){c.remove();},3800);}
  }
 };

 function Controls(player,media,kind,P){
  var isV=kind==='video';
  var ui=document.createElement('div');ui.className='sp-ctl';
  ui.innerHTML='<div class="sp-seek" role="slider" tabindex="0" aria-label="جابه‌جایی در زمان جلسه" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="sp-seek-track"><div class="sp-seek-buf"></div><div class="sp-seek-fill"></div></div><div class="sp-seek-knob"></div></div>'+
   '<div class="sp-ctl-row"><button type="button" data-c="play" aria-label="پخش">'+svg('play')+'</button><button type="button" data-c="back" aria-label="۱۰ ثانیه عقب">'+svg('back10')+'</button><button type="button" data-c="fwd" aria-label="۱۰ ثانیه جلو">'+svg('fwd10')+'</button><span class="sp-time"><span data-t>۰:۰۰</span> / <span data-d>—</span></span><span class="sp-grow"></span>'+
   '<button type="button" class="sp-rate" data-c="rate" aria-label="سرعت پخش">۱×</button><button type="button" class="sp-hide-sm" data-c="mute" aria-label="بی‌صدا">'+svg('vol')+'</button>'+
   (isV&&document.pictureInPictureEnabled?'<button type="button" class="sp-hide-sm" data-c="pip" aria-label="تصویر در تصویر">'+svg('pip')+'</button>':'')+
   (isV?'<button type="button" data-c="full" aria-label="تمام‌صفحه">'+svg('full')+'</button>':'')+'</div>';
  var big=document.createElement('button');big.type='button';big.className='sp-bigplay';big.setAttribute('aria-label','پخش جلسه');big.innerHTML=svg('play');
  var buf=document.createElement('div');buf.className='sp-buffering';
  var stage=player.querySelector('[data-sp-stage]');
  if(isV){['l','r'].forEach(function(s){var z=document.createElement('div');z.className='sp-tapzone '+s;z.dataset.side=s;stage.appendChild(z);});}
  stage.appendChild(buf);stage.appendChild(big);stage.appendChild(ui);
  var seek=ui.querySelector('.sp-seek'),fill=ui.querySelector('.sp-seek-fill'),bufb=ui.querySelector('.sp-seek-buf'),knob=ui.querySelector('.sp-seek-knob'),tEl=ui.querySelector('[data-t]'),dEl=ui.querySelector('[data-d]'),playB=ui.querySelector('[data-c="play"]'),rateB=ui.querySelector('[data-c="rate"]'),muteB=ui.querySelector('[data-c="mute"]');
  var rate=parseFloat(store('sp-rate')||'1');if(RATES.indexOf(rate)<0)rate=1;media.playbackRate=rate;rateB.textContent=fa(rate)+'×';
  function toggle(){if(media.paused){var p=media.play();if(p&&p.catch)p.catch(function(){});}else media.pause();}
  function jump(s){if(!isFinite(media.duration))return;media.currentTime=Math.max(0,Math.min(media.duration-0.5,media.currentTime+s));wake();}
  function paint(){var d=media.duration||0,k=d?media.currentTime/d:0;fill.style.width=(k*100)+'%';knob.style.left=(k*100)+'%';tEl.textContent=clock(media.currentTime);seek.setAttribute('aria-valuenow',Math.round(k*100));seek.setAttribute('aria-valuetext',clock(media.currentTime));
   if(media.buffered&&media.buffered.length&&d)bufb.style.width=(media.buffered.end(media.buffered.length-1)/d*100)+'%';}
  media.addEventListener('loadedmetadata',function(){dEl.textContent=clock(media.duration);paint();});
  var lastMediaTime=null,lastWallTime=0;
  media.addEventListener('seeking',function(){lastMediaTime=null;lastWallTime=0;});
  media.addEventListener('timeupdate',function(){
   paint();var wall=Date.now(),now=media.currentTime;
   if(!media.paused&&!media.seeking&&media.readyState>=3&&!player.classList.contains('is-waiting') && lastMediaTime!==null){
    var delta=now-lastMediaTime,elapsed=(wall-lastWallTime)/1000;
    if(delta>0&&delta<=Math.min(3.5,elapsed*Math.max(1,media.playbackRate)+.65)) P.watchPending=Math.min(30,(P.watchPending||0)+delta/Math.max(1,media.playbackRate));
   }
   lastMediaTime=now;lastWallTime=wall;
   if(!media.paused&&Date.now()-P.lastSave>12000)P.save();
  });
  media.addEventListener('progress',paint);
  media.addEventListener('play',function(){player.classList.add('is-playing');playB.innerHTML=svg('pause');playB.setAttribute('aria-label','توقف');setRow(true);wake();});
  media.addEventListener('pause',function(){lastMediaTime=null;player.classList.remove('is-playing','is-idle-ui');playB.innerHTML=svg('play');playB.setAttribute('aria-label','پخش');setRow(false);if(media.currentTime>2&&!media.ended)P.save();});
  media.addEventListener('waiting',function(){lastMediaTime=null;player.classList.add('is-waiting');});
  ['playing','canplay','pause'].forEach(function(ev){media.addEventListener(ev,function(){player.classList.remove('is-waiting');});});
  media.addEventListener('ended',function(){player.classList.remove('is-playing');setRow(false);P.onEnded(player);});
  media.addEventListener('error',function(){if(P.media!==media)return;toast('پخش این فایل ممکن نشد؛ می‌توانید جلسه را در صفحه استادیار باز کنید.','باز کردن',function(){var o=P.sec.querySelector('[data-sp-origin]');if(o)window.open(o.href,'_blank','noopener');},7000);});
  function setRow(on){var r=P.sec&&P.sec.querySelector('.sp-lesson.is-current');if(r)r.classList.toggle('is-playing',on);}
  big.onclick=toggle;
  ui.addEventListener('click',function(e){var b=e.target.closest('[data-c]');if(!b)return;var c=b.dataset.c;
   if(c==='play')toggle();else if(c==='back')jump(-10);else if(c==='fwd')jump(10);
   else if(c==='rate'){rate=RATES[(RATES.indexOf(rate)+1)%RATES.length];media.playbackRate=rate;store('sp-rate',String(rate));b.textContent=fa(rate)+'×';}
   else if(c==='mute'){media.muted=!media.muted;b.innerHTML=svg(media.muted?'mute':'vol');}
   else if(c==='pip'){try{if(document.pictureInPictureElement)document.exitPictureInPicture();else media.requestPictureInPicture();}catch(err){}}
   else if(c==='full'){fullscreen();}
  });
  function fullscreen(){
   if(document.fullscreenElement){document.exitFullscreen();return;}
   if(player.requestFullscreen){player.requestFullscreen().then(function(){try{screen.orientation.lock('landscape').catch(function(){});}catch(e){}}).catch(function(){});}
   else if(media.webkitEnterFullscreen)media.webkitEnterFullscreen();
  }
  // نوار زمان
  var drag=false;
  function seekTo(e){var r=seek.getBoundingClientRect(),k=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));if(isFinite(media.duration)){media.currentTime=k*media.duration;paint();}}
  seek.addEventListener('pointerdown',function(e){drag=true;seek.classList.add('is-drag');seek.setPointerCapture(e.pointerId);seekTo(e);});
  seek.addEventListener('pointermove',function(e){if(drag)seekTo(e);});
  seek.addEventListener('pointerup',function(){drag=false;seek.classList.remove('is-drag');});
  seek.addEventListener('keydown',function(e){if(e.key==='ArrowRight'){jump(5);e.preventDefault();}if(e.key==='ArrowLeft'){jump(-5);e.preventDefault();}});
  // لمس دوبار
  var lastTap={t:0,s:''},tapT=0;
  stage.querySelectorAll('.sp-tapzone').forEach(function(z){z.addEventListener('click',function(e){
   var now=Date.now(),side=z.dataset.side;
   if(!COARSE){toggle();return;}
   if(now-lastTap.t<320&&lastTap.s===side){clearTimeout(tapT);jump(side==='r'?10:-10);var fx=document.createElement('div');fx.className='sp-tapfx '+side;fx.textContent=side==='r'?'+۱۰ ثانیه':'−۱۰ ثانیه';stage.appendChild(fx);setTimeout(function(){fx.remove();},620);lastTap.t=0;return;}
   lastTap={t:now,s:side};clearTimeout(tapT);tapT=setTimeout(function(){if(player.classList.contains('is-idle-ui'))wake();else if(!media.paused)player.classList.add('is-idle-ui');else toggle();},320);
  });});
  // پنهان شدن کنترل‌ها
  var idleT=0;function wake(){player.classList.remove('is-idle-ui');clearTimeout(idleT);if(!media.paused&&isV)idleT=setTimeout(function(){if(!media.paused&&!drag)player.classList.add('is-idle-ui');},2800);}
  player.addEventListener('pointermove',wake);player.addEventListener('focusin',wake);
  // کیبورد
  player.addEventListener('keydown',function(e){if(/input|textarea|select/i.test(e.target.tagName))return;var k=e.key.toLowerCase();
   if(k===' '||k==='k'){if(e.target.closest('button,a'))return;toggle();e.preventDefault();}
   else if(k==='arrowright'||k==='l'){if(e.target===seek)return;jump(10);e.preventDefault();}else if(k==='arrowleft'||k==='j'){if(e.target===seek)return;jump(-10);e.preventDefault();}
   else if(k==='f'&&isV){fullscreen();}else if(k==='m'){media.muted=!media.muted;if(muteB)muteB.innerHTML=svg(media.muted?'mute':'vol');}
  });
 }
 document.addEventListener('keydown',function(e){if(current!=='learn'||!Player.media||e.target.closest('input,textarea,select,[contenteditable],.sp-player'))return;if(e.key===' '&&!e.target.closest('button,a')){e.preventDefault();if(Player.media.paused)Player.media.play();else Player.media.pause();}});
 document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'&&Player.media&&Player.media.currentTime>2)Player.save(null,true);});
 addEventListener('pagehide',function(){if(Player.media&&Player.media.currentTime>2)Player.save(null,true);});

 route(true);
 requestAnimationFrame(function(){var sc=root.querySelector('.sp-screen:not([hidden])');if(sc){sc.classList.add('is-entering');animateScreen(sc);}moveIndicators();});
 setTimeout(moveIndicators,400);
}
function ready(){document.querySelectorAll('[data-sp-root]').forEach(init);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
