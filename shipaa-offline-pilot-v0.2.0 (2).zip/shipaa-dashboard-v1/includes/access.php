<?php
/**
 * SHIPAA course access — دسترسی واقعی به دوره
 * دسترسی در سه لایه هم‌زمان ثبت و بررسی می‌شود:
 *  ۱) سفارش تکمیل‌شده ووکامرس (همان چیزی که استادیار با studi_has_bought_items می‌خواند)
 *  ۲) متای کاربر _shipaa_course_access (سابقه اعطا: چه کسی، کی، از کدام سفارش)
 *  ۳) پاک‌سازی کش خرید ووکامرس تا استادیار بلافاصله دسترسی را ببیند
 */
if (!defined('ABSPATH')) exit;

final class SHIPAA_Access {
 const META='_shipaa_course_access';

 public static function boot(){
  // دروازه تأیید: سفارش دوره (از هر مسیری) تا تأیید مدیر شیپا «در انتظار بررسی» می‌ماند
  add_filter('woocommerce_payment_complete_order_status',array(__CLASS__,'hold_on_payment'),99,3);
  add_action('woocommerce_order_status_completed',array(__CLASS__,'on_paid'),5);
  add_action('woocommerce_order_status_processing',array(__CLASS__,'on_paid'),5);
  add_action('wp_ajax_shipaa_v1_gate',array(__CLASS__,'ajax_gate'));
  foreach(array('cancelled','refunded','failed') as $s) add_action('woocommerce_order_status_'.$s,array(__CLASS__,'on_void'),20);
  add_action('wp_ajax_shipaa_v1_grant_access',array(__CLASS__,'ajax_grant'));
  add_action('wp_ajax_shipaa_v1_revoke_access',array(__CLASS__,'ajax_revoke'));
 }
 public static function all($uid){ $a=get_user_meta($uid,self::META,true); return is_array($a)?$a:array(); }
 public static function has($uid,$pid){ $a=self::all($uid); return !empty($a[(int)$pid]) && empty($a[(int)$pid]['revoked']); }
 public static function course_items($order){
  $ids=array(); foreach($order->get_items('line_item') as $it){ $pid=absint($it->get_product_id()); if($pid && get_post_meta($pid,'_studiare_course',true)==='yes') $ids[]=$pid; }
  return array_values(array_unique($ids));
 }
 public static function flush($uid,$order=null){
  if(class_exists('WC_Cache_Helper')) WC_Cache_Helper::get_transient_version('orders',true);
  if($order && function_exists('wc_delete_shop_order_transients')) wc_delete_shop_order_transients($order);
  if(function_exists('clean_user_cache')) clean_user_cache($uid);
  if(function_exists('wp_cache_delete')){ wp_cache_delete($uid,'user_meta'); }
  do_action('shipaa_course_access_changed',$uid);
 }
 private static function record($uid,$pid,$source,$order_id){
  $a=self::all($uid);
  $a[(int)$pid]=array('at'=>current_time('mysql',true),'by'=>get_current_user_id(),'source'=>$source,'order'=>(int)$order_id);
  update_user_meta($uid,self::META,$a);
 }
 /** هر سفارش دوره‌ای که پرداخت/تکمیل شود، دسترسی ثبت می‌شود (از هر مسیری). */
 /* ---------- دروازه تأیید ---------- */
 public static function gate_on(){ return get_option('shipaa_require_approval','yes')!=='no' && apply_filters('shipaa_require_approval',true); }
 public static function is_approved($order){
  return $order->get_meta('_shipaa_approved')==='yes' || (string)$order->get_meta('_shipaa_receipt_approved_at')!=='' || $order->get_meta('_shipaa_manual_grant')==='yes';
 }
 public static function needs_gate($order){ return self::gate_on() && self::course_items($order) && !self::is_approved($order); }
 /** تغییر دستی وضعیت توسط مدیر در پیشخوان ووکامرس (ویرایش سفارش، دکمه تکمیل فهرست سفارش‌ها، کار گروهی) = تأیید */
 private static function admin_intent(){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce')) return false;
  if(function_exists('wp_doing_ajax') && wp_doing_ajax()) return in_array((string)($_REQUEST['action']??''),array('woocommerce_mark_order_status'),true);
  return is_admin();
 }
 public static function mark_approved($order,$via){
  $order->update_meta_data('_shipaa_approved','yes');
  $order->update_meta_data('_shipaa_approved_via',$via);
  $order->update_meta_data('_shipaa_receipt_approved_by',(int)get_current_user_id());
  $order->update_meta_data('_shipaa_receipt_approved_at',current_time('mysql',true));
  $order->delete_meta_data('_shipaa_review_state');$order->delete_meta_data('_shipaa_review_note');
  $order->save();
 }
 /** پرداخت آنلاین/صفرتومانی: به‌جای «در حال انجام/تکمیل» به «در انتظار بررسی» می‌رود */
 public static function hold_on_payment($status,$order_id,$order=null){
  $order=$order?:wc_get_order($order_id);
  if($order && in_array($status,array('processing','completed'),true) && self::needs_gate($order)){
   $order->update_meta_data('_shipaa_paid_waiting','yes');$order->save();
   if(function_exists('delete_transient')) delete_transient('shipaa_pending_count');
   return 'on-hold';
  }
  return $status;
 }
 public static function ajax_gate(){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce')) wp_send_json_error(array('message'=>'دسترسی مجاز نیست.'),403);
  if(!check_ajax_referer('shipaa_v1','nonce',false)) wp_send_json_error(array('message'=>'صفحه را تازه کنید.'),403);
  $on=(string)($_POST['on']??'')==='yes'; update_option('shipaa_require_approval',$on?'yes':'no',false);
  wp_send_json_success(array('on'=>$on,'message'=>$on?'تأیید دستی روشن شد: هیچ ثبت‌نامی بدون تأیید شما باز نمی‌شود.':'تأیید دستی خاموش شد: پرداخت موفق، دوره را خودکار باز می‌کند.'));
 }
 public static function on_paid($order_id){
  $order=wc_get_order($order_id); if(!$order) return;
  if(self::needs_gate($order)){
   if(self::admin_intent()){ self::mark_approved($order,'woocommerce'); $order->add_order_note('ثبت‌نام با تغییر وضعیت توسط مدیر در ووکامرس تأیید شد.',false); }
   else {
    // تکمیل خودکار (درگاه، افزونه دیگر، سفارش رایگان) → برگشت به بررسی؛ دسترسی باز نمی‌شود
    $order->update_meta_data('_shipaa_paid_waiting','yes');$order->save();
    $order->update_status('on-hold','پرداخت/ثبت انجام شد؛ دسترسی دوره پس از تأیید مدیر شیپا باز می‌شود.');
    $u=(int)$order->get_customer_id(); if($u){ $a=self::all($u); $ch=false; foreach(self::course_items($order) as $pid) if(isset($a[$pid])&&(int)$a[$pid]['order']===(int)$order_id){unset($a[$pid]);$ch=true;} if($ch) update_user_meta($u,self::META,$a); self::flush($u,$order); }
    if(function_exists('delete_transient')) delete_transient('shipaa_pending_count');
    return;
   }
  }
  $uid=(int)$order->get_customer_id(); if(!$uid) return;
  self::ensure_customer($order,$uid);
  $source=$order->get_meta('_shipaa_manual_grant')==='yes'?'manual':'order';
  foreach(self::course_items($order) as $pid) self::record($uid,$pid,$source,$order_id);
  self::flush($uid,$order);
 }
 public static function on_void($order_id){
  $order=wc_get_order($order_id); if(!$order) return; $uid=(int)$order->get_customer_id(); if(!$uid) return;
  $a=self::all($uid); $changed=false;
  foreach(self::course_items($order) as $pid) if(isset($a[$pid]) && (int)$a[$pid]['order']===(int)$order_id){ unset($a[$pid]); $changed=true; }
  if($changed) update_user_meta($uid,self::META,$a);
  self::flush($uid,$order);
 }
 /** ووکامرس خرید را با شناسه مشتری و ایمیل صورتحساب می‌سنجد؛ اگر خالی باشد پر می‌شود. */
 public static function ensure_customer($order,$uid){
  $u=get_userdata($uid); if(!$u) return; $dirty=false;
  if(!$order->get_billing_email()){ $order->set_billing_email($u->user_email); $dirty=true; }
  if(!$order->get_date_paid() && in_array($order->get_status(),array('completed','processing'),true)){ $order->set_date_paid(time()); $dirty=true; }
  if($dirty) $order->save();
 }
 /** گزارش راستی‌آزمایی: استادیار، ووکامرس، شیپا */
 public static function verify($uid,$pid){
  $st=function_exists('studi_has_bought_items')?in_array(studi_has_bought_items($uid,$pid),array(true,1,'1','true'),true):null;
  $u=get_userdata($uid);
  $wc=($u && function_exists('wc_customer_bought_product'))?(bool)wc_customer_bought_product($u->user_email,$uid,$pid):null;
  return array('studiare'=>$st,'woo'=>$wc,'shipaa'=>self::has($uid,$pid)||$st===true||$wc===true); // پلیر شیپا هر سه منبع را می‌پذیرد
 }
 public static function verify_text($v){
  if($v['studiare']===true||($v['studiare']===null&&$v['woo']===true)) return array('ok',"دسترسی در استادیار فعال است ✓");
  if($v['woo']===true) return array('warn','سفارش در ووکامرس ثبت شد ولی استادیار هنوز دسترسی را نمی‌بیند؛ کش سایت را پاک کنید و دوباره بررسی کنید.');
  return array('warn','دسترسی در پلیر شیپا باز است؛ استادیار هنوز خرید را تشخیص نمی‌دهد.');
 }
 /** اعطای دستی: یک سفارش صفرتومانی واقعی ووکامرس ساخته و تکمیل می‌شود تا استادیار هم آن را بشناسد. */
 public static function grant_manual($uid,$pid,$note=''){
  $product=function_exists('wc_get_product')?wc_get_product($pid):null;
  if(!$product || get_post_meta($pid,'_studiare_course',true)!=='yes') return new WP_Error('bad','این دوره پیدا نشد.');
  $u=get_userdata($uid); if(!$u) return new WP_Error('bad','مخاطب پیدا نشد.');
  $order=wc_create_order(array('customer_id'=>$uid,'created_via'=>'shipaa_manual_grant'));
  if(is_wp_error($order)) return $order;
  $order->add_product($product,1,array('subtotal'=>0,'total'=>0));
  $order->set_billing_email($u->user_email);
  $order->set_billing_first_name((string)get_user_meta($uid,'first_name',true));
  $order->set_billing_last_name((string)get_user_meta($uid,'last_name',true));
  $order->set_billing_phone((string)get_user_meta($uid,'billing_phone',true));
  $order->update_meta_data('_shipaa_manual_grant','yes');
  $order->update_meta_data('_shipaa300','yes');
  $order->set_date_paid(time());
  $order->calculate_totals(false);
  $order->save();
  $order->update_status('completed','دسترسی دستی دوره توسط مدیر شیپا'.($note?': '.$note:'').'.',true);
  self::on_paid($order->get_id());
  return $order;
 }
 private static function guard(){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce')) wp_send_json_error(array('message'=>'دسترسی مجاز نیست.'),403);
  if(!check_ajax_referer('shipaa_v1','nonce',false)) wp_send_json_error(array('message'=>'اعتبار صفحه منقضی شده؛ صفحه را تازه کنید.'),403);
  $uid=absint($_POST['user_id']??0); $pid=absint($_POST['course']??0);
  if(!$uid||!get_userdata($uid)) wp_send_json_error(array('message'=>'مخاطب پیدا نشد.'),404);
  if(!$pid||get_post_meta($pid,'_studiare_course',true)!=='yes') wp_send_json_error(array('message'=>'دوره را انتخاب کنید.'),400);
  return array($uid,$pid);
 }
 public static function ajax_grant(){
  list($uid,$pid)=self::guard();
  $v=self::verify($uid,$pid);
  if($v['studiare']===true) wp_send_json_error(array('message'=>'این مخاطب از قبل به این دوره دسترسی دارد.'),409);
  $r=self::grant_manual($uid,$pid,sanitize_text_field(wp_unslash($_POST['note']??'')));
  if(is_wp_error($r)) wp_send_json_error(array('message'=>$r->get_error_message()),400);
  $t=self::verify_text(self::verify($uid,$pid));
  SHIPAA_Admin_Dossier_V13::log($uid,'access','اعطای دسترسی دستی: '.get_the_title($pid).' (سفارش #'.$r->get_id().')');
  wp_send_json_success(array('message'=>'دسترسی داده شد. '.$t[1],'tone'=>$t[0],'html'=>SHIPAA_Admin_Dossier_V13::dossier_html($uid)));
 }
 /** لغو: سفارش‌های تکمیل‌شده همان دوره برای این مخاطب «لغو» می‌شوند (با یادداشت). */
 public static function ajax_revoke(){
  list($uid,$pid)=self::guard();
  if((string)($_POST['confirmed']??'')!=='yes') wp_send_json_error(array('message'=>'لغو دسترسی باید صریحاً تأیید شود.'),400);
  $orders=wc_get_orders(array('customer'=>$uid,'status'=>array('completed','processing'),'limit'=>50));
  $n=0; foreach($orders as $o){ if(in_array($pid,self::course_items($o),true)){ $o->update_status('cancelled','لغو دسترسی دوره «'.get_the_title($pid).'» توسط مدیر شیپا.',true); $n++; } }
  $a=self::all($uid); unset($a[$pid]); update_user_meta($uid,self::META,$a); self::flush($uid);
  SHIPAA_Admin_Dossier_V13::log($uid,'access','لغو دسترسی: '.get_the_title($pid).($n?' ('.$n.' سفارش لغو شد)':''));
  wp_send_json_success(array('message'=>'دسترسی لغو شد'.($n?' و '.number_format_i18n($n).' سفارش به «لغو شده» تغییر کرد.':'.'),'html'=>SHIPAA_Admin_Dossier_V13::dossier_html($uid)));
 }
}
SHIPAA_Access::boot();
