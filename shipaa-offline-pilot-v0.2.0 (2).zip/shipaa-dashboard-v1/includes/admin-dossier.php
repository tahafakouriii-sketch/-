<?php
/** SHIPAA dossier — admin-only user information and decisions on Woo orders. */
if (!defined('ABSPATH')) exit;
final class SHIPAA_Admin_Dossier_V13 {
 const MAX_ORDERS = 40;
 const MAX_EVENTS = 80;
 public static function boot(){
  add_action('wp_ajax_shipaa_v1_dossier', array(__CLASS__,'ajax_dossier'));
  add_action('wp_ajax_shipaa_v1_people_search',array(__CLASS__,'ajax_search'));
  add_action('wp_ajax_shipaa_v1_save_profile',array(__CLASS__,'ajax_save_profile'));
  add_action('wp_ajax_shipaa_v1_add_note',array(__CLASS__,'ajax_add_note'));
 }
 private static function guard(){
  if(!is_user_logged_in() || !current_user_can('manage_woocommerce'))wp_send_json_error(array('message'=>'دسترسی به پرونده مخاطبان مجاز نیست.'),403);
  if(!check_ajax_referer('shipaa_v1','nonce',false))wp_send_json_error(array('message'=>'جلسه شما منقضی شده است؛ صفحه را تازه‌سازی کنید.'),403);
 }
 private static function user_from_request(){
  $uid=absint($_POST['user_id']??0);
  $u=$uid?get_userdata($uid):false;
  if(!$u)wp_send_json_error(array('message'=>'این مخاطب پیدا نشد.'),404);
  return $u;
 }
 private static function tr($value){return trim((string)$value);}
 private static function char_len($value){return function_exists('mb_strlen')?mb_strlen((string)$value,'UTF-8'):preg_match_all('/./us',(string)$value);}
 private static function date_text($raw){
  if(!$raw)return '—';
  $ts=is_numeric($raw)?(int)$raw:strtotime((string)$raw);
  return $ts?wp_date('Y/m/d', $ts):'—';
 }
 private static function phone($uid){
  $phone=self::tr(get_user_meta($uid,'billing_phone',true));
  if(!$phone)$phone=self::tr(get_user_meta($uid,'phone',true));
  return $phone;
 }
 private static function course_ids(){
  return get_posts(array('post_type'=>'product','post_status'=>'publish','posts_per_page'=>200,'fields'=>'ids','no_found_rows'=>true,'meta_query'=>array(array('key'=>'_studiare_course','value'=>'yes'))));
 }
 private static function enrolled($uid,$pid){
  if(class_exists('SHIPAA_Access') && SHIPAA_Access::has($uid,$pid))return true;
  if(function_exists('studi_has_bought_items') && in_array(studi_has_bought_items($uid,$pid),array(true,1,'1','true'),true))return true;
  $u=get_userdata($uid);
  return (bool)($u && function_exists('wc_customer_bought_product') && wc_customer_bought_product($u->user_email,$uid,$pid));
 }
 private static function order_courses($order){
  $ids=array();foreach($order->get_items('line_item') as $item){
   $pid=absint($item->get_product_id());
   if($pid && get_post_meta($pid,'_studiare_course',true)==='yes')$ids[$pid]=true;
  }
  return array_keys($ids);
 }
 private static function reviewable($order,$uid){
  return $order && $order->get_customer_id()===$uid &&
   in_array($order->get_status(),array('on-hold','pending'),true) && count(self::order_courses($order))>0;
 }
 private static function get_orders($uid){
  return function_exists('wc_get_orders')?wc_get_orders(array('customer'=>$uid,'limit'=>self::MAX_ORDERS,'orderby'=>'date','order'=>'DESC')):array();
 }
 private static function status($order){
  if(in_array($order->get_status(),array('pending','on-hold'),true)){
   return $order->get_meta('_shipaa_review_state')==='needs_changes'?'نیازمند اصلاح':'در انتظار بررسی';
  }
  return wc_get_order_status_name($order->get_status());
 }
 private static function orders_for_course($orders,$pid){
  foreach($orders as $o)if(in_array((int)$pid,self::order_courses($o),true))return $o;
  return null;
 }
 private static function event_items($uid){
  $events=get_user_meta($uid,'_shipaa_v1_activity',true);
  return is_array($events)?array_slice($events,-self::MAX_EVENTS):array();
 }
 private static function add_event($uid,$type,$message){
  $events=self::event_items($uid);
  $events[]=array('type'=>$type,'text'=>$message,'actor'=>get_current_user_id(),'at'=>current_time('mysql',true));
  update_user_meta($uid,'_shipaa_v1_activity',array_slice($events,-self::MAX_EVENTS));
 }
 public static function log($uid,$type,$msg){ self::add_event((int)$uid,$type,$msg); }
 public static function dossier_html($uid){ return self::render_dossier(get_userdata((int)$uid)); }
 public static function people_html(){
  $users=get_users(array('number'=>24,'orderby'=>'registered','order'=>'DESC'));
  ob_start();?>
  <div class="sd13-listhead"><div><span class="sd13-eyebrow">بانک اعضای شیپا</span><h2 class="sv-heading">مخاطبان</h2><p class="sv-intro">مرتب‌سازی: جدیدترین ثبت‌نام ابتدا؛ تاریخ عضویت و شناسه هر مخاطب مشخص است. نام، ایمیل یا شماره تماس را جست‌وجو کن.</p></div><div class="sd13-list-count">آخرین حساب‌ها</div></div>
  <label class="sd13-searchwrap"><span aria-hidden="true">⌕</span><input class="sv-search" type="search" autocomplete="off" data-dossier-search placeholder="جست‌وجوی نام، ایمیل یا تلفن…" aria-label="جست‌وجوی مخاطبان"><span data-dossier-search-status class="sd13-search-status" aria-live="polite"></span></label>
  <div class="sv-list sd13-people-list" data-dossier-people><?php echo self::render_people($users);?></div>
  <p class="sd13-tip">اطلاعات فقط برای مدیران مجاز نمایش داده می‌شود. ویرایش مشخصات به مجوز ویرایش کاربر نیاز دارد.</p>
  <?php return ob_get_clean();
 }
 private static function render_people($users){
  if(!$users)return '<div class="sd13-empty"><strong>مخاطبی با این مشخصات پیدا نشد.</strong><p>عبارت دیگری یا بخشی از شماره تماس را امتحان کن.</p></div>';
  ob_start();$rank=0;foreach($users as $u):$rank++;$uid=(int)$u->ID;$phone=self::phone($uid);$initial=function_exists('mb_substr')?mb_substr($u->display_name,0,1):substr($u->display_name,0,1);?>
  <div class="sv-listitem sd13-person"><span class="sd13-person-rank"><?php echo esc_html(number_format_i18n($rank));?></span><?php echo SHIPAA_Dashboard_Avatar180::admin_avatar($uid,44,$initial);?><div class="sd13-person-info"><strong><?php echo esc_html($u->display_name);?></strong><small><?php echo esc_html($phone?:$u->user_email);?></small><small>عضویت: <?php echo esc_html(self::date_text($u->user_registered));?> · شناسه <?php echo esc_html($uid);?></small></div><button type="button" class="sv-button sv-secondary sd13-open" data-person-id="<?php echo esc_attr($uid);?>" aria-haspopup="dialog">مشاهده پرونده <span aria-hidden="true">←</span></button></div>
  <?php endforeach;return ob_get_clean();
 }
 public static function modal(){
  return '<div class="sd13-layer" data-drawer hidden><div class="sd13-backdrop" data-close-drawer aria-hidden="true"></div><div class="sd13-drawer" role="dialog" aria-modal="true" aria-label="پرونده مخاطب" tabindex="-1" data-drawer-shell><div class="sd13-drawer-frame"><div class="sd13-drawer-top"><span><span class="sd13-dot"></span> پرونده مخاطب شیپا</span><button class="sd13-close" data-close-drawer type="button" aria-label="بستن پرونده">×</button></div><div data-drawer-content><div class="sd13-loading">در حال دریافت پرونده…</div></div></div></div><div class="sd13-confirm" data-dossier-confirm hidden role="alertdialog" aria-modal="true" aria-label="تأیید عملیات"><div class="sd13-confirm-card"><h3 data-confirm-title></h3><p data-confirm-desc></p><label class="sd13-check" data-confirm-check-wrap><input type="checkbox" data-confirm-check> <span data-confirm-check-text>تأیید می‌کنم که رسید و مبلغ پرداخت را مستقلاً بررسی کرده‌ام.</span></label><label class="sd13-note-field" data-confirm-note-wrap hidden>دلیل نیاز به اصلاح<textarea data-confirm-note rows="3" maxlength="600" placeholder="توضیح ضروری برای پیگیری…"></textarea></label><label class="sd13-check sv-check-soft" data-confirm-share-wrap hidden><input type="checkbox" data-confirm-share checked> <span>این توضیح در صفحه ثبت‌نام‌های مخاطب هم نمایش داده شود.</span></label><div class="sd13-confirm-actions"><button type="button" class="sd13-action" data-confirm-submit>ثبت تصمیم</button><button type="button" class="sd13-link" data-confirm-cancel>انصراف</button></div></div></div></div>';
 }
 public static function ajax_search(){
  self::guard();$query=sanitize_text_field(wp_unslash($_POST['q']??''));$query=trim($query);$users=array();
  if($query===''){$users=get_users(array('number'=>24,'orderby'=>'registered','order'=>'DESC'));}
  elseif(self::char_len($query)>=2 && self::char_len($query)<=70){
   $users=get_users(array('number'=>24,'search'=>'*'.esc_attr($query).'*','search_columns'=>array('user_login','user_email','display_name'),'orderby'=>'registered','order'=>'DESC'));
   if(count($users)<24){
    $phone_matches=get_users(array('number'=>24,'meta_query'=>array(array('key'=>'billing_phone','value'=>$query,'compare'=>'LIKE'))));
    $existing=array();foreach($users as $u)$existing[(int)$u->ID]=true;
    foreach($phone_matches as $u)if(!isset($existing[(int)$u->ID])){$users[]=$u;$existing[(int)$u->ID]=true;if(count($users)>=24)break;}
   }
  }
  wp_send_json_success(array('html'=>self::render_people($users),'count'=>count($users)));
 }
 public static function ajax_dossier(){
  self::guard();$u=self::user_from_request();wp_send_json_success(array('html'=>self::render_dossier($u)));
 }
 private static function render_dossier($u){
  $uid=(int)$u->ID;$orders=self::get_orders($uid);$courses=self::course_ids();$active=array();$pending=array();$other=array();
  foreach($courses as $pid){
   if(self::enrolled($uid,$pid))$active[$pid]=get_the_title($pid);
   else { $o=self::orders_for_course($orders,$pid);if($o && in_array($o->get_status(),array('pending','on-hold'),true))$pending[$pid]=get_the_title($pid); }
  }
  foreach($orders as $o)if(self::reviewable($o,$uid))$other[]=$o;
  $initial=function_exists('mb_substr')?mb_substr($u->display_name,0,1):substr($u->display_name,0,1);
  $editable=current_user_can('edit_user',$uid);
  $phone=self::phone($uid);
  ob_start();?><div class="sd13-content" data-dossier-uid="<?php echo esc_attr($uid);?>">
   <div class="sd13-identity"><?php echo SHIPAA_Dashboard_Avatar180::admin_avatar($uid,64,$initial);?><div class="sd13-identity-main"><h2><?php echo esc_html($u->display_name);?></h2><span>عضو شیپا از <?php echo esc_html(self::date_text($u->user_registered));?> · شناسه <?php echo esc_html($uid);?></span></div><span class="sd13-identity-mark">عضو شیپا</span></div>
   <?php if($other):$o=$other[0];?><div class="sd13-attention"><div class="sd13-attention-head"><span class="sd13-label-warning">نیازمند بررسی</span><span class="sd13-muted">سفارش #<?php echo esc_html($o->get_id());?></span></div><strong><?php echo esc_html(self::order_titles($o));?></strong><p>رسید را در ایتا و سوابق پرداخت بررسی کن؛ ثبت سفارش به معنی پرداخت قطعی نیست.</p><button type="button" class="sd13-action" data-dossier-open-order="<?php echo esc_attr($o->get_id());?>">بررسی ثبت‌نام <span aria-hidden="true">←</span></button></div><?php endif;?>
   <?php
   $watch_data=class_exists('SHIPAA_Studiare')?SHIPAA_Studiare::progress($uid):array();
   $watch_total=0;$watch_done=0;
   foreach($watch_data as $wc){foreach(($wc['lessons']??array()) as $wl){$watch_total+=(int)($wl['watched']??0);if(!empty($wl['done']))$watch_done++;}}
   ?>
   <div class="sd13-watch-summary"><strong>گزارش تماشای ثبت‌شده</strong><span><?php echo esc_html(number_format_i18n(intdiv($watch_total,60)));?> دقیقه پخش ثبت‌شده · <?php echo esc_html(number_format_i18n($watch_done));?> جلسه دیده‌شده</span><small>زمان‌سنجی از نسخه جدید آغاز می‌شود؛ مشاهده‌های گذشته زمان قابل‌اندازه‌گیری ندارند. ارقام تخمین پخش هستند، نه اثبات حضور یا توجه.</small></div>
   <div class="sd13-metrics"><div><strong><?php echo esc_html(number_format_i18n(count($active)));?></strong><span>دوره فعال</span></div><div><strong><?php echo esc_html(number_format_i18n(count($pending)));?></strong><span>در انتظار</span></div><div><strong><?php echo esc_html(number_format_i18n(count($orders)));?></strong><span>سفارش اخیر</span></div></div>
   <div class="sd13-tabs" role="tablist" aria-label="بخش‌های پرونده"><button type="button" data-dossier-tab="overview" role="tab" aria-selected="true">نمای کلی</button><button type="button" data-dossier-tab="courses" role="tab" aria-selected="false">دوره‌ها</button><button type="button" data-dossier-tab="orders" role="tab" aria-selected="false">سفارش‌ها</button><button type="button" data-dossier-tab="history" role="tab" aria-selected="false">سوابق</button></div>
   <section data-dossier-view="overview" role="tabpanel" class="sd13-view"><div class="sd13-sectionhead"><h3>اطلاعات فردی</h3><?php if($editable):?><button type="button" class="sd13-link" data-dossier-edit aria-expanded="false">ویرایش اطلاعات</button><?php endif;?></div><div class="sd13-info-grid"><div><small>شماره تماس</small><strong><?php echo esc_html($phone?:'ثبت نشده');?></strong><?php if($phone):?><button type="button" class="sd13-inline-copy" data-dossier-copy="<?php echo esc_attr($phone);?>">کپی شماره</button><?php endif;?></div><div><small>ایمیل</small><strong dir="ltr"><?php echo esc_html($u->user_email);?></strong></div><div><small>نام و نام خانوادگی</small><strong><?php echo esc_html(trim(self::tr(get_user_meta($uid,'first_name',true)).' '.self::tr(get_user_meta($uid,'last_name',true)))?:'ثبت نشده');?></strong></div><div><small>تاریخ عضویت</small><strong><?php echo esc_html(self::date_text($u->user_registered));?></strong></div></div>
    <?php if($editable):?><form class="sd13-edit-form" data-dossier-edit-form hidden><div class="sd13-form-grid"><label>نام نمایشی<input name="display_name" required maxlength="90" value="<?php echo esc_attr($u->display_name);?>"></label><label>نام<input name="first_name" maxlength="65" value="<?php echo esc_attr(get_user_meta($uid,'first_name',true));?>"></label><label>نام خانوادگی<input name="last_name" maxlength="65" value="<?php echo esc_attr(get_user_meta($uid,'last_name',true));?>"></label><label>تلفن<input name="billing_phone" maxlength="20" inputmode="tel" dir="ltr" value="<?php echo esc_attr($phone);?>"></label></div><div class="sd13-form-actions"><button type="submit" class="sd13-action">ذخیره اطلاعات</button><button type="button" class="sd13-link" data-dossier-cancel-edit>انصراف</button></div></form><?php endif;?>
    <div class="sd13-sectionhead"><h3>راه‌های ارتباط</h3></div><div class="sd13-contact"><span>برای گفت‌وگو و رسیدها از حساب پشتیبانی شیپا در ایتا استفاده می‌شود.</span><a href="https://eitaa.com/shipaa_admin" target="_blank" rel="noopener noreferrer">بازکردن پشتیبانی ↗</a></div>
   </section>
   <section data-dossier-view="courses" role="tabpanel" class="sd13-view" hidden>
    <div class="sd13-sectionhead"><h3>دوره‌ها و دسترسی واقعی</h3><small>استادیار · ووکامرس · شیپا</small></div>
    <?php $all_courses=self::course_ids(); $shown=0; foreach($all_courses as $pid): $v=class_exists('SHIPAA_Access')?SHIPAA_Access::verify($uid,$pid):array('studiare'=>null,'woo'=>null,'shipaa'=>false); $is_on=($v['studiare']===true)||($v['studiare']===null&&$v['woo']===true)||$v['shipaa']; $is_wait=isset($pending[$pid]); if(!$is_on && !$is_wait) continue; $shown++; ?>
     <div class="sd13-course <?php echo $is_on?'is-on':'is-wait';?>">
      <span class="sd13-course-icon"><?php echo $is_on?'✓':'◷';?></span>
      <div><strong><?php echo esc_html(get_the_title($pid));?></strong>
       <?php $watch_cp=class_exists('SHIPAA_Studiare')?SHIPAA_Studiare::course_progress($uid,$pid):null;if($watch_cp){$watch_sec=0;foreach($watch_cp['lessons'] as $wl)$watch_sec+=(int)($wl['watched']??0);?><small class="sd13-watch-course">پیشرفت: <?php echo esc_html(number_format_i18n($watch_cp['percent']));?>٪ · زمان پخش ثبت‌شده: <?php echo esc_html(number_format_i18n(intdiv($watch_sec,60)));?> دقیقه</small><?php }?><span class="sd13-checks"><?php foreach(array('studiare'=>'استادیار','woo'=>'ووکامرس','shipaa'=>'پلیر شیپا') as $k=>$lbl): $val=$v[$k]; ?><i class="<?php echo $val===true?'ok':($val===null?'na':'no');?>"><?php echo esc_html($lbl);?></i><?php endforeach;?></span>
      </div>
      <?php if($is_on):?><button type="button" class="sd13-link sd13-danger" data-dossier-revoke="<?php echo esc_attr($pid);?>" data-course-title="<?php echo esc_attr(get_the_title($pid));?>">لغو دسترسی</button>
      <?php else:?><span class="sd13-wait">منتظر تأیید سفارش</span><?php endif;?>
     </div>
    <?php endforeach; if(!$shown):?><div class="sd13-empty"><strong>هنوز دوره‌ای برای این مخاطب باز نشده است.</strong><p>از کادر زیر می‌توانید دسترسی را مستقیم بدهید.</p></div><?php endif;?>
    <form class="sd13-grant" data-dossier-grant-form>
     <label for="sd13-grant-<?php echo esc_attr($uid);?>">اعطای دسترسی مستقیم</label>
     <div class="sd13-grant-row"><select id="sd13-grant-<?php echo esc_attr($uid);?>" name="course" required><option value="">انتخاب دوره…</option><?php foreach($all_courses as $pid): if(isset($active[$pid])) continue; ?><option value="<?php echo esc_attr($pid);?>"><?php echo esc_html(get_the_title($pid));?></option><?php endforeach;?></select><button type="submit" class="sd13-action">باز کردن دوره</button></div>
     <small>یک سفارش صفرتومانی تکمیل‌شده با برچسب «دسترسی دستی» ساخته می‌شود؛ استادیار، ووکامرس و پلیر شیپا هر سه همان لحظه دسترسی را می‌شناسند.</small>
    </form>
   </section>
   <section data-dossier-view="orders" role="tabpanel" class="sd13-view" hidden><div class="sd13-sectionhead"><h3>سفارش‌ها و تصمیم‌ها</h3><small>حداکثر <?php echo esc_html(self::MAX_ORDERS);?> سفارش اخیر</small></div><?php if(!$orders):?><div class="sd13-empty"><strong>هنوز سفارشی ثبت نشده است.</strong></div><?php endif;?><?php foreach($orders as $order):$oid=$order->get_id();$allowed=self::reviewable($order,$uid);?><article class="sd13-order" data-dossier-order="<?php echo esc_attr($oid);?>"><div class="sd13-order-head"><div><strong>سفارش #<?php echo esc_html($oid);?></strong><small><?php echo esc_html(self::order_titles($order));?></small></div><span class="<?php echo $allowed?'sd13-wait':'sd13-state';?>"><?php echo esc_html(self::status($order));?></span></div><div class="sd13-order-meta"><span><?php echo wp_kses_post($order->get_formatted_order_total());?></span><span><?php echo $order->get_date_created()?esc_html(wc_format_datetime($order->get_date_created())):'—';?></span></div><?php if($allowed):?><div class="sd13-order-actions"><button type="button" class="sd13-action" data-dossier-approve="<?php echo esc_attr($oid);?>">تأیید رسید</button><button type="button" class="sd13-link" data-dossier-revise="<?php echo esc_attr($oid);?>">نیازمند اصلاح</button></div><?php endif;?></article><?php endforeach;?><p class="sd13-tip">تأیید رسید باعث تکمیل سفارش در ووکامرس می‌شود. تنها پس از بررسی مستقل رسید و اطمینان از مبلغ صحیح تأیید کن.</p></section>
   <section data-dossier-view="history" role="tabpanel" class="sd13-view" hidden><div class="sd13-sectionhead"><h3>یادداشت‌ها و سوابق مدیریتی</h3></div><form data-dossier-note-form class="sd13-note-form"><label for="sd13-note-<?php echo esc_attr($uid);?>">یادداشت داخلی مدیر</label><textarea id="sd13-note-<?php echo esc_attr($uid);?>" name="note" rows="3" maxlength="600" required placeholder="نتیجه تماس، پیگیری یا توضیح کوتاه…"></textarea><button type="submit" class="sd13-action">ثبت یادداشت</button><small>این یادداشت فقط برای مدیران مجاز است.</small></form><div class="sd13-timeline"><?php echo self::render_events($uid,$orders);?></div></section>
  </div><?php return ob_get_clean();
 }
 private static function order_titles($order){
  $titles=array();foreach($order->get_items('line_item') as $item)$titles[]=$item->get_name();
  return $titles?implode('، ',$titles):'بدون عنوان دوره';
 }
 private static function render_events($uid,$orders){
  $entries=array();foreach(self::event_items($uid) as $ev){if(!is_array($ev)||empty($ev['at']))continue;$entries[]=array('t'=>strtotime($ev['at']),'actor'=>(int)($ev['actor']??0),'text'=>(string)($ev['text']??''),'kind'=>(string)($ev['type']??''));}
  foreach(array_slice($orders,0,15) as $order){
   if($order->get_meta('_shipaa_receipt_approved_at'))$entries[]=array('t'=>strtotime($order->get_meta('_shipaa_receipt_approved_at')),'actor'=>(int)$order->get_meta('_shipaa_receipt_approved_by'),'text'=>'تأیید رسید سفارش #'.$order->get_id(),'kind'=>'approve');
   if(function_exists('wc_get_order_notes')){
    $notes=wc_get_order_notes(array('order_id'=>$order->get_id(),'limit'=>8,'type'=>'internal'));
    foreach($notes as $note)if(strpos((string)$note->content,'نیازمند اصلاح / توسط مدیر:')!==false){$entries[]=array('t'=>$note->date_created?$note->date_created->getTimestamp():0,'actor'=>(int)$note->added_by_user,'text'=>'پیگیری سفارش #'.$order->get_id().' — '.wp_strip_all_tags($note->content),'kind'=>'order');}
   }
  }
  usort($entries,function($a,$b){return $b['t']<=>$a['t'];});
  if(!$entries)return '<div class="sd13-empty"><strong>هنوز یادداشت مدیریتی ثبت نشده است.</strong><p>اقدام‌های جدید و یادداشت‌ها در این قسمت ثبت می‌شوند.</p></div>';
  ob_start();foreach(array_slice($entries,0,35) as $ev){$actor=$ev['actor']?get_userdata($ev['actor']):false;?><div class="sd13-event"><span class="sd13-event-mark"></span><div><strong><?php echo esc_html($ev['text']);?></strong><small><?php echo esc_html($ev['t']?wp_date('Y/m/d H:i',$ev['t']):'—');?> · <?php echo esc_html($actor?$actor->display_name:'سامانه/مدیر');?></small></div></div><?php }return ob_get_clean();
 }
 public static function ajax_save_profile(){
  self::guard();$u=self::user_from_request();$uid=(int)$u->ID;
  if(!current_user_can('edit_user',$uid))wp_send_json_error(array('message'=>'مجوز ویرایش این حساب را ندارید.'),403);
  $display=sanitize_text_field(wp_unslash($_POST['display_name']??''));$first=sanitize_text_field(wp_unslash($_POST['first_name']??''));$last=sanitize_text_field(wp_unslash($_POST['last_name']??''));$phone=sanitize_text_field(wp_unslash($_POST['billing_phone']??''));
  if(!$display || self::char_len($display)>90 || self::char_len($first)>65 || self::char_len($last)>65)wp_send_json_error(array('message'=>'نام نمایشی و محدودیت طول نام‌ها را بررسی کنید.'),400);
  $phone=strtr($phone,array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));
  if($phone!=='' && (!preg_match('/^[+0-9()\-\s]{8,20}$/',$phone)))wp_send_json_error(array('message'=>'قالب شماره تلفن معتبر نیست.'),400);
  $changes=array();if($display!==$u->display_name)$changes[]='نام نمایشی';
  foreach(array('first_name'=>$first,'last_name'=>$last,'billing_phone'=>$phone) as $key=>$val){if(self::tr(get_user_meta($uid,$key,true))!==$val)$changes[]=$key==='billing_phone'?'تلفن':($key==='first_name'?'نام':'نام خانوادگی');}
  $result=wp_update_user(array('ID'=>$uid,'display_name'=>$display,'first_name'=>$first,'last_name'=>$last));
  if(is_wp_error($result))wp_send_json_error(array('message'=>'اطلاعات حساب ذخیره نشد: '.$result->get_error_message()),500);
  update_user_meta($uid,'billing_phone',$phone);
  if($changes)self::add_event($uid,'profile','ویرایش اطلاعات حساب: '.implode('، ',$changes));
  wp_send_json_success(array('message'=>'اطلاعات مخاطب ذخیره شد.','html'=>self::render_dossier(get_userdata($uid))));
 }
 public static function ajax_add_note(){
  self::guard();$u=self::user_from_request();$note=sanitize_textarea_field(wp_unslash($_POST['note']??''));
  if(self::char_len($note)<3 || self::char_len($note)>600)wp_send_json_error(array('message'=>'متن یادداشت باید بین ۳ تا ۶۰۰ نویسه باشد.'),400);
  self::add_event((int)$u->ID,'note',$note);
  wp_send_json_success(array('message'=>'یادداشت داخلی ثبت شد.','html'=>self::render_dossier($u)));
 }
}
SHIPAA_Admin_Dossier_V13::boot();
