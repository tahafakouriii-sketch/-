<?php
/** Shared learner/manager image integration; retains existing Shipaa profile storage. */
if (!defined('ABSPATH')) exit;
final class SHIPAA_Dashboard_Avatar180 {
 public static function boot(){
  add_action('wp_ajax_shipaa_avatar180_upload',array(__CLASS__,'upload'));
  add_action('wp_ajax_shipaa_avatar180_remove',array(__CLASS__,'remove'));
  add_filter('get_avatar_url',array(__CLASS__,'wp_avatar'),20,3);
  add_filter('manage_users_columns',array(__CLASS__,'column'));
  add_filter('manage_users_custom_column',array(__CLASS__,'column_content'),10,3);
  add_action('show_user_profile',array(__CLASS__,'admin_profile'));
  add_action('edit_user_profile',array(__CLASS__,'admin_profile'));
 }
 public static function url($uid,$size=96){
  $uid=absint($uid);
  if(!$uid)return '';
  return SHIPAA_Profile_Integrated::avatar_url($uid,$size);
 }
 public static function admin_avatar($uid,$size=44,$initial=''){
  $src=self::url($uid,$size);
  if($src)return '<span class="sd13-avatar sd13-avatar-photo'.($size>44?' sd13-avatar-lg':'').'"><img alt="تصویر مخاطب" src="'.esc_url($src).'" loading="lazy" decoding="async"></span>';
  $gen=get_user_meta($uid,'shipaa_gender',true);
  $initial=$gen==='زن'?'👩':($gen==='مرد'?'👨':($initial?:'👤'));
  return '<span class="sd13-avatar'.($size>44?' sd13-avatar-lg':'').'" role="img" aria-label="آواتار پیش‌فرض">'.esc_html($initial).'</span>';
 }
 public static function wp_avatar($url,$id_or_email,$args){
  $uid=0;
  if(is_numeric($id_or_email))$uid=absint($id_or_email);
  elseif($id_or_email instanceof WP_User)$uid=$id_or_email->ID;
  elseif($id_or_email instanceof WP_Comment)$uid=absint($id_or_email->user_id);
  elseif(is_string($id_or_email)&&is_email($id_or_email)){$u=get_user_by('email',$id_or_email);if($u)$uid=$u->ID;}
  if(!$uid)return $url;
  return self::url($uid,absint($args['size']??96))?:$url;
 }
 public static function column($cols){$cols['shipaa_photo']='تصویر';return $cols;}
 public static function column_content($out,$key,$user_id){
  if($key!=='shipaa_photo')return $out;
  $url=self::url($user_id,48);
  if(!$url)return '<span title="تصویر بارگذاری نشده">—</span>';
  return '<img src="'.esc_url($url).'" alt="تصویر مخاطب" loading="lazy" style="width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid #a4d67b">';
 }
 public static function admin_profile($u){
  if(!($u instanceof WP_User)||!current_user_can('edit_user',$u->ID))return;
  echo '<h2>تصویر مخاطب در شیپا</h2><p>همان تصویر بارگذاری‌شده در داشبورد شخصی؛ بدون نیاز به بارگذاری دوباره.</p><p>'.self::admin_avatar($u->ID,64).'</p>';
 }
 private static function guard(){
  if(!is_user_logged_in())wp_send_json_error(array('message'=>'برای ادامه وارد حساب شوید.'),401);
  if(!check_ajax_referer('shipaa_avatar180','nonce',false))wp_send_json_error(array('message'=>'نشست به پایان رسید؛ صفحه را تازه‌سازی کنید.'),403);
 }
 public static function upload(){
  self::guard();$uid=get_current_user_id();
  if(get_transient('shipaa_avatar180_rate_'.$uid))wp_send_json_error(array('message'=>'چند ثانیه بعد دوباره تلاش کنید.'),429);
  $file=$_FILES['shipaa_avatar_upload']??null;
  if(!is_array($file)||($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)wp_send_json_error(array('message'=>'تصویر به‌درستی انتخاب نشده است.'),400);
  if(empty($file['size'])||(int)$file['size']>3*1024*1024)wp_send_json_error(array('message'=>'حداکثر حجم فایل ۳ مگابایت است.'),400);
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/image.php';
  require_once ABSPATH.'wp-admin/includes/media.php';
  $type=wp_check_filetype_and_ext($file['tmp_name'],sanitize_file_name($file['name']));
  if(!in_array($type['type']??'',array('image/jpeg','image/png','image/webp'),true))wp_send_json_error(array('message'=>'فقط تصویر JPG، PNG یا WebP مجاز است.'),400);
  $id=media_handle_upload('shipaa_avatar_upload',0,array('post_author'=>$uid),array('test_form'=>false,'mimes'=>array('jpg|jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp')));
  if(is_wp_error($id))wp_send_json_error(array('message'=>$id->get_error_message()),400);
  $src=wp_get_attachment_image_url($id,'medium');
  if(!$src){wp_delete_attachment($id,true);wp_send_json_error(array('message'=>'ذخیره تصویر موفق نبود.'),500);}
  update_user_meta($uid,'shipaa_avatar_id',absint($id));
  update_user_meta($uid,'shipaa_avatar_mode','upload');
  update_user_meta($uid,'profile_picture',esc_url_raw($src));
  set_transient('shipaa_avatar180_rate_'.$uid,1,12);
  wp_send_json_success(array('url'=>$src,'message'=>'تصویر شما ذخیره شد.'));
 }
 public static function remove(){
  self::guard();$uid=get_current_user_id();
  delete_user_meta($uid,'shipaa_avatar_id');
  delete_user_meta($uid,'shipaa_avatar_mode');
  delete_user_meta($uid,'profile_picture');
  // Don't delete the media attachment: other parts of the site may reference it.
  $gender=get_user_meta($uid,'shipaa_gender',true);
  wp_send_json_success(array('symbol'=>$gender==='زن'?'👩':($gender==='مرد'?'👨':'👤'),'message'=>'تصویر حذف شد.'));
 }
}
