<?php
/**
 * SHIPAA Learner App v3 — خانه یادگیری شیپا
 * منوی ثابت (نوار کناری دسکتاپ / ریل تبلت / نوار پایین موبایل)، پلیر داخلی متصل به استادیار، پیگیری ثبت‌نام.
 */
if (!defined('ABSPATH')) exit;

final class SHIPAA_Learner_V3 {
 const SUPPORT = 'https://eitaa.com/shipaa_admin';
 const LOGO = 'https://shipaa.ir/wp-content/uploads/2026/10/shipaa-official-logo-contact.png';

 public static function icon($key){
  $p=array(
   'home'=>'<path d="M4 10.5 12 4l8 6.5V20a1 1 0 0 1-1 1h-4.5v-6h-5v6H5a1 1 0 0 1-1-1z"/>',
   'book'=>'<path d="M12 6.5C9.5 4.8 6.5 4.5 3.5 5.3v13.4c3-.8 6-.5 8.5 1.3 2.5-1.8 5.5-2.1 8.5-1.3V5.3c-3-.8-6-.5-8.5 1.2z"/><path d="M12 6.5V20"/>',
   'receipt'=>'<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
   'user'=>'<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c1-4 4-6 7.5-6s6.5 2 7.5 6"/>',
   'play'=>'<path d="M8 5.5v13l10.5-6.5z" fill="currentColor" stroke="none"/>',
   'pause'=>'<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor" stroke="none"/>',
   'playc'=>'<circle cx="12" cy="12" r="9.5"/><path d="M10 8.3v7.4l6-3.7z" fill="currentColor"/>',
   'arrow'=>'<path d="M19 12H5m6-6-6 6 6 6"/>',
   'back'=>'<path d="M5 12h14m-6-6 6 6-6 6"/>',
   'check'=>'<path d="m5 12.5 4.2 4.2L19 7"/>',
   'clock'=>'<circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/>',
   'chevron'=>'<path d="m6 9 6 6 6-6"/>',
   'chat'=>'<path d="M4 5h16v11H9l-5 4z"/><path d="M8 9.5h8M8 12.5h5"/>',
   'spark'=>'<path d="M12 3l1.9 6.1L20 11l-6.1 1.9L12 19l-1.9-6.1L4 11l6.1-1.9z"/>',
   'leaf'=>'<path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14z"/><path d="M5 19 13 11"/>',
   'lock'=>'<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8.5 10.5V7.5a3.5 3.5 0 0 1 7 0v3"/>',
   'external'=>'<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
   'search'=>'<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
   'file'=>'<path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h4"/>',
   'headphones'=>'<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3.5" y="13.5" width="4.5" height="7" rx="2"/><rect x="16" y="13.5" width="4.5" height="7" rx="2"/>',
   'rewind'=>'<path d="M11 7 6 12l5 5M18 7l-5 5 5 5"/>',
   'forward'=>'<path d="m13 7 5 5-5 5M6 7l5 5-5 5"/>',
   'next'=>'<path d="M6 6v12l9-6z" fill="currentColor" stroke="none"/><path d="M18 6v12"/>',
   'prev'=>'<path d="M18 6v12L9 12z" fill="currentColor" stroke="none"/><path d="M6 6v12"/>',
   'full'=>'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
   'pip'=>'<rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1" fill="currentColor"/>',
   'phone'=>'<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/>',
   'logout'=>'<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
   'compass'=>'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
   'list'=>'<path d="M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01"/>',
   'volume'=>'<path d="M4 9.5h4L13 5v14l-5-4.5H4z"/><path d="M16.5 9a4 4 0 0 1 0 6"/>',
   'mute'=>'<path d="M4 9.5h4L13 5v14l-5-4.5H4z"/><path d="m17 9.5 4 5M21 9.5l-4 5"/>'
  );
  $path=$p[$key] ?? $p['spark'];
  return '<svg class="sp-i" aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'.$path.'</svg>';
 }
 private static function n($v){ return esc_html(number_format_i18n((int)$v)); }
 public static function greeting(){
  $h=(int)wp_date('G');
  if($h>=4 && $h<11) return 'صبح بخیر';
  if($h>=11 && $h<16) return 'ظهر بخیر';
  if($h>=16 && $h<20) return 'عصر بخیر';
  return 'شب بخیر';
 }
 private static function fmt_time($s){ $s=max(0,(int)$s); $m=floor($s/60); $r=$s%60; return number_format_i18n($m).':'.str_pad(number_format_i18n($r),2,number_format_i18n(0),STR_PAD_LEFT); }

 /** وضعیت سفارش با واژگان شیپا */
 public static function order_state($order){
  $s=$order->get_status(); $fix=$order->get_meta('_shipaa_review_state')==='needs_changes';
  if($fix && in_array($s,array('pending','on-hold'),true)) return array('label'=>'نیاز به اصلاح رسید','tone'=>'lilac','step'=>2,'fix'=>true,'note'=>trim((string)$order->get_meta('_shipaa_review_note')));
  if($s==='pending') return array('label'=>'منتظر پرداخت و ارسال رسید','tone'=>'sky','step'=>2,'fix'=>false);
  if($s==='on-hold') return array('label'=>($order->get_meta('_shipaa_paid_waiting')==='yes'||$order->get_date_paid())?'پرداخت انجام شد؛ منتظر تأیید شیپا':'رسید رسید؛ در حال بررسی','tone'=>'sky','step'=>3,'fix'=>false);
  if(in_array($s,array('completed','processing'),true)) return array('label'=>'تأیید شد؛ دوره باز است','tone'=>'green','step'=>5,'fix'=>false);
  return array('label'=>function_exists('wc_get_order_status_name')?wc_get_order_status_name($s):$s,'tone'=>'muted','step'=>0,'fix'=>false);
 }

 private static function nav_items(){
  return array(
   'home'=>array('خانه','home'),
   'courses'=>array('دوره‌های من','book'),
   'learn'=>array('ادامه یادگیری','playc'),
   'requests'=>array('ثبت‌نام‌ها','receipt'),
   'account'=>array('پروفایل من','user'),
  );
 }
 private static function nav_button($key,$label,$icon,$cls,$badge=0){
  $b=$badge?'<b class="sp-badge-dot" aria-label="'.esc_attr(number_format_i18n($badge).' مورد باز').'">'.self::n($badge).'</b>':'';
  return '<a href="#/'.esc_attr($key).'" class="'.esc_attr($cls).'" data-sp-nav="'.esc_attr($key).'"'.($key==='home'?' aria-current="page"':'').'><span class="sp-nav-ic">'.self::icon($icon).$b.'</span><span class="sp-nav-tx">'.esc_html($label).'</span></a>';
 }

 private static function course_card($c,$state,$prog=null,$pending_state=null){
  $tone=$state==='active'?'green':($state==='pending'?($pending_state?$pending_state['tone']:'sky'):'lilac');
  $label=$state==='active'?'آماده یادگیری':($state==='pending'?($pending_state?$pending_state['label']:'در انتظار تأیید'):'پیشنهاد شیپا');
  ob_start(); ?>
  <article class="sp-ccard" data-sp-card data-sp-filter="<?php echo esc_attr($state);?>" data-sp-title="<?php echo esc_attr($c['title']);?>">
   <div class="sp-ccard-cover"><?php if($c['image']):?><img src="<?php echo esc_url($c['image']);?>" alt="" loading="lazy"><?php else:?><span class="sp-cover-art"><?php echo self::icon('leaf');?></span><?php endif;?>
    <span class="sp-pill sp-<?php echo esc_attr($tone);?>"><?php echo esc_html($label);?></span>
    <?php if($state==='active'):?><button type="button" class="sp-cover-play" data-sp-open="<?php echo esc_attr($c['id']);?>" aria-label="<?php echo esc_attr('پخش '.$c['title']);?>"><?php echo self::icon('play');?></button><?php endif;?>
   </div>
   <div class="sp-ccard-body">
    <h3><?php echo esc_html($c['title']);?></h3>
    <?php if($state==='active' && $prog):?>
     <div class="sp-meter" aria-label="<?php echo esc_attr('پیشرفت '.$prog['percent'].' درصد');?>"><b style="--w:<?php echo esc_attr($prog['percent']);?>%" data-sp-course-bar="<?php echo esc_attr($c['id']);?>"></b></div>
     <p class="sp-muted"><span data-sp-course-count="<?php echo esc_attr($c['id']);?>"><?php echo self::n($prog['done']);?> از <?php echo self::n($c['count']);?> جلسه</span> · <?php echo $prog['done']?'در مسیر':'شروع نشده';?></p>
     <button type="button" class="sp-btn sp-btn-main" data-sp-open="<?php echo esc_attr($c['id']);?>"><?php echo self::icon('play');?> <?php echo $prog['done']||$prog['last']?'ادامه یادگیری':'شروع اولین جلسه';?></button>
    <?php elseif($state==='pending'):?>
     <p class="sp-muted">پس از تأیید رسید توسط همکاران شیپا، جلسه‌ها برای شما باز می‌شود.</p>
     <a class="sp-btn sp-btn-soft" href="#/requests" data-sp-nav="requests"><?php echo self::icon('receipt');?> پیگیری ثبت‌نام</a>
    <?php else:?>
     <p class="sp-muted"><?php echo $c['count']?self::n($c['count']).' جلسه آموزشی':'مسیر آموزشی شیپا';?></p>
     <a class="sp-btn sp-btn-soft" href="<?php echo esc_url($c['url']);?>"><?php echo self::icon('compass');?> آشنایی و ثبت‌نام</a>
    <?php endif;?>
   </div>
  </article>
  <?php return ob_get_clean();
 }

 private static function learn_view($c,$prog){
  $done_map=array(); foreach($prog['lessons'] as $k=>$v) if(!empty($v['done'])) $done_map[$k]=true;
  $n=0; $first='';
  ob_start(); ?>
  <section class="sp-learn" data-sp-learn="<?php echo esc_attr($c['id']);?>" data-sp-course-title="<?php echo esc_attr($c['title']);?>" data-sp-cover="<?php echo esc_url($c['image']);?>" hidden>
   <div class="sp-learn-head">
    <a href="#/courses" data-sp-nav="courses" class="sp-back"><?php echo self::icon('back');?><span>دوره‌های من</span></a>
    <div class="sp-learn-title"><span class="sp-kicker">کلاس شما</span><h1 tabindex="-1"><?php echo esc_html($c['title']);?></h1></div>
    <div class="sp-ring" style="--p:<?php echo esc_attr($prog['percent']);?>" data-sp-ring="<?php echo esc_attr($c['id']);?>"><svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18"/><circle class="sp-ring-v" cx="22" cy="22" r="18" pathLength="100"/></svg><b><span data-sp-ring-num><?php echo self::n($prog['percent']);?></span>٪</b></div>
   </div>
   <?php if(!$c['count']):?>
    <div class="sp-empty"><span class="sp-empty-ic"><?php echo self::icon('book');?></span><h2>جلسه‌های این دوره به‌زودی اضافه می‌شود</h2><p>فعلاً می‌توانید معرفی و جزئیات دوره را در صفحه اصلی آن ببینید.</p><a class="sp-btn sp-btn-main" href="<?php echo esc_url($c['url']);?>">صفحه دوره <?php echo self::icon('external');?></a></div>
   <?php else:?>
   <div class="sp-learn-grid">
    <div class="sp-player-col">
     <div class="sp-player" data-sp-player tabindex="-1">
      <div class="sp-player-stage" data-sp-stage>
       <div class="sp-player-idle"><span class="sp-idle-ic"><?php echo self::icon('playc');?></span><strong>جلسه را از فهرست انتخاب کنید</strong><small>یا روی «ادامه یادگیری» بزنید.</small></div>
      </div>
      <a class="sp-fab-back" href="#/courses" data-sp-nav="courses" aria-label="بازگشت به دوره‌های من"><?php echo self::icon('back');?></a>
     </div>
     <div class="sp-lesson-info" data-sp-info>
      <div class="sp-info-course"><span><?php echo esc_html($c['title']);?></span><b class="sp-info-pct"><i style="--w:<?php echo esc_attr($prog['percent']);?>%" data-sp-course-bar="<?php echo esc_attr($c['id']);?>"></i><span data-sp-course-pct="<?php echo esc_attr($c['id']);?>"><?php echo self::n($prog['percent']);?></span>٪</b></div>
      <span class="sp-kicker" data-sp-lesson-meta>آماده پخش</span>
      <h2 data-sp-lesson-title>—</h2>
      <div class="sp-lesson-actions">
       <button type="button" class="sp-btn sp-btn-ghost" data-sp-prev disabled><?php echo self::icon('back');?> قبلی</button>
       <span class="sp-auto-seen" data-sp-auto-seen aria-live="polite"><?php echo self::icon('check');?> <span>ثبت مشاهده خودکار</span></span>
       <button type="button" class="sp-btn sp-btn-main" data-sp-next disabled>بعدی <?php echo self::icon('arrow');?></button>
      </div>
      <section class="sp-pack-v2" data-sp-pack hidden aria-label="بسته یادگیری جلسه">
       <div class="sp-pack-v2-title"><span class="sp-pack-v2-icon" aria-hidden="true"><?php echo self::icon('file');?></span><div><h3>بسته یادگیری جلسه</h3><small>محتواهای تکمیلی همین جلسه</small></div></div>
       <div class="sp-pack-v2-description" data-sp-pack-description hidden></div>
       <div class="sp-pack-v2-links" data-sp-pack-links></div>
      </section>
      <div class="sp-files" data-sp-files hidden></div>
      <details class="sp-notes" data-sp-notes hidden><summary><?php echo self::icon('file');?> متن و توضیحات جلسه <?php echo self::icon('chevron');?></summary><div class="sp-notes-body" data-sp-notes-body></div></details>
      <a class="sp-origin" data-sp-origin href="<?php echo esc_url($c['url']);?>" target="_blank" rel="noopener"><?php echo self::icon('external');?> باز کردن همین جلسه در صفحه استادیار</a>
     </div>
    </div>
    <aside class="sp-playlist" aria-label="فهرست جلسه‌ها">
     <div class="sp-playlist-head"><h2><?php echo self::icon('list');?> سرفصل‌ها</h2><span class="sp-muted"><?php echo self::n(count($c['modules']));?> سرفصل · <?php echo self::n($c['count']);?> بخش آموزشی</span></div>
     <?php foreach($c['modules'] as $mi=>$m):?>
      <?php
       // Visual labels only. The Studiare lesson keys, permissions and progress are unchanged.
       $intro=(bool)preg_match('/(?:جلسه\s*(?:صفر|۰|0)|مقدمات|معرفی\s*دوره|آشنایی\s*با\s*دوره)/u',($m['title'].' '.($m['number']??'')));
       $session_number=$intro?0:($mi+1);
       $display_number=$intro?'۰':self::n($session_number);
      ?>
      <details class="sp-module sp-session-card" data-sp-session="<?php echo esc_attr($display_number);?>" <?php echo $mi===0?'open':'';?>>
       <summary><span class="sp-session-summary"><span class="sp-session-number" aria-hidden="true"><?php echo esc_html($display_number);?></span><span class="sp-session-name"><strong><?php echo esc_html($m['title']);?></strong><small><?php echo $intro?'مقدمه · ':''; echo self::n(count($m['lessons']));?> بخش آموزشی</small></span></span><?php echo self::icon('chevron');?></summary>
       <div class="sp-lessons">
        <?php if(!$m['lessons']):?><p class="sp-muted sp-pad">هنوز بخشی در این سرفصل منتشر نشده است.</p><?php endif;?>
        <?php foreach($m['lessons'] as $li=>$l): $n++; if(!$first)$first=$l['key']; $isdone=isset($done_map[$l['key']]); ?>
         <button type="button" class="sp-lesson<?php echo $isdone?' is-done':'';?>" data-sp-lesson="<?php echo esc_attr($l['key']);?>" data-sp-course="<?php echo esc_attr($c['id']);?>" aria-label="<?php echo esc_attr('بخش '.self::n($li+1).'، '.$l['title']);?>">
          <span class="sp-lesson-no" aria-hidden="true"><span><?php echo self::n($li+1);?></span><?php echo self::icon('check');?></span>
          <span class="sp-lesson-tx"><small class="sp-part-label"><?php echo self::icon('play');?> بخش <?php echo self::n($li+1);?> · ویدئوی آموزشی</small><strong><?php echo esc_html($l['title']);?></strong><?php if($l['duration']):?><small><?php echo self::icon('clock');?> <?php echo esc_html($l['duration']);?></small><?php endif;?></span>
          <span class="sp-lesson-eq" aria-hidden="true"><i></i><i></i><i></i></span>
         </button>
        <?php endforeach;?>
        <p class="sp-session-help">محتوای تکمیلی هر بخش پس از انتخاب آن، زیر پلیر نمایش داده می‌شود.</p>
       </div>
      </details>
     <?php endforeach;?>
    </aside>
   </div>
   <?php endif;?>
   <script type="application/json" data-sp-first><?php echo wp_json_encode(array('first'=>$first,'last'=>$prog['last']));?></script>
  </section>
  <?php return ob_get_clean();
 }

 public static function render(){
  if(!is_user_logged_in()) return SHIPAA_Learning_Auth::render();
  if(!function_exists('wc_get_orders')) return '<div dir="rtl" class="sp-signin">برای استفاده از این صفحه، ووکامرس باید فعال باشد.</div>';

  $u=wp_get_current_user(); $uid=(int)$u->ID;
  $first=trim((string)get_user_meta($uid,'first_name',true)); $name=$first?:$u->display_name;
  $is_admin=current_user_can('manage_woocommerce');
  $completion=SHIPAA_Profile_Integrated::completion_percent($uid);
  $avatar=SHIPAA_Profile_Integrated::avatar_markup($uid,'sp-ava-img',64,$name);

  $all_ids=SHIPAA_Studiare::course_ids(); $active=array(); $pending=array();
  foreach($all_ids as $id) if(SHIPAA_Studiare::enrolled($uid,$id)) $active[]=$id;
  $history=array();
  foreach(wc_get_orders(array('customer'=>$uid,'limit'=>100,'orderby'=>'date','order'=>'DESC')) as $o){
   $rel=array(); foreach($o->get_items('line_item') as $it){ $pid=absint($it->get_product_id()); if(in_array($pid,$all_ids,true)) $rel[]=$pid; }
   if(!$rel) continue; $st=self::order_state($o); $history[]=array('order'=>$o,'courses'=>array_values(array_unique($rel)),'state'=>$st);
   if(in_array($o->get_status(),array('pending','on-hold'),true)) foreach($rel as $pid) if(!in_array($pid,$active,true) && !isset($pending[$pid])) $pending[$pid]=$st;
  }
  $owned=array_values(array_unique(array_merge($active,array_keys($pending))));
  $courses=array(); foreach(array_unique(array_merge($owned,$all_ids)) as $id) $courses[$id]=SHIPAA_Studiare::structure($id);
  $progress=array(); $lessons_done=0; $lessons_total=0;
  foreach($active as $id){ $progress[$id]=SHIPAA_Studiare::course_progress($uid,$id); $lessons_done+=$progress[$id]['done']; $lessons_total+=$progress[$id]['total']; }
  $overall=$lessons_total?(int)round($lessons_done*100/$lessons_total):0;
  $recommended=array_values(array_diff($all_ids,$owned));
  $resume=SHIPAA_Studiare::resume($uid,$active);
  $open_requests=0; foreach($history as $h) if(in_array($h['order']->get_status(),array('pending','on-hold'),true)) $open_requests++;
  $greet=self::greeting();

  ob_start(); ?>
<div class="sp-app" dir="rtl" data-sp-root>
 <div class="sp-ambient" aria-hidden="true"><i class="a1"></i><i class="a2"></i><i class="a3"></i></div>

 <aside class="sp-rail" aria-label="منوی خانه یادگیری">
  <a class="sp-rail-brand" href="<?php echo esc_url(home_url('/'));?>" aria-label="صفحه اصلی شیپا"><img src="<?php echo esc_url(self::LOGO);?>" alt="شیپا" width="132" height="56"><span class="sp-rail-sub">خانه یادگیری</span></a>
  <nav class="sp-rail-nav"><span class="sp-rail-ind" aria-hidden="true"></span>
   <?php foreach(self::nav_items() as $k=>$it) echo self::nav_button($k,$it[0],$it[1],'sp-rail-btn',$k==='requests'?$open_requests:0); ?>
  </nav>
  <div class="sp-rail-foot">
   <?php if($resume):?><button type="button" class="sp-rail-resume" data-sp-resume><span class="sp-rail-resume-ic"><?php echo self::icon('play');?></span><span><small>ادامه از همان‌جا</small><strong><?php echo esc_html($resume['title']);?></strong></span></button><?php endif;?>
   <?php if($is_admin):?><a class="sp-rail-link" href="<?php echo esc_url(home_url('/shipaa-command/'));?>"><?php echo self::icon('spark');?><span>مرکز فرمان</span></a><?php endif;?>
   <a class="sp-rail-link" href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener"><?php echo self::icon('chat');?><span>پشتیبانی در ایتا</span></a>
   <a class="sp-rail-link" href="<?php echo esc_url(home_url('/'));?>"><?php echo self::icon('external');?><span>بازگشت به سایت</span></a>
   <p class="sp-motto"><?php echo self::icon('leaf');?> یادگیری، نقطه آغاز حرکت</p>
  </div>
 </aside>

 <div class="sp-frame">

  <main class="sp-stage" id="sp-main">

  <!-- خانه -->
  <section class="sp-screen is-on" data-sp-screen="home">
   <div class="sp-hero" data-sp-reveal>
    <a href="#/account" data-sp-nav="account" class="sp-identity-avatar" aria-label="ویرایش پروفایل و تصویر شخصی"><?php echo SHIPAA_Profile_Integrated::avatar_markup($uid,'sp-avatar-hero',100,'عکس پروفایل شما');?><span class="sp-avatar-edit" aria-hidden="true"><?php echo self::icon('user');?></span></a>
    <div class="sp-hero-copy">
     <span class="sp-kicker sp-kicker-hero"><?php echo self::icon('leaf');?> <?php echo esc_html($greet);?> · خانه یادگیری من</span>
     <h1 tabindex="-1"><?php echo esc_html($name);?> عزیز، خوش آمدید</h1>
     <p>فضای شخصی شما در شیپا؛ مسیر یادگیری‌ات از همین‌جا ادامه پیدا می‌کند.</p>
     <div class="sp-hero-cta">
      <?php if($resume):?><button type="button" class="sp-btn sp-btn-main sp-btn-lg" data-sp-resume><?php echo self::icon('play');?> ادامه یادگیری</button>
      <?php elseif($active):?><button type="button" class="sp-btn sp-btn-main sp-btn-lg" data-sp-open="<?php echo esc_attr($active[0]);?>"><?php echo self::icon('play');?> شروع اولین جلسه</button>
      <?php else:?><a class="sp-btn sp-btn-main sp-btn-lg" href="#/courses" data-sp-nav="courses"><?php echo self::icon('compass');?> کشف دوره‌ها</a><?php endif;?>
     </div>
    </div>
    <div class="sp-hero-ring" aria-label="<?php echo esc_attr('پیشرفت کلی '.$overall.' درصد');?>">
     <div class="sp-ring sp-ring-xl<?php echo $overall?'':' is-zero';?>" style="--p:<?php echo esc_attr($overall);?>" data-sp-ring="all"><svg viewBox="0 0 44 44" aria-hidden="true"><circle cx="22" cy="22" r="18"/><circle class="sp-ring-v" cx="22" cy="22" r="18" pathLength="100"/></svg><b><span data-sp-count="<?php echo esc_attr($overall);?>">۰</span>٪</b></div>
     <small>پیشرفت کلی یادگیری</small>
    </div>
   </div>

   <?php // Short status strip just below greeting; show only actionable nonzero counts.
   $shipaa_summary_items = array(
    array('count'=>count($active),'label'=>'دوره فعال','icon'=>'book','section'=>'courses'),
    array('count'=>$lessons_done,'label'=>'جلسه دیده‌شده','icon'=>'check','section'=>'courses'),
    array('count'=>$open_requests,'label'=>'ثبت‌نام در جریان','icon'=>'receipt','section'=>'requests'),
   );
   $shipaa_summary_items=array_values(array_filter($shipaa_summary_items,static function($item){return $item['count']>0;}));
   ?>
   <?php if($shipaa_summary_items):?>
   <nav class="sp-progress-strip" aria-label="خلاصه وضعیت یادگیری" data-sp-reveal>
    <?php foreach($shipaa_summary_items as $item):?>
    <a class="sp-progress-item" href="#/<?php echo esc_attr($item['section']);?>" data-sp-nav="<?php echo esc_attr($item['section']);?>" aria-label="<?php echo esc_attr($item['count'].' '.$item['label']);?>">
      <span class="sp-progress-icon" aria-hidden="true"><?php echo self::icon($item['icon']);?></span>
      <strong data-sp-count="<?php echo esc_attr($item['count']);?>"><?php echo esc_html(self::n($item['count']));?></strong>
      <span class="sp-progress-name"><?php echo esc_html($item['label']);?></span>
    </a>
    <?php endforeach;?>
   </nav>
   <?php endif;?>

   <?php if($resume): $c=$courses[$resume['course']]; $pc=$resume['dur']?min(100,(int)round($resume['pos']*100/$resume['dur'])):0; ?>
   <button type="button" class="sp-resume" data-sp-resume data-sp-reveal>
    <span class="sp-resume-cover"><?php if($c['image']):?><img src="<?php echo esc_url($c['image']);?>" alt="" loading="lazy"><?php endif;?><span class="sp-resume-play"><?php echo self::icon('play');?></span></span>
    <span class="sp-resume-tx"><small>از همان‌جا که ماندید ادامه دهید</small><strong><?php echo esc_html($resume['title']);?></strong><em><?php echo esc_html($c['title']);?><?php if($resume['pos']>5):?> · دقیقه <?php echo esc_html(self::fmt_time($resume['pos']));?><?php endif;?></em><span class="sp-meter sp-meter-sm"><b style="--w:<?php echo esc_attr($pc);?>%"></b></span></span>
    <span class="sp-resume-go"><?php echo self::icon('arrow');?></span>
   </button>
   <?php elseif($active): $c=$courses[$active[0]]; ?>
   <button type="button" class="sp-resume sp-resume-first" data-sp-open="<?php echo esc_attr($active[0]);?>" data-sp-reveal>
    <span class="sp-resume-cover"><?php if($c['image']):?><img src="<?php echo esc_url($c['image']);?>" alt="" loading="lazy"><?php endif;?><span class="sp-resume-play"><?php echo self::icon('play');?></span></span>
    <span class="sp-resume-tx"><small>کلاس شما آماده است</small><strong><?php echo esc_html($c['title']);?></strong><em>شروع اولین جلسه و مسیر یادگیری</em><span class="sp-resume-first-label">شروع یادگیری ←</span></span>
    <span class="sp-resume-go"><?php echo self::icon('arrow');?></span>
   </button>
   <?php endif;?>

   <div class="sp-sec-head sp-sec-head-quick" data-sp-reveal><h2>دسترسی‌های سریع</h2></div>
   <div class="sp-quick" data-sp-reveal>
    <a href="#/courses" data-sp-nav="courses" class="sp-q sp-t-green"><span><?php echo self::icon('book');?></span><strong>دوره‌های من</strong><small>کلاس‌ها و جلسات</small></a>
    <a href="#/account" data-sp-nav="account" class="sp-q sp-t-lilac"><span><?php echo self::icon('user');?></span><strong>پروفایل من</strong><small>عکس و مشخصات</small></a>
    <a href="#/requests" data-sp-nav="requests" class="sp-q sp-t-sky"><span><?php echo self::icon('receipt');?></span><strong>ثبت‌نام‌های من</strong><small>وضعیت و رسیدها</small></a>
    <a href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener" class="sp-q sp-t-amber"><span><?php echo self::icon('chat');?></span><strong>پشتیبانی</strong><small>گفت‌وگو در ایتا</small></a>
   </div>

   <?php if($completion < 100): ?>
   <a href="#/account" data-sp-nav="account" class="sp-next-step" data-sp-reveal><span class="sp-next-step-icon"><?php echo self::icon('user');?></span><span><strong>پروفایل شما هنوز کامل نیست</strong><small>اطلاعات و تصویرتان را تکمیل کنید</small></span><span class="sp-next-step-arrow"><?php echo self::icon('arrow');?></span></a>
   <?php elseif($open_requests): ?>
   <a href="#/requests" data-sp-nav="requests" class="sp-next-step" data-sp-reveal><span class="sp-next-step-icon"><?php echo self::icon('receipt');?></span><span><strong>ثبت‌نام در انتظار بررسی</strong><small>وضعیت درخواست‌های خود را ببینید</small></span><span class="sp-next-step-arrow"><?php echo self::icon('arrow');?></span></a>
   <?php endif;?>

   <?php if($owned):?>
   <div class="sp-sec-head" data-sp-reveal><h2>دوره‌های من</h2><a href="#/courses" data-sp-nav="courses" class="sp-more">همه دوره‌ها <?php echo self::icon('arrow');?></a></div>
   <div class="sp-hscroll" data-sp-reveal><?php foreach($owned as $id) echo self::course_card($courses[$id],in_array($id,$active,true)?'active':'pending',$progress[$id]??null,$pending[$id]??null); ?></div>
   <?php else:?>
   <div class="sp-first" data-sp-reveal><span class="sp-empty-ic"><?php echo self::icon('spark');?></span><h2>اولین قدم را با هم برداریم</h2><p>هنوز دوره‌ای در حساب شما فعال نشده است. دوره‌های شیپا را ببینید و مسیر خود را انتخاب کنید.</p><a class="sp-btn sp-btn-main" href="#/courses" data-sp-nav="courses"><?php echo self::icon('compass');?> دیدن دوره‌ها</a></div>
   <?php endif;?>


  </section>

  <!-- دوره‌ها -->
  <section class="sp-screen" data-sp-screen="courses" hidden>
   <div class="sp-page-head" data-sp-reveal><span class="sp-kicker">کتابخانه شخصی</span><h1 tabindex="-1">دوره‌های من</h1><p>هر دوره‌ای که برایتان باز شده، با یک لمس پخش می‌شود.</p></div>
   <div class="sp-toolbar" data-sp-reveal>
    <!-- جست‌وجوی عمومی در پنل کوتاه «بیشتر» در دسترس است؛ این باکس خالی حذف شد. -->
    <div class="sp-filters" role="group" aria-label="فیلتر دوره‌ها">
     <button type="button" class="is-on" data-sp-filter-btn="all">همه</button>
     <button type="button" data-sp-filter-btn="active">آماده یادگیری <b><?php echo self::n(count($active));?></b></button>
     <?php if($pending):?><button type="button" data-sp-filter-btn="pending">در انتظار <b><?php echo self::n(count($pending));?></b></button><?php endif;?>
     <?php if($recommended):?><button type="button" data-sp-filter-btn="suggest">پیشنهادی</button><?php endif;?>
    </div>
   </div>
   <div class="sp-grid" data-sp-grid>
    <?php foreach($active as $id) echo self::course_card($courses[$id],'active',$progress[$id]);
          foreach(array_keys($pending) as $id) echo self::course_card($courses[$id],'pending',null,$pending[$id]);
          foreach(array_slice($recommended,0,12) as $id) echo self::course_card($courses[$id],'suggest'); ?>
   </div>
   <p class="sp-empty-inline" data-sp-search-empty hidden>دوره‌ای با این نام پیدا نشد؛ واژه دیگری را امتحان کنید.</p>
   <?php if(!$courses):?><div class="sp-empty"><span class="sp-empty-ic"><?php echo self::icon('book');?></span><h2>به‌زودی دوره‌های تازه منتشر می‌شود</h2></div><?php endif;?>
  </section>

  <!-- یادگیری -->
  <section class="sp-screen" data-sp-screen="learn" hidden>
   <div class="sp-learn-pick" data-sp-learn-pick>
    <div class="sp-page-head"><span class="sp-kicker">ادامه یادگیری</span><h1 tabindex="-1">کدام دوره را پخش کنیم؟</h1><p><?php echo $active?'یکی از دوره‌های فعال خود را انتخاب کنید.':'هنوز دوره‌ای برای پخش در حساب شما فعال نشده است.';?></p></div>
    <div class="sp-grid"><?php foreach($active as $id) echo self::course_card($courses[$id],'active',$progress[$id]); ?></div>
    <?php if(!$active):?><div class="sp-empty"><span class="sp-empty-ic"><?php echo self::icon('lock');?></span><h2>کلاس شما پس از تأیید ثبت‌نام باز می‌شود</h2><p>اگر رسید را فرستاده‌اید، وضعیت را در «ثبت‌نام‌ها» ببینید.</p><a class="sp-btn sp-btn-main" href="#/requests" data-sp-nav="requests">ثبت‌نام‌های من</a></div><?php endif;?>
   </div>
   <?php foreach($active as $id) echo self::learn_view($courses[$id],$progress[$id]); ?>
  </section>

  <!-- ثبت‌نام‌ها -->
  <section class="sp-screen" data-sp-screen="requests" hidden>
   <div class="sp-page-head" data-sp-reveal><span class="sp-kicker">شفاف و قدم‌به‌قدم</span><h1 tabindex="-1">ثبت‌نام‌های من</h1><p>هر ثبت‌نام چهار مرحله دارد؛ مرحله فعلی شما روشن است.</p></div>
   <?php if($history):?><div class="sp-orders">
    <?php foreach($history as $h): $o=$h['order']; $st=$h['state']; $step=$st['step'];
     $steps=array('ثبت درخواست',$st['fix']?'اصلاح رسید':'پرداخت و ارسال رسید','بررسی همکاران شیپا','باز شدن دوره'); ?>
     <article class="sp-order" data-sp-reveal>
      <div class="sp-order-top"><div><span class="sp-pill sp-<?php echo esc_attr($st['tone']);?>"><?php echo esc_html($st['label']);?></span><h3><?php echo esc_html(implode('، ',array_map('get_the_title',$h['courses'])));?></h3><p class="sp-muted">سفارش <?php echo esc_html('#'.number_format_i18n($o->get_id(),0));?> · <?php echo esc_html($o->get_date_created()?wp_date('j F Y',$o->get_date_created()->getTimestamp()):'—');?> · <?php echo wp_kses_post($o->get_formatted_order_total());?></p></div></div>
      <?php if($step):?><ol class="sp-steps<?php echo $st['fix']?' has-fix':'';?>" style="--s:<?php echo esc_attr(min(4,$step));?>">
       <?php foreach($steps as $i=>$label): $n=$i+1; $cls=$n<$step?'is-done':($n===$step?'is-now':''); if($step===5)$cls='is-done'; ?>
        <li class="<?php echo esc_attr($cls);?>"><span><?php echo $cls==='is-done'?self::icon('check'):self::n($n);?></span><small><?php echo esc_html($label);?></small></li>
       <?php endforeach;?></ol><?php endif;?>
      <div class="sp-order-foot">
       <?php if($step===5):?><span class="sp-muted"><?php echo self::icon('check');?> دسترسی شما فعال است.</span><?php foreach($h['courses'] as $cid) if(in_array($cid,$active,true)):?><button type="button" class="sp-btn sp-btn-main sp-btn-sm" data-sp-open="<?php echo esc_attr($cid);?>"><?php echo self::icon('play');?> ورود به کلاس</button><?php break; endif;?>
       <?php elseif($st['fix']):?><?php if(!empty($st['note'])):?><p class="sp-fixnote"><b>پیام همکاران شیپا:</b> <?php echo esc_html($st['note']);?></p><?php endif;?><span class="sp-muted">رسید نیاز به اصلاح دارد؛ لطفاً رسید درست را در ایتا برای پشتیبان بفرستید.</span><a class="sp-btn sp-btn-main sp-btn-sm" href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener"><?php echo self::icon('chat');?> پیام به پشتیبان</a>
       <?php elseif($step===2):?><span class="sp-muted">رسید کارت‌به‌کارت را در ایتا برای پشتیبان بفرستید.</span><a class="sp-btn sp-btn-main sp-btn-sm" href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener"><?php echo self::icon('chat');?> ارسال رسید در ایتا</a>
       <?php elseif($step===3):?><span class="sp-muted">ثبت‌نام شما در صف بررسی همکاران شیپاست؛ پس از تأیید، دوره خودکار باز می‌شود.</span>
       <?php endif;?>
       <a class="sp-link" href="<?php echo esc_url($o->get_view_order_url());?>">جزئیات سفارش <?php echo self::icon('external');?></a>
      </div>
     </article>
    <?php endforeach;?></div>
   <?php else:?><div class="sp-empty" data-sp-reveal><span class="sp-empty-ic"><?php echo self::icon('receipt');?></span><h2>هنوز ثبت‌نامی ندارید</h2><p>بعد از ثبت‌نام در هر دوره، مراحل بررسی آن همین‌جا دیده می‌شود.</p><a class="sp-btn sp-btn-main" href="<?php echo esc_url(home_url('/shop/'));?>"><?php echo self::icon('compass');?> دیدن دوره‌ها</a></div><?php endif;?>
   <div class="sp-help" data-sp-reveal><span class="sp-help-ic"><?php echo self::icon('chat');?></span><div><h3>سؤالی دارید؟</h3><p>همکاران پشتیبانی شیپا در ایتا پاسخ‌گوی ثبت‌نام، رسید و دسترسی دوره‌ها هستند.</p></div><a class="sp-btn sp-btn-soft" href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener">گفت‌وگو در ایتا <?php echo self::icon('external');?></a></div>
  </section>

  <!-- پروفایل -->
  <section class="sp-screen" data-sp-screen="account" hidden>
   <div class="sp-page-head" data-sp-reveal><span class="sp-kicker">پرونده شخصی</span><h1 tabindex="-1">پروفایل من</h1><p>اطلاعات شما فقط برای خدمات آموزشی و ارتباط با شیپا استفاده می‌شود.</p></div>
   <div data-sp-reveal><?php echo SHIPAA_Profile_Integrated::render($u); ?></div>
   <div class="sp-acc-grid" data-sp-reveal>
    <div class="sp-acc sp-t-sky" data-sp-install hidden><span><?php echo self::icon('phone');?></span><h3>شیپا روی صفحه گوشی</h3><p>خانه یادگیری را مثل یک برنامه به صفحه اصلی گوشی اضافه کنید.</p><button type="button" class="sp-btn sp-btn-main sp-btn-sm" data-sp-install-btn>افزودن به صفحه اصلی</button></div>
    <div class="sp-acc sp-t-green"><span><?php echo self::icon('chat');?></span><h3>پشتیبانی شیپا</h3><p>برای رسید، ثبت‌نام یا دسترسی دوره در ایتا پیام بدهید.</p><a class="sp-btn sp-btn-soft sp-btn-sm" href="<?php echo esc_url(self::SUPPORT);?>" target="_blank" rel="noopener">گفت‌وگو در ایتا</a></div>
    <div class="sp-acc sp-t-lilac"><span><?php echo self::icon('logout');?></span><h3>خروج از حساب</h3><p>روی دستگاه‌های مشترک، بعد از پایان کار خارج شوید.</p><a class="sp-btn sp-btn-ghost sp-btn-sm" href="<?php echo esc_url(wp_logout_url(home_url('/')));?>">خروج</a></div>
   </div>
  </section>
  </main>
 </div>

 <nav class="sp-tabbar" aria-label="منوی اصلی">
  <span class="sp-tab-ind" aria-hidden="true"></span>
  <?php foreach(self::nav_items() as $k=>$it){ echo $k==='learn'
    ? '<a href="#/learn" class="sp-tab sp-tab-fab" data-sp-nav="learn" '.($resume?'data-sp-resume-nav ':'').'aria-label="ادامه یادگیری"><span class="sp-fab">'.self::icon('play').'</span><span class="sp-nav-tx">ادامه</span></a>'
    : self::nav_button($k,$k==='courses'?'دوره‌ها':($k==='account'?'پروفایل':$it[0]),$it[1],'sp-tab',$k==='requests'?$open_requests:0); } ?>
 </nav>
 <div class="sp-toast" role="status" aria-live="polite" hidden><span data-sp-toast-tx></span><button type="button" data-sp-toast-act hidden></button></div>
 <script type="application/json" data-sp-boot><?php echo wp_json_encode(array('resume'=>$resume?array('course'=>$resume['course'],'key'=>$resume['key']):null,'active'=>$active,'admin'=>$is_admin));?></script>
</div>
  <?php return ob_get_clean();
 }
}
