<?php
if (!defined('ABSPATH')) exit;
/** Auth UI for guests on the learning page only. No changes to course or navigation logic. */
final class SHIPAA_Learning_Auth {
 public static $error='';
 public static function boot(){add_action('template_redirect',array(__CLASS__,'handle'),5);}
 private static function on_page(){global $post;return $post instanceof WP_Post && has_shortcode((string)$post->post_content,'shipaa_dashboard_v1');}
 private static function digits($v){return strtr((string)$v,array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));}
 private static function phone($v){$v=preg_replace('/[^0-9]/','',self::digits($v));if(strlen($v)===12&&substr($v,0,2)==='98')$v='0'.substr($v,2);return $v;}
 public static function handle(){
  if(!self::on_page()||is_user_logged_in()||($_SERVER['REQUEST_METHOD']??'')!=='POST'||!isset($_POST['shipaa_learning_auth']))return;
  $nonce=sanitize_text_field(wp_unslash($_POST['_shipaa_auth_nonce']??''));
  if(!wp_verify_nonce($nonce,'shipaa_learning_auth')){self::$error='فرم منقضی شده است؛ صفحه را تازه‌سازی کنید.';return;}
  if(!empty($_POST['shipaa_site_field'])){self::$error='درخواست نامعتبر است.';return;}
  $ip=(string)($_SERVER['REMOTE_ADDR']??'');$key='shipaa_auth_limit_'.md5($ip);$attempts=(int)get_transient($key);
  if($attempts>=12){self::$error='تعداد تلاش‌ها زیاد شده؛ کمی بعد دوباره امتحان کنید.';return;}
  set_transient($key,$attempts+1,15*MINUTE_IN_SECONDS);
  $mode=sanitize_key(wp_unslash($_POST['shipaa_learning_auth']));
  $phone=self::phone(wp_unslash($_POST['phone']??''));$password=(string)wp_unslash($_POST['password']??'');
  if(!preg_match('/^09\d{9}$/',$phone)){self::$error='شماره موبایل معتبر وارد کنید.';return;}
  if($mode==='login'){
   // Existing accounts with a different username can still use their established login in the top login route.
   $user=wp_signon(array('user_login'=>$phone,'user_password'=>$password,'remember'=>true),is_ssl());
   if(is_wp_error($user)){self::$error='شماره موبایل یا رمز عبور درست نیست. اگر قبلاً با نام کاربری دیگری عضو شده‌اید، از ورود معمول سایت استفاده کنید.';return;}
   wp_set_current_user($user->ID);wp_safe_redirect(get_permalink(),303);exit;
  }
  if($mode!=='register'){self::$error='درخواست نامعتبر است.';return;}
  $first=sanitize_text_field(wp_unslash($_POST['first_name']??''));$last=sanitize_text_field(wp_unslash($_POST['last_name']??''));
  if(!$first||!$last||(function_exists('mb_strlen')?mb_strlen($first):strlen($first))>65||(function_exists('mb_strlen')?mb_strlen($last):strlen($last))>65){self::$error='نام و نام خانوادگی را کامل وارد کنید.';return;}
  if(strlen($password)<8){self::$error='رمز عبور باید حداقل ۸ کاراکتر باشد.';return;}
  if(get_user_by('login',$phone)||get_users(array('meta_key'=>'billing_phone','meta_value'=>$phone,'number'=>1,'fields'=>'ID'))){self::$error='این شماره قبلاً ثبت شده است. از بخش ورود استفاده کنید.';return;}
  // Deliberately no fabricated email address. Existing WooCommerce profile fields remain intact.
  $uid=wp_create_user($phone,$password,'');
  if(is_wp_error($uid)){self::$error='ساخت حساب انجام نشد. لطفاً دوباره تلاش کنید.';return;}
  wp_update_user(array('ID'=>$uid,'first_name'=>$first,'last_name'=>$last,'display_name'=>$first.' '.$last,'role'=>'customer'));
  update_user_meta($uid,'billing_phone',$phone);
  wp_set_current_user($uid);wp_set_auth_cookie($uid,true,is_ssl());
  wp_safe_redirect(get_permalink(),303);exit;
 }
 public static function render(){
  $url=wp_login_url(get_permalink());ob_start(); ?>
  <style>
  .sp-onboard{direction:rtl;box-sizing:border-box;position:relative;isolation:isolate;max-width:550px;margin:clamp(28px,7vh,80px) auto;padding:clamp(22px,5vw,38px);border:1px solid #dfece8;border-radius:28px;background:linear-gradient(140deg,#ffffff 0%,#f8fcfa 54%,#f6f8ff 100%);box-shadow:0 20px 65px #285e4a12;font-family:inherit;color:#234238;overflow:hidden}.sp-onboard *{box-sizing:border-box}.sp-onboard:before{content:"";position:absolute;width:210px;height:210px;top:-135px;left:-85px;border-radius:50%;background:#ddd1f770;z-index:-1}.sp-onboard-head{display:flex;align-items:center;gap:15px}.sp-onboard-head img{width:86px;height:auto;object-fit:contain}.sp-onboard h1{margin:0;font-size:clamp(20px,4vw,26px);line-height:1.6;color:#23533c}.sp-onboard p{margin:7px 0 20px;color:#647b78;font-size:14px;line-height:2}.sp-onboard-sw{display:grid;grid-template-columns:1fr 1fr;gap:5px;padding:5px;background:#eaf4f1;border-radius:14px;margin:15px 0 22px}.sp-onboard-sw button{border:0;border-radius:11px;background:transparent;color:#56716a;font:inherit;padding:10px;cursor:pointer}.sp-onboard-sw button[aria-selected=true]{background:white;color:#247b54;box-shadow:0 3px 12px #225e3515;font-weight:700}.sp-onboard label{display:block;margin:0 0 13px;color:#365d51;font-weight:600;font-size:13px}.sp-onboard input:not([type=hidden]){display:block;width:100%;border:1px solid #d4e5df;background:white;color:#254739;border-radius:13px;padding:13px 14px;margin-top:7px;font:inherit;font-size:15px;outline-offset:2px}.sp-onboard input:focus{border-color:#65b88d;outline:2px solid #caead8}.sp-onboard-name{display:grid;grid-template-columns:1fr 1fr;gap:10px}.sp-onboard-submit{display:block;width:100%;border:0;border-radius:14px;background:linear-gradient(100deg,#57b674,#399b81);color:white;font:inherit;font-weight:700;padding:14px 18px;cursor:pointer;box-shadow:0 8px 18px #3e9a7433}.sp-onboard-tip{margin-top:12px;text-align:center;font-size:12px;color:#738b86;line-height:1.9}.sp-onboard-error{padding:11px;border-radius:12px;background:#fff0f0;color:#962f45;margin-bottom:15px}.sp-onboard-hidden{display:none!important}.sp-onboard-help{display:block;text-align:center;margin:16px auto 0;font-size:12px;color:#56738a;text-decoration:underline;text-underline-offset:3px}@media(max-width:520px){.sp-onboard{margin:16px 12px;padding:22px 18px;border-radius:21px}.sp-onboard-name{grid-template-columns:1fr}}
  </style>
  <section class="sp-onboard" dir="rtl" aria-label="ورود و عضویت خانه یادگیری">
   <div class="sp-onboard-head"><img src="<?php echo esc_url(SHIPAA_Learner_V3::LOGO);?>" alt="شیپا"><h1>خانه یادگیری تو، همین‌جاست 🌱</h1></div>
   <p>چند قدم کوتاه تا شروع مسیر یادگیری؛ بدون فرم‌های طولانی.</p>
   <?php if(self::$error):?><div class="sp-onboard-error" role="alert"><?php echo esc_html(self::$error);?></div><?php endif;?>
   <div class="sp-onboard-sw" role="tablist" aria-label="انتخاب ورود یا عضویت"><button type="button" data-sp-auth-tab="register" role="tab" aria-selected="true">ساخت حساب</button><button type="button" data-sp-auth-tab="login" role="tab" aria-selected="false">قبلاً عضو شدم</button></div>
   <form method="post" autocomplete="on">
    <?php wp_nonce_field('shipaa_learning_auth','_shipaa_auth_nonce');?><input type="hidden" name="shipaa_learning_auth" value="register" data-sp-auth-mode><input type="text" name="shipaa_site_field" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px;opacity:0" aria-hidden="true">
    <label>شماره موبایل<input required name="phone" type="tel" inputmode="tel" autocomplete="tel-national" maxlength="16" placeholder="۰۹۱۲۳۴۵۶۷۸۹"></label>
    <div data-sp-auth-register><div class="sp-onboard-name"><label>نام<input name="first_name" autocomplete="given-name" maxlength="65" required placeholder="نام شما"></label><label>نام خانوادگی<input name="last_name" autocomplete="family-name" maxlength="65" required placeholder="نام خانوادگی"></label></div></div>
    <label>رمز عبور<input name="password" type="password" autocomplete="new-password" minlength="8" required placeholder="حداقل ۸ کاراکتر"></label>
    <button class="sp-onboard-submit" type="submit" data-sp-auth-submit>ساخت حساب و شروع یادگیری ←</button>
    <div class="sp-onboard-tip">فقط شماره، نام و نام خانوادگی ثبت می‌شود؛ رمز عبور برای حفاظت از حساب شماست. تکمیل پروفایل هنگام ثبت‌نام دوره انجام می‌شود.</div>
    <a class="sp-onboard-help" href="<?php echo esc_url($url);?>">ورود با نام کاربری قبلی یا بازیابی رمز عبور</a>
   </form>
  </section>
  <script>(function(){var root=document.querySelector('.sp-onboard');if(!root)return;var tabs=root.querySelectorAll('[data-sp-auth-tab]'),field=root.querySelector('[data-sp-auth-mode]'),names=root.querySelector('[data-sp-auth-register]'),pass=root.querySelector('[name=password]'),submit=root.querySelector('[data-sp-auth-submit]');tabs.forEach(function(t){t.addEventListener('click',function(){var reg=t.getAttribute('data-sp-auth-tab')==='register';tabs.forEach(function(b){b.setAttribute('aria-selected',b===t?'true':'false')});field.value=reg?'register':'login';names.classList.toggle('sp-onboard-hidden',!reg);names.querySelectorAll('input').forEach(function(i){i.required=reg});pass.autocomplete=reg?'new-password':'current-password';submit.textContent=reg?'ساخت حساب و شروع یادگیری ←':'ورود به خانه یادگیری ←';});});})();</script>
  <?php return ob_get_clean();
 }
}
