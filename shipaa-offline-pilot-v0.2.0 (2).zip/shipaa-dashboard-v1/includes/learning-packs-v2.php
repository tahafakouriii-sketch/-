<?php
/** SHIPAA lesson-specific learning packs. Keeps Studiare and the existing access rules authoritative. */
if (!defined('ABSPATH')) exit;
final class SHIPAA_Learning_Packs_V2 {
 const META='_shipaa_session_learning_packs'; // Compatible with the 1.9 test version.
 public static function boot(){
  add_action('admin_menu',array(__CLASS__,'menu'),25);
  add_action('admin_enqueue_scripts',array(__CLASS__,'assets'));
  add_action('wp_ajax_shipaa_packs_v2',array(__CLASS__,'ajax'));
 }
 private static function allowed(){return current_user_can('manage_woocommerce') || current_user_can('manage_options');}
 public static function get($course,$lesson){
  $all=get_post_meta(absint($course),self::META,true);
  $row=is_array($all)&&isset($all[(string)$lesson])&&is_array($all[(string)$lesson])?$all[(string)$lesson]:array();
  $description=(string)($row['description']??'');
  // Legacy 1.9 descriptions could contain wp_kses_post HTML.
  $description=wp_strip_all_tags(str_replace(array('</p>','<br>','<br/>','<br />'),"\n",$description));
  $items=array();
  foreach((array)($row['items']??array()) as $item){
   if(!is_array($item))continue;
   $link=esc_url_raw((string)($item['url']??''),array('https','http'));
   if(!preg_match('#^https?://#i',$link))continue;
   $kind=(string)($item['type']??'file');
   if(!in_array($kind,array('note','slide','audio','image','summary','file','video'),true))$kind='file';
   $items[]=array('title'=>sanitize_text_field($item['title']??''),'url'=>$link,'type'=>$kind);
  }
  return array('description'=>$description,'items'=>array_slice($items,0,40));
 }
 public static function menu(){
  if(!self::allowed())return;
  add_submenu_page('shipaa-command','بسته‌های یادگیری جلسات','بسته‌های یادگیری','manage_woocommerce','shipaa-session-packs-v2',array(__CLASS__,'page'));
  add_submenu_page('edit.php?post_type=product','بسته‌های یادگیری جلسات','بسته‌های یادگیری','manage_woocommerce','shipaa-session-packs-v2',array(__CLASS__,'page'));
 }
 public static function assets($hook){
  if(strpos((string)$hook,'shipaa-session-packs-v2')===false)return;
  wp_enqueue_media();
  wp_enqueue_style('shipaa-packs-admin-v2',plugins_url('../assets/pack-admin.201.css',__FILE__),array(),'2.0.1');
  wp_enqueue_script('shipaa-packs-admin-v2',plugins_url('../assets/pack-admin.201.js',__FILE__),array(),'2.0.1',true);
  wp_localize_script('shipaa-packs-admin-v2','SHIPAA_PACKS_V2',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('shipaa_packs_v2')));
 }
 public static function page(){
  if(!self::allowed())wp_die(esc_html__('You do not have permission to access this page.'));
  $courses=SHIPAA_Studiare::course_ids();
  $entries=array();
  foreach($courses as $id){
   $lessons=array();
   foreach(SHIPAA_Studiare::flat_lessons($id) as $l){$lessons[]=array('key'=>$l['key'],'name'=>$l['title']);}
   $entries[]=array('id'=>$id,'name'=>get_the_title($id),'lessons'=>$lessons);
  }
  $selected=absint($_GET['course']??0);
  echo '<div class="wrap shipaa-pack-manager" dir="rtl" id="shipaa-packs-v2">';
  echo '<div class="spm-head"><div><span class="spm-eyebrow">شیپا · خانه یادگیری</span><h1>بسته‌های یادگیری جلسات</h1><p>توضیحات و محتوای تکمیلی هر جلسه مستقل از جلسه‌های دیگر ذخیره می‌شود.</p></div><span class="spm-bubble" aria-hidden="true">✦</span></div>';
  echo '<div class="spm-card"><div class="spm-pickers"><label>۱. دوره <select id="spm-course"><option value="">انتخاب دوره</option></select></label><label>۲. جلسه <select id="spm-lesson" disabled><option value="">ابتدا یک دوره انتخاب کنید</option></select></label></div>';
  echo '<div id="spm-editor" hidden><div class="spm-subtitle"><div><span class="spm-kicker">بسته یادگیری جلسه</span><h2 id="spm-session-title"></h2></div><span id="spm-state" aria-live="polite" role="status"></span></div>';
  echo '<label for="spm-description">توضیحات تکمیلی جلسه</label><textarea id="spm-description" rows="8" maxlength="15000" placeholder="توضیحات آموزشی، خلاصه مباحث، مسیر مطالعه، نکته‌های کاربردی و…"></textarea><p class="spm-hint">متن طولانی هم پشتیبانی می‌شود؛ شکست خطوط در صفحه مخاطب حفظ خواهد شد.</p>';
  echo '<div class="spm-content-head"><h3>فایل‌ها و محتوای همراه</h3><div><button id="spm-media" class="button" type="button">افزودن از رسانه</button><button id="spm-add" class="button" type="button">+ لینک یا فایل جدید</button></div></div>';
  echo '<div id="spm-rows" class="spm-rows"></div><div class="spm-actions"><button id="spm-save" class="button button-primary button-hero" type="button">ذخیره بسته این جلسه</button><p>فقط محتوای همین جلسه ذخیره می‌شود.</p></div></div>';
  echo '<div id="spm-intro" class="spm-intro">ابتدا دوره و جلسه را انتخاب کنید تا محتواهای مرتبط نمایش داده شوند.</div></div>';
  echo '<script type="application/json" id="spm-config">'.wp_json_encode(array('courses'=>$entries,'selected'=>$selected),JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT).'</script>';
  echo '</div>';
 }
 public static function ajax(){
  if(!self::allowed())wp_send_json_error(array('message'=>'شما مجوز مدیریت بسته‌ها را ندارید.'),403);
  if(!check_ajax_referer('shipaa_packs_v2','nonce',false))wp_send_json_error(array('message'=>'نشست منقضی شده؛ صفحه را تازه‌سازی کنید.'),403);
  $course=absint($_POST['course']??0);
  $lesson=sanitize_text_field(wp_unslash($_POST['lesson']??''));
  $match=SHIPAA_Studiare::find_lesson($course,$lesson);
  if(!SHIPAA_Studiare::is_course($course)||!$lesson||empty($match[0]))wp_send_json_error(array('message'=>'دوره یا جلسه معتبر نیست.'),404);
  $mode=sanitize_key($_POST['mode']??'');
  if($mode==='read')wp_send_json_success(self::get($course,$lesson));
  if($mode!=='save')wp_send_json_error(array('message'=>'درخواست نامعتبر است.'),400);
  $description=sanitize_textarea_field(wp_unslash((string)($_POST['description']??'')));
  if(function_exists('mb_substr'))$description=mb_substr($description,0,15000);else $description=substr($description,0,15000);
  $raw=wp_unslash((string)($_POST['items']??'[]'));
  $items=json_decode($raw,true);
  if(!is_array($items))wp_send_json_error(array('message'=>'فرمت فهرست فایل‌ها صحیح نیست.'),400);
  $clean=array();
  foreach(array_slice($items,0,40) as $item){
   if(!is_array($item))continue;
   $link=esc_url_raw((string)($item['url']??''),array('http','https'));
   if(!preg_match('#^https?://#i',$link))continue;
   $kind=(string)($item['type']??'file');
   if(!in_array($kind,array('note','slide','audio','image','summary','file','video'),true))$kind='file';
   $clean[]=array('title'=>sanitize_text_field($item['title']??''),'url'=>$link,'type'=>$kind);
  }
  $all=get_post_meta($course,self::META,true);if(!is_array($all))$all=array();
  if(!$clean&&trim($description)==='')unset($all[$lesson]);
  else $all[$lesson]=array('description'=>$description,'items'=>$clean);
  update_post_meta($course,self::META,$all);
  wp_send_json_success(self::get($course,$lesson));
 }
}
