<?php
if (!defined('ABSPATH')) exit;

final class SHIPAA_Profile_Integrated {
 public static function boot(){
  add_action('admin_post_shipaa_profile_save',array(__CLASS__,'save'));
 }

 private static function get($id,$key){return (string)get_user_meta($id,$key,true);} 

 public static function provinces(){
  return array('آذربایجان شرقی','آذربایجان غربی','اردبیل','اصفهان','البرز','ایلام','بوشهر','تهران','چهارمحال و بختیاری','خراسان جنوبی','خراسان رضوی','خراسان شمالی','خوزستان','زنجان','سمنان','سیستان و بلوچستان','فارس','قزوین','قم','کردستان','کرمان','کرمانشاه','کهگیلویه و بویراحمد','گلستان','گیلان','لرستان','مازندران','مرکزی','هرمزگان','همدان','یزد');
 }

 public static function city_map(){
  return array(
   'آذربایجان شرقی'=>array('تبریز','مراغه','مرند','میانه','اهر','بناب','آذرشهر','شبستر'),
   'آذربایجان غربی'=>array('ارومیه','خوی','مهاباد','بوکان','سلماس','نقده','میاندوآب','پیرانشهر'),
   'اردبیل'=>array('اردبیل','پارس‌آباد','خلخال','مشگین‌شهر','گرمی','نمین'),
   'اصفهان'=>array('اصفهان','کاشان','نجف‌آباد','خمینی‌شهر','شاهین‌شهر','فولادشهر','نائین','شهرضا'),
   'البرز'=>array('کرج','فردیس','نظرآباد','هشتگرد','طالقان'),
   'ایلام'=>array('ایلام','دهلران','ایوان','آبدانان','مهران'),
   'بوشهر'=>array('بوشهر','دشتستان','گناوه','دیلم','کنگان','جم'),
   'تهران'=>array('تهران','ری','اسلامشهر','شهریار','قدس','ملارد','ورامین','پاکدشت','دماوند','پردیس'),
   'چهارمحال و بختیاری'=>array('شهرکرد','بروجن','فارسان','لردگان','اردل'),
   'خراسان جنوبی'=>array('بیرجند','قائن','فردوس','طبس','نهبندان'),
   'خراسان رضوی'=>array('مشهد','نیشابور','سبزوار','تربت حیدریه','کاشمر','قوچان','چناران','تربت جام'),
   'خراسان شمالی'=>array('بجنورد','شیروان','اسفراین','جاجرم','فاروج'),
   'خوزستان'=>array('اهواز','آبادان','خرمشهر','دزفول','اندیمشک','بهبهان','شوشتر','ماهشهر'),
   'زنجان'=>array('زنجان','ابهر','خرمدره','قیدار'),
   'سمنان'=>array('سمنان','شاهرود','دامغان','گرمسار','مهدی‌شهر'),
   'سیستان و بلوچستان'=>array('زاهدان','زابل','ایرانشهر','چابهار','خاش','سراوان'),
   'فارس'=>array('شیراز','مرودشت','کازرون','جهرم','فسا','لار','داراب','فیروزآباد'),
   'قزوین'=>array('قزوین','البرز','تاکستان','آبیک','بوئین‌زهرا'),
   'قم'=>array('قم'),
   'کردستان'=>array('سنندج','سقز','مریوان','بانه','بیجار','قروه'),
   'کرمان'=>array('کرمان','سیرجان','رفسنجان','جیرفت','بم','زرند'),
   'کرمانشاه'=>array('کرمانشاه','اسلام‌آباد غرب','سنقر','کنگاور','پاوه','جوانرود'),
   'کهگیلویه و بویراحمد'=>array('یاسوج','گچساران','دهدشت'),
   'گلستان'=>array('گرگان','گنبدکاووس','علی‌آباد','آق‌قلا','مینودشت'),
   'گیلان'=>array('رشت','انزلی','لاهیجان','لنگرود','آستارا','رودسر'),
   'لرستان'=>array('خرم‌آباد','بروجرد','دورود','الیگودرز','کوهدشت'),
   'مازندران'=>array('ساری','بابل','آمل','قائم‌شهر','نوشهر','تنکابن','چالوس'),
   'مرکزی'=>array('اراک','ساوه','خمین','محلات','دلیجان'),
   'هرمزگان'=>array('بندرعباس','میناب','قشم','بندر لنگه','حاجی‌آباد'),
   'همدان'=>array('همدان','ملایر','نهاوند','تویسرکان','کبودرآهنگ'),
   'یزد'=>array('یزد','میبد','اردکان','تفت','ابرکوه')
  );
 }

 private static function choices(){
  return array(
   'education'=>array('کاردانی','کارشناسی','کارشناسی ارشد','دکتری','سطح 1 یا 2 حوزه','سطح 3 یا 4 حوزه','سایر موارد'),
   'gender'=>array('مرد','زن'),
   'marital'=>array('مجرد','متاهل')
  );
 }

 private static function fa_to_en_digits($value){
  return strtr((string)$value,array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'));
 }

 private static function national_ok($code){
  if(!preg_match('/^[0-9]{10}$/',$code)||preg_match('/^(\d)\1{9}$/',$code))return false;
  $sum=0;for($i=0;$i<9;$i++)$sum+=(int)$code[$i]*(10-$i);$r=$sum%11;$v=$r<2?$r:11-$r;return $v===(int)$code[9];
 }

 public static function completion_percent($id){ return self::completion($id); }

 private static function completion($id){
  $keys=array('first_name','last_name','billing_phone','shipaa_national_id','shipaa_province','shipaa_city','shipaa_education','shipaa_field','shipaa_occupation','shipaa_referral');
  $filled=0;foreach($keys as $k){if(trim(self::get($id,$k))!=='')$filled++;}
  return (int)round(($filled/max(count($keys),1))*100);
 }

 public static function avatar_url($user_id,$size=96){
  $attachment_id=absint(get_user_meta($user_id,'shipaa_avatar_id',true));
  if($attachment_id){
   $src=wp_get_attachment_image_url($attachment_id,array($size,$size));
   if($src)return $src;
  }
  // سازگاری با عکس‌های پیشین وردپرس/اپ شیپا: فقط یک تصویر واحد در همه پنل‌ها.
  $existing=get_user_meta($user_id,'profile_picture',true);
  if(is_numeric($existing))return wp_get_attachment_image_url((int)$existing,array($size,$size))?:'';
  if(is_string($existing) && $existing && in_array(strtolower((string)wp_parse_url($existing,PHP_URL_SCHEME)),array('http','https'),true))return esc_url_raw($existing);
  return '';
 }

 public static function avatar_markup($user_id,$class='',$size=72,$alt=''){
  $src=self::avatar_url($user_id,$size);
  $alt=$alt?:'تصویر پروفایل';
  if(!$src){
   $gender=(string)get_user_meta($user_id,'shipaa_gender',true);
   $emoji=$gender==='زن'?'👩':($gender==='مرد'?'👨':'👤');
   return '<span class="sip-avatar-fallback '.esc_attr($class).'" role="img" aria-label="تصویر پروفایل انتخاب نشده">'.$emoji.'</span>';
  }
  return '<img class="'.esc_attr(trim('sip-avatar-img '.$class)).'" src="'.esc_url($src).'" alt="'.esc_attr($alt).'" loading="lazy" />';
 }

 private static function handle_upload($uid){
  if(empty($_FILES['shipaa_avatar_upload']['name']))return;
  if(!function_exists('wp_handle_upload'))require_once ABSPATH.'wp-admin/includes/file.php';
  if(!function_exists('wp_insert_attachment'))require_once ABSPATH.'wp-admin/includes/image.php';
  $file=$_FILES['shipaa_avatar_upload'];
  if(!empty($file['error']) && (int)$file['error']!==UPLOAD_ERR_NO_FILE){throw new Exception('آپلود تصویر با خطا روبه‌رو شد.');}
  if((int)$file['error']===UPLOAD_ERR_NO_FILE)return;
  if(empty($file['size']) || (int)$file['size']>3*1024*1024)throw new Exception('حداکثر حجم تصویر ۳ مگابایت است.');
  $check=wp_check_filetype_and_ext($file['tmp_name'],$file['name']);
  if(!in_array($check['type']??'',array('image/jpeg','image/png','image/webp'),true))throw new Exception('فقط تصویر JPG، PNG یا WebP پذیرفته می‌شود.');
  $move=wp_handle_upload($file,array('test_form'=>false,'mimes'=>array('jpg|jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif')));
  if(!empty($move['error']))throw new Exception($move['error']);
  $attachment=array('post_mime_type'=>$move['type'],'post_title'=>sanitize_file_name(pathinfo($move['file'],PATHINFO_FILENAME)),'post_status'=>'inherit');
  $attachment_id=wp_insert_attachment($attachment,$move['file']);
  if(!$attachment_id)throw new Exception('ذخیره تصویر پروفایل انجام نشد.');
  $metadata=wp_generate_attachment_metadata($attachment_id,$move['file']);
  if($metadata)wp_update_attachment_metadata($attachment_id,$metadata);
  update_user_meta($uid,'shipaa_avatar_id',$attachment_id);
  update_user_meta($uid,'profile_picture',esc_url_raw(wp_get_attachment_image_url($attachment_id,'medium')?:$move['url']));
  update_user_meta($uid,'shipaa_avatar_mode','upload');
 }

 public static function save(){
  if(!is_user_logged_in())wp_die('ابتدا وارد حساب خود شوید.',403);
  if(!isset($_POST['_shipaa_profile_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_shipaa_profile_nonce'])),'shipaa_profile_save'))wp_die('درخواست معتبر نیست.',403);
  $uid=get_current_user_id();
  $values=array();
  foreach(array('first_name','last_name','billing_phone','shipaa_national_id','shipaa_province','shipaa_city','shipaa_age','shipaa_gender','shipaa_marital','shipaa_education','shipaa_field','shipaa_occupation','shipaa_referral') as $key){$values[$key]=sanitize_text_field(wp_unslash($_POST[$key]??''));}
  $values['shipaa_activities']=sanitize_textarea_field(wp_unslash($_POST['shipaa_activities']??''));

  $phone=preg_replace('/[^0-9]/','',self::fa_to_en_digits($values['billing_phone']));
  if(strpos($phone,'98')===0&&strlen($phone)===12)$phone='0'.substr($phone,2);
  $code=preg_replace('/[^0-9]/','',self::fa_to_en_digits($values['shipaa_national_id']));

  $error='';
  if(!$values['first_name']||!$values['last_name'])$error='نام و نام خانوادگی ضروری است.';
  elseif(!preg_match('/^09[0-9]{9}$/',$phone))$error='شماره موبایل معتبر وارد کنید.';
  elseif(!self::national_ok($code))$error='کد ملی معتبر وارد کنید.';
  elseif($values['shipaa_age']!==''&&(!ctype_digit(self::fa_to_en_digits($values['shipaa_age']))||(int)self::fa_to_en_digits($values['shipaa_age'])>120||(int)self::fa_to_en_digits($values['shipaa_age'])<1))$error='سن واردشده معتبر نیست.';
  elseif($values['shipaa_province']!=='' && !in_array($values['shipaa_province'],self::provinces(),true))$error='استان معتبر را انتخاب کنید.';
  else {
   foreach(self::choices() as $key=>$opts){if($values['shipaa_'.$key]!==''&&!in_array($values['shipaa_'.$key],$opts,true)){$error='یکی از گزینه‌های فرم معتبر نیست.';break;}}
  }

  $back=wp_get_referer();$target=($back&&wp_validate_redirect($back,false))?$back:home_url('/my-learning/');$target=remove_query_arg(array('shipaa_profile_status','shipaa_profile_message'),$target);
  if($error){wp_safe_redirect(add_query_arg(array('shipaa_profile_status'=>'error','shipaa_profile_message'=>rawurlencode($error)),$target).'#/account');exit;}

  $values['billing_phone']=$phone;$values['shipaa_national_id']=$code;$values['shipaa_age']=self::fa_to_en_digits($values['shipaa_age']);
  foreach($values as $key=>$value)update_user_meta($uid,$key,$value);
  update_user_meta($uid,'billing_first_name',$values['first_name']);
  update_user_meta($uid,'billing_last_name',$values['last_name']);
  wp_update_user(array('ID'=>$uid,'first_name'=>$values['first_name'],'last_name'=>$values['last_name'],'display_name'=>trim($values['first_name'].' '.$values['last_name'])));

  try { self::handle_upload($uid); } catch(Exception $e){ wp_safe_redirect(add_query_arg(array('shipaa_profile_status'=>'error','shipaa_profile_message'=>rawurlencode($e->getMessage())),$target).'#/account'); exit; }

  wp_safe_redirect(add_query_arg('shipaa_profile_status','saved',$target).'#/account');exit;
 }

 public static function render($u){
  $id=$u->ID; $status=sanitize_key($_GET['shipaa_profile_status']??''); $choices=self::choices(); $provinces=self::provinces(); $city_map=self::city_map(); $current_province=self::get($id,'shipaa_province'); $completion=self::completion($id);
  $v=function($k)use($id){return esc_attr(self::get($id,$k));};
  ob_start(); ?>
 <div class="sip-profile" id="shipaa-profile-form" data-sip-root>
  <div class="sip-head">
   <div class="sip-head-main">
    <div class="sip-avatar-wrap"><?php echo self::avatar_markup($id,'sip-avatar-main',88,'تصویر کاربر'); ?></div>
    <div><span class="sip-kicker">پرونده شخصی شما در شیپا</span><h2>اطلاعات من <span>🌱</span></h2><p>هرچه کامل‌تر باشد، ثبت‌نام‌های بعدی سریع‌تر انجام می‌شود.</p></div>
   </div>
   <div class="sip-progress"><strong><?php echo esc_html(number_format_i18n($completion));?>٪</strong><span>تکمیل پروفایل</span><small>برای صدور گواهی، نام و کد ملی ضروری است.</small></div>
  </div>
  <?php if($status==='saved'):?><p class="sip-alert sip-success" role="status">تغییرات شما ذخیره شد ✓</p><?php elseif($status==='error'):?><p class="sip-alert sip-error" role="alert"><?php echo esc_html(rawurldecode(sanitize_text_field(wp_unslash($_GET['shipaa_profile_message']??'اطلاعات را بررسی کنید.'))));?></p><?php endif;?>

  <form action="<?php echo esc_url(admin_url('admin-post.php'));?>" method="post" class="sip-form" enctype="multipart/form-data">
   <input type="hidden" name="action" value="shipaa_profile_save"><?php wp_nonce_field('shipaa_profile_save','_shipaa_profile_nonce'); ?>

   <div class="sip-section sip-section-avatar">
    <h3><span>۰۰</span> تصویر پروفایل</h3>
    <div class="sip-avatar-grid">
      <div class="sip-upload-box">
        <div class="sip-preview-box"><?php echo self::avatar_markup($id,'sip-avatar-preview',112,'پیش‌نمایش آواتار'); ?></div>
        <label class="sip-upload-control">انتخاب تصویر از گوشی یا رایانه
          <input type="file" accept="image/*" name="shipaa_avatar_upload" data-sip-upload>
        </label>
        <small>JPG، PNG یا WebP تا ۳ مگابایت. تغییر تصویر بلافاصله ذخیره می‌شود.</small><p class="sip-avatar-notice" role="status" aria-live="polite" data-sp-photo-status></p><button class="sip-avatar-remove" type="button" data-sp-photo-remove>حذف تصویر پروفایل</button>
      </div>

    </div>
   </div>

   <div class="sip-section"><h3><span>۰۱</span> اطلاعات اصلی</h3><div class="sip-grid"><label>نام <b>*</b><input required maxlength="80" name="first_name" autocomplete="given-name" value="<?php echo $v('first_name');?>"></label><label>نام خانوادگی <b>*</b><input required maxlength="80" name="last_name" autocomplete="family-name" value="<?php echo $v('last_name');?>"></label><label>شماره موبایل <b>*</b><input required name="billing_phone" inputmode="tel" autocomplete="tel" maxlength="16" placeholder="09123456789" value="<?php echo $v('billing_phone');?>"><small>برای ارتباط و پیگیری ثبت‌نام</small></label><label>کد ملی <b>*</b><input required name="shipaa_national_id" inputmode="numeric" maxlength="10" placeholder="۱۰ رقم" value="<?php echo $v('shipaa_national_id');?>"><small>برای پرونده و صدور گواهی؛ خصوصی</small></label><label>استان<select name="shipaa_province" data-sip-province><option value="">انتخاب کنید</option><?php foreach($provinces as $province):?><option value="<?php echo esc_attr($province);?>" <?php selected($current_province,$province);?>><?php echo esc_html($province);?></option><?php endforeach;?></select></label><label>شهرستان<input name="shipaa_city" maxlength="80" list="shipaa-city-suggestions" data-sip-city value="<?php echo $v('shipaa_city');?>" placeholder="از پیشنهادها انتخاب کنید یا بنویسید"><datalist id="shipaa-city-suggestions"><?php foreach(($city_map[$current_province]??array()) as $city):?><option value="<?php echo esc_attr($city);?>"></option><?php endforeach;?></datalist></label></div></div>

   <div class="sip-section"><h3><span>۰۲</span> اطلاعات فردی و تحصیلی <small>تکمیل اختیاری</small></h3><div class="sip-grid"><label>سن<input name="shipaa_age" inputmode="numeric" maxlength="3" value="<?php echo $v('shipaa_age');?>"></label>
   <?php foreach(array('gender'=>'جنسیت','marital'=>'وضعیت تأهل','education'=>'مدرک تحصیلی') as $key=>$title):?><label><?php echo esc_html($title);?><select name="shipaa_<?php echo esc_attr($key);?>"><option value="">انتخاب کنید</option><?php foreach($choices[$key] as $opt):?><option value="<?php echo esc_attr($opt);?>" <?php selected(self::get($id,'shipaa_'.$key),$opt);?>><?php echo esc_html($opt);?></option><?php endforeach;?></select></label><?php endforeach;?><label class="sip-full">رشته تحصیلی<input name="shipaa_field" maxlength="160" value="<?php echo $v('shipaa_field');?>"></label></div></div>

   <div class="sip-section"><h3><span>۰۳</span> فعالیت‌ها و آشنایی با شیپا <small>تکمیل اختیاری</small></h3><div class="sip-grid"><label class="sip-full">شغل و حوزه فعالیت<input name="shipaa_occupation" maxlength="200" value="<?php echo $v('shipaa_occupation');?>"></label><label class="sip-full">فعالیت‌های اجتماعی و فرهنگی<textarea name="shipaa_activities" rows="3" maxlength="2500"><?php echo esc_textarea(self::get($id,'shipaa_activities'));?></textarea></label><label class="sip-full">از چه طریق با شیپا آشنا شدید؟<input name="shipaa_referral" maxlength="160" value="<?php echo $v('shipaa_referral');?>"></label></div></div>

   <div class="sip-footer"><p>شماره موبایل و کد ملی در بخش عمومی نمایش داده نمی‌شوند. تغییر موبایل در این نسخه هنوز تأیید پیامکی ندارد.</p><button type="submit">ذخیره تغییرات ✓</button></div>
  </form>
 </div>
 <script type="application/json" class="sip-city-map"><?php echo wp_json_encode($city_map,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);?></script>
 <?php return ob_get_clean();
 }
}
SHIPAA_Profile_Integrated::boot();
