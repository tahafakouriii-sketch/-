<?php
/**
 * SHIPAA ↔ Studiare (استادیار) bridge.
 * - خواندن ساختار دوره از متای lessons_group استادیار (هر دو حالت: شناسه نوشته‌ی درس یا درس درون‌خطی)
 * - بررسی مجوز با studi_has_bought_items و در نبود آن wc_customer_bought_product
 * - استخراج منبع ویدئو/صوت/جاسازی/فایل هر جلسه برای پلیر داخلی
 * - ذخیره پیشرفت تماشا در user meta (بدون جدول جدید)
 */
if (!defined('ABSPATH')) exit;

final class SHIPAA_Studiare {
 const META_PROGRESS = '_shipaa_learning';
 const NONCE = 'shipaa_learn';
 private static $structure_cache = array();

 public static function boot(){
  add_action('wp_ajax_shipaa_l3_lesson', array(__CLASS__,'ajax_lesson'));
  add_action('wp_ajax_shipaa_l3_progress', array(__CLASS__,'ajax_progress'));
 }

 /* ---------- دوره‌ها و مجوز ---------- */
 public static function course_ids(){
  return array_map('absint', get_posts(array('post_type'=>'product','post_status'=>'publish','posts_per_page'=>200,'fields'=>'ids','no_found_rows'=>true,'meta_query'=>array(array('key'=>'_studiare_course','value'=>'yes')))));
 }
 public static function is_course($pid){ return $pid && get_post_meta($pid,'_studiare_course',true)==='yes'; }
 public static function enrolled($uid,$pid){
  if(!$uid || !$pid) return false;
  if(user_can($uid,'manage_woocommerce') && apply_filters('shipaa_admin_can_preview_courses', true)) return true;
  if(class_exists('SHIPAA_Access') && SHIPAA_Access::has($uid,$pid)) return true;
  if(function_exists('studi_has_bought_items') && in_array(studi_has_bought_items($uid,$pid),array(true,1,'1','true'),true)) return true;
  $u=get_userdata($uid);
  return (bool)($u && function_exists('wc_customer_bought_product') && wc_customer_bought_product($u->user_email,$uid,$pid));
 }

 /* ---------- ساختار سرفصل‌ها ---------- */
 private static function first_key($arr,$keys){
  foreach($keys as $k) if(isset($arr[$k]) && is_scalar($arr[$k]) && trim((string)$arr[$k])!=='') return trim((string)$arr[$k]);
  return '';
 }
 private static function key_like($arr,$needles){
  foreach($arr as $k=>$v){ if(!is_scalar($v)) continue; foreach($needles as $n) if(stripos((string)$k,$n)!==false && trim((string)$v)!=='') return trim((string)$v); }
  return '';
 }
 private static function truthy($v){ return in_array(strtolower(trim((string)$v)),array('1','yes','on','true','private'),true); }

 public static function structure($pid){
  $pid=absint($pid);
  if(isset(self::$structure_cache[$pid])) return self::$structure_cache[$pid];
  $groups=get_post_meta($pid,'lessons_group',true);
  $modules=array(); $total=0;
  if(is_array($groups)) foreach(array_values($groups) as $si=>$section){
   if(!is_array($section)) continue;
   $raw=$section['lessons_list'] ?? ($section['lessons'] ?? ($section['lesson'] ?? array()));
   $raw=maybe_unserialize($raw);
   if(is_string($raw)) $raw=array_filter(array_map('trim',explode(',',$raw)));
   $entries=array();
   foreach((array)$raw as $li=>$item){
    if(is_numeric($item)){
     $lid=absint($item);
     if(!$lid || get_post_status($lid)!=='publish') continue;
     $title=wp_strip_all_tags(get_the_title($lid));
     $entries[]=array('key'=>'p'.$lid,'post'=>$lid,'title'=>$title!==''?$title:'جلسه '.($total+1),'url'=>get_permalink($lid),'duration'=>self::post_duration($lid),'raw'=>null);
     $total++;
    } elseif(is_array($item)){
     $title=wp_strip_all_tags(self::first_key($item,array('title','lesson_title','name','subtitle')));
     $entries[]=array('key'=>'i'.$pid.'_'.$si.'_'.$li,'post'=>0,'title'=>$title!==''?$title:'جلسه '.($total+1),'url'=>get_permalink($pid),'duration'=>wp_strip_all_tags(self::key_like($item,array('duration','time','length'))),'raw'=>$item);
     $total++;
    }
   }
   $modules[]=array(
    'title'=>wp_strip_all_tags($section['title'] ?? 'بخش آموزشی'),
    'number'=>wp_strip_all_tags($section['section_num_title'] ?? ''),
    'lessons'=>$entries
   );
  }
  $s=array('id'=>$pid,'title'=>get_the_title($pid),'image'=>get_the_post_thumbnail_url($pid,'large')?:'','url'=>get_permalink($pid),'modules'=>$modules,'count'=>$total);
  return self::$structure_cache[$pid]=$s;
 }
 private static function post_duration($lid){
  foreach(array('lesson_duration','_lesson_duration','duration','studiare_lesson_time','lesson_time') as $k){ $v=get_post_meta($lid,$k,true); if(is_scalar($v) && trim((string)$v)!=='') return wp_strip_all_tags((string)$v); }
  return '';
 }
 public static function flat_lessons($pid){
  $out=array(); foreach(self::structure($pid)['modules'] as $mi=>$m) foreach($m['lessons'] as $l){ $l['module']=$mi; $out[]=$l; }
  return $out;
 }
 public static function find_lesson($pid,$key){
  $flat=self::flat_lessons($pid);
  foreach($flat as $i=>$l) if($l['key']===$key) return array($l,$i,$flat);
  return array(null,-1,$flat);
 }

 /* ---------- استخراج رسانه ---------- */
 private static function collect_strings($value,&$out,$depth=0){
  if($depth>6) return;
  $value=maybe_unserialize($value);
  if(is_array($value)||is_object($value)){ foreach((array)$value as $v) self::collect_strings($v,$out,$depth+1); return; }
  if(is_scalar($value)){ $s=trim((string)$value); if($s!=='' && strlen($s)<20000 && (stripos($s,'http')!==false || stripos($s,'<iframe')!==false || stripos($s,'[video')!==false || stripos($s,'[audio')!==false || preg_match('#\.(mp4|m4v|webm|m3u8|mp3|m4a|og[ga]|wav|aac|opus|pdf|zip|rar)\b#i',$s))) $out[]=$s; }
 }
 private static function urls_in($text){
  $urls=array();
  if(preg_match_all('#(?:src|href|data-src|mp4|m4v|webm|mp3|file)\s*=\s*["\']([^"\']+)["\']#i',$text,$m)) $urls=array_merge($urls,$m[1]);
  if(preg_match_all('#https?://[^\s"\'<>\]\[]+#i',$text,$m)) $urls=array_merge($urls,$m[0]);
  $bare=trim($text); if($bare!=='' && $bare[0]==='/' && !preg_match('#\s#',$bare)) $urls[]=$bare;
  $urls=array_map(function($u){ $u=html_entity_decode(trim($u),ENT_QUOTES); if(isset($u[1]) && $u[0]==='/' && $u[1]!=='/') $u=home_url($u); elseif(strpos($u,'//')===0) $u='https:'.$u; return $u; },$urls);
  return array_values(array_unique(array_filter($urls,function($u){ return preg_match('#^https?://#i',$u); })));
 }
 public static function classify($url){
  $u=strtolower($url); $path=strtolower((string)parse_url($url,PHP_URL_PATH));
  if(preg_match('#\.(mp4|m4v|webm|ogv|mov)$#',$path)) return array('video',esc_url_raw($url));
  if(preg_match('#\.m3u8$#',$path)) return array('hls',esc_url_raw($url));
  if(preg_match('#\.(mp3|m4a|aac|oga|ogg|wav|opus)$#',$path)) return array('audio',esc_url_raw($url));
  if(preg_match('#aparat\.com/v/([a-z0-9]+)#i',$url,$m)) return array('embed','https://www.aparat.com/video/video/embed/videohash/'.$m[1].'/vt/frame');
  if(strpos($u,'aparat.com/video/video/embed')!==false) return array('embed',esc_url_raw($url));
  if(preg_match('#(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([\w-]{6,})#i',$url,$m)) return array('embed','https://www.youtube-nocookie.com/embed/'.$m[1]);
  if(preg_match('#(arvancloud|arvanvod|player\.|/embed/|iframe)#i',$u) && !preg_match('#\.(js|css|png|jpe?g|gif|svg|webp)(\?|$)#',$u)) return array('embed',esc_url_raw($url));
  if(preg_match('#\.(pdf|zip|rar|7z|docx?|pptx?|xlsx?|epub)$#',$path)) return array('file',esc_url_raw($url));
  return array('',null);
 }
 private static function allowed_html(){
  $tags=wp_kses_allowed_html('post');
  $tags['iframe']=array('src'=>true,'width'=>true,'height'=>true,'allow'=>true,'allowfullscreen'=>true,'frameborder'=>true,'loading'=>true,'title'=>true,'style'=>true);
  $tags['video']=array('src'=>true,'controls'=>true,'poster'=>true,'preload'=>true,'width'=>true,'height'=>true,'playsinline'=>true);
  $tags['audio']=array('src'=>true,'controls'=>true,'preload'=>true);
  $tags['source']=array('src'=>true,'type'=>true);
  return $tags;
 }
 public static function media($course_id,$lesson){
  $strings=array(); $html='';
  if($lesson['post']){
   $post=get_post($lesson['post']);
   foreach((array)get_post_meta($lesson['post']) as $k=>$vals){ if(strpos($k,'_edit_')===0||$k==='_thumbnail_id') continue; self::collect_strings($vals,$strings); }
   if($post){
    $content=$post->post_content;
    if(stripos($content,'[video')!==false||stripos($content,'[audio')!==false||stripos($content,'[embed')!==false) $content=do_shortcode($content);
    $rendered=apply_filters('the_content',$post->post_content);
    $strings[]=$content; $strings[]=$rendered;
    $html=wp_kses($rendered,self::allowed_html());
   }
   if(function_exists('get_attached_media')) foreach(array('video','audio') as $t) foreach((array)get_attached_media($t,$lesson['post']) as $att) $strings[]=wp_get_attachment_url($att->ID);
  } elseif(is_array($lesson['raw'])){
   self::collect_strings($lesson['raw'],$strings);
   $desc=self::first_key($lesson['raw'],array('content','description','desc','subtitle'));
   if($desc!=='') $html=wp_kses(wpautop($desc),self::allowed_html());
  }
  $found=array('video'=>array(),'hls'=>array(),'audio'=>array(),'embed'=>array(),'file'=>array());
  foreach($strings as $s){ foreach(self::urls_in($s) as $u){ list($type,$clean)=self::classify($u); if($type && $clean && !in_array($clean,$found[$type],true)) $found[$type][]=$clean; } }
  $kind='text'; $src=''; $sources=array();
  if($found['video']){ $kind='video'; $src=$found['video'][0]; $sources=$found['video']; }
  elseif($found['hls']){ $kind='hls'; $src=$found['hls'][0]; }
  elseif($found['audio']){ $kind='audio'; $src=$found['audio'][0]; $sources=$found['audio']; }
  elseif($found['embed']){ $kind='embed'; $src=$found['embed'][0]; }
  elseif(trim(wp_strip_all_tags($html))===''){ $kind='link'; }
  // جلوگیری از تکرار پلیر داخل متن جلسه
  if(in_array($kind,array('video','audio','hls','embed'),true) && $html) $html=preg_replace('#<(video|audio|iframe)\b[^>]*>.*?</\1>|<(video|audio|iframe)\b[^>]*/?>#is','',$html);
  $files=array(); foreach($found['file'] as $f){ $name=wp_basename(parse_url($f,PHP_URL_PATH)); $files[]=array('url'=>$f,'name'=>urldecode($name)); }
  $pack=class_exists('SHIPAA_Learning_Packs_V2')?SHIPAA_Learning_Packs_V2::get($course_id,$lesson['key']):array();
  $payload=array('pack'=>$pack,'kind'=>$kind,'src'=>$src,'sources'=>$sources,'files'=>$files,'html'=>trim((string)$html),'page'=>$lesson['url']);
  return apply_filters('shipaa_lesson_media',$payload,$course_id,$lesson);
 }

 /* ---------- پیشرفت ---------- */
 public static function progress($uid){ $p=get_user_meta($uid,self::META_PROGRESS,true); return is_array($p)?$p:array(); }
 public static function course_progress($uid,$pid){
  $all=self::progress($uid); $c=$all[$pid]??array(); $lessons=isset($c['lessons'])&&is_array($c['lessons'])?$c['lessons']:array();
  $total=self::structure($pid)['count']; $done=0; $valid=array(); foreach(self::flat_lessons($pid) as $l) $valid[$l['key']]=true;
  foreach($lessons as $k=>$v) if(isset($valid[$k]) && !empty($v['done'])) $done++;
  return array('done'=>$done,'total'=>$total,'percent'=>$total?(int)round($done*100/$total):0,'last'=>$c['last']??'','t'=>(int)($c['t']??0),'lessons'=>$lessons);
 }
 /** آخرین جلسه‌ای که کاربر در یکی از دوره‌های فعال خود باز کرده است. */
 public static function resume($uid,$active){
  $best=null; $all=self::progress($uid);
  foreach($active as $pid){ if(empty($all[$pid]['last'])) continue; if(!$best || (int)$all[$pid]['t']>$best['t']) $best=array('course'=>(int)$pid,'key'=>(string)$all[$pid]['last'],'t'=>(int)$all[$pid]['t']); }
  if($best){ list($l)=self::find_lesson($best['course'],$best['key']); if(!$l) return null; $best['title']=$l['title']; $p=$all[$best['course']]['lessons'][$best['key']]??array(); $best['pos']=(int)($p['p']??0); $best['dur']=(int)($p['d']??0); }
  return $best;
 }
 private static function save_progress($uid,$pid,$key,$pos=null,$dur=null,$done=null){
  $all=self::progress($uid); if(!isset($all[$pid])||!is_array($all[$pid])) $all[$pid]=array('lessons'=>array());
  $row=$all[$pid]['lessons'][$key] ?? array();
  if($pos!==null) $row['p']=max(0,(int)$pos);
  if($dur!==null && $dur>0) $row['d']=(int)$dur;
  // Completion is no longer granted from seeking or client-controlled 'done'.
  // Existing historical completions remain visible. New completions use watched time.

  $row['t']=time();
  $all[$pid]['lessons'][$key]=$row; $all[$pid]['last']=$key; $all[$pid]['t']=time();
  if(count($all)>60) $all=array_slice($all,-60,null,true);
  update_user_meta($uid,self::META_PROGRESS,$all);
  return $row;
 }

 /* ---------- AJAX ---------- */
 private static function guard(){
  if(!is_user_logged_in()) wp_send_json_error(array('message'=>'برای ادامه، دوباره وارد حساب شیپا شوید.'),401);
  if(!check_ajax_referer(self::NONCE,'nonce',false)) wp_send_json_error(array('message'=>'صفحه مدتی باز مانده است؛ یک بار تازه‌سازی کنید.'),403);
  $uid=get_current_user_id(); $pid=absint($_POST['course']??0); $key=sanitize_text_field(wp_unslash($_POST['lesson']??''));
  if(!self::is_course($pid)) wp_send_json_error(array('message'=>'این دوره پیدا نشد.'),404);
  if(!self::enrolled($uid,$pid)) wp_send_json_error(array('message'=>'دسترسی این دوره هنوز برای شما فعال نشده است.'),403);
  list($lesson,$index,$flat)=self::find_lesson($pid,$key);
  if(!$lesson) wp_send_json_error(array('message'=>'این جلسه در سرفصل دوره پیدا نشد.'),404);
  return array($uid,$pid,$lesson,$index,$flat);
 }
 public static function ajax_lesson(){
  list($uid,$pid,$lesson,$index,$flat)=self::guard();
  $row=self::save_progress($uid,$pid,$lesson['key']);
  $media=self::media($pid,$lesson);
  $cp=self::course_progress($uid,$pid);
  wp_send_json_success(array(
   'key'=>$lesson['key'],'title'=>$lesson['title'],'index'=>$index+1,'total'=>count($flat),
   'module'=>self::structure($pid)['modules'][$lesson['module']]['title'] ?? '',
   'prev'=>$index>0?$flat[$index-1]['key']:'','next'=>isset($flat[$index+1])?$flat[$index+1]['key']:'',
   'nextTitle'=>isset($flat[$index+1])?$flat[$index+1]['title']:'',
   'media'=>$media,'resume'=>(int)($row['p']??0),'done'=>!empty($row['done']),'course'=>array('done'=>$cp['done'],'total'=>$cp['total'],'percent'=>$cp['percent'])
  ));
 }
 public static function ajax_progress(){
  list($uid,$pid,$lesson)=self::guard();
  $pos=isset($_POST['pos'])?(int)$_POST['pos']:null; $dur=isset($_POST['dur'])?(int)$_POST['dur']:null;
  $watch=isset($_POST['watch'])?max(0,min(20,(int)$_POST['watch'])):0;
  // Per-lesson timestamp caps repeated updates; claimed watch time is not blindly trusted.
  $all=self::progress($uid);$prior=$all[$pid]['lessons'][$lesson['key']]??array();
  $now=time();$last=(int)($prior['watch_ping']??0);
  if($watch){
   $allow=$last?min(20,max(0,$now-$last)):min(20,$watch);
   $watch=min($watch,$allow);
  }
  $row=self::save_progress($uid,$pid,$lesson['key'],$pos,$dur,null);
  $all=self::progress($uid);
  $row=$all[$pid]['lessons'][$lesson['key']];
  if($watch){$row['watched']=min(10000000,max(0,(int)($row['watched']??0))+$watch);}
  // A ping may arrive without watch time (pause/end), but never grants credit.
  $row['watch_ping']=$now;
  if(!empty($row['d']) && $row['d']>=10 && ($row['watched']??0)>=ceil($row['d']*.5))$row['done']=1;
  $all[$pid]['lessons'][$lesson['key']]=$row;update_user_meta($uid,self::META_PROGRESS,$all);
  $cp=self::course_progress($uid,$pid);
  wp_send_json_success(array('done'=>!empty($row['done']),'watched'=>(int)($row['watched']??0),'course'=>array('done'=>$cp['done'],'total'=>$cp['total'],'percent'=>$cp['percent'])));
 }
}
SHIPAA_Studiare::boot();
