<?php
/**
 * Plugin Name: SHIPAA Unified Dashboard
 * Description: خانه یادگیری و مرکز فرمان شیپا — متصل به سفارش‌های ووکامرس، مجوز و سرفصل‌های استادیار (Studiare) و پلیر داخلی جلسه‌ها.
 * Version: 2.1.9
 * Requires Plugins: woocommerce
 * Text Domain: shipaa-dashboard
 */
if (!defined('ABSPATH')) exit;
require_once __DIR__.'/includes/studiare.php';
require_once __DIR__.'/includes/access.php';
require_once __DIR__.'/includes/admin-dossier.php';
require_once __DIR__.'/includes/profile.php';
require_once __DIR__.'/includes/learner.php';
require_once __DIR__.'/includes/learning-auth.php';
require_once __DIR__.'/includes/avatar-180.php';
require_once __DIR__.'/includes/learning-packs-v2.php';

final class SHIPAA_Dashboard_V1 {
 const VER='2.1.9';
 public static function boot(){
  SHIPAA_Dashboard_Avatar180::boot();
  SHIPAA_Learning_Auth::boot();
  SHIPAA_Learning_Packs_V2::boot();
  add_action('template_redirect',array(__CLASS__,'account_entry'));
  add_shortcode('shipaa_dashboard_v1',array(__CLASS__,'learner'));
  add_shortcode('shipaa_command_v1',array(__CLASS__,'admin'));
  add_action('admin_menu',array(__CLASS__,'admin_menu'));
  add_action('admin_bar_menu',array(__CLASS__,'admin_bar'),80);
  add_action('wp_dashboard_setup',array(__CLASS__,'dashboard_widget'));
  add_action('admin_head',array(__CLASS__,'admin_menu_css'));
  add_action('wp_enqueue_scripts',array(__CLASS__,'assets'));
  add_action('wp_head',array(__CLASS__,'critical_mobile_geometry'),1);
  add_action('wp_ajax_shipaa_v1_get',array(__CLASS__,'ajax_get'));
  add_action('wp_ajax_shipaa_v1_approve',array(__CLASS__,'approve'));
  add_action('wp_ajax_shipaa_v1_request_changes',array(__CLASS__,'request_changes'));
  add_action('wp_ajax_shipaa_v1_queue',array(__CLASS__,'ajax_queue'));
  add_action('template_redirect',array(__CLASS__,'no_cache'),1);
  foreach(array('woocommerce_new_order','woocommerce_order_status_changed','woocommerce_checkout_order_processed') as $h) add_action($h,array(__CLASS__,'flush_count'));
 }
 public static function account_entry(){
  if(!is_user_logged_in() || is_admin() || !function_exists('is_account_page') || !is_account_page())return;
  if(function_exists('is_wc_endpoint_url') && is_wc_endpoint_url())return;
  if(strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='GET')return;
  $page=get_page_by_path('my-learning');
  if(!$page || $page->post_status!=='publish' || !has_shortcode($page->post_content,'shipaa_dashboard_v1') || is_page($page->ID))return;
  wp_safe_redirect(get_permalink($page->ID),302);exit;
 }
 /** نصب روی گوشی به مانیفست/PWA خود سایت سپرده شده تا با قابلیت دانلود نسخه وب تداخلی نداشته باشد. */
 public static function app_head(){}
 /** صفحه‌های شخصی/مدیریتی نباید در کش صفحه (AccelerateWP و مشابه) ذخیره شوند. */
 public static function no_cache(){
  if(!self::page_has('shipaa_dashboard_v1') && !self::page_has('shipaa_command_v1'))return;
  if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);
  if(!defined('DONOTCACHEOBJECT'))define('DONOTCACHEOBJECT',true);
  nocache_headers();
 }
 public static function flush_count(){ delete_transient('shipaa_pending_count'); }
 private static function page_has($tag){ global $post; return ($post instanceof WP_Post || is_object($post)) && isset($post->post_content) && has_shortcode((string)$post->post_content,$tag); }
 private static function course_ids(){return SHIPAA_Studiare::course_ids();}
 private static function validated_order($order){
  if(!$order || !is_a($order,'WC_Order'))return false;
  // ۱.۶.۲: همه سفارش‌های دوره (صفحه ثبت‌نام شیپا، تسویه‌حساب ووکامرس، دکمه خرید استادیار، سفارش دستی) وارد صف می‌شوند.
  $ok=false;
  foreach($order->get_items('line_item') as $item){
   $pid=absint($item->get_product_id());
   if($pid && get_post_meta($pid,'_studiare_course',true)==='yes')$ok=true;
  }
  return $ok;
 }
 private static function orders($args=array()){
  if(!function_exists('wc_get_orders'))return array();
  return wc_get_orders(wp_parse_args($args,array('limit'=>100,'orderby'=>'date','order'=>'DESC')));
 }

 /** Critical first-frame mobile layout: shipped inline before delayed/minified plugin CSS. */
 public static function critical_mobile_geometry(){
  if(!self::page_has('shipaa_dashboard_v1'))return;
  echo '<style id="shipaa-learner-critical-214">@media(max-width:900px){html:has([data-sp-root]),body:has([data-sp-root]){max-width:100%;overflow-x:clip}body:has([data-sp-root]) .sp-app{box-sizing:border-box!important;display:grid!important;grid-template-columns:minmax(0,1fr)!important;width:100%!important;max-width:100%!important;min-width:0!important;margin:0!important;position:relative!important;overflow-x:clip!important}body:has([data-sp-root]) .sp-app .sp-rail{display:none!important}body:has([data-sp-root]) .sp-app .sp-frame{grid-column:1!important;min-width:0!important;width:100%!important;max-width:100%!important}body:has([data-sp-root]) .sp-app .sp-stage,body:has([data-sp-root]) .sp-app .sp-screen,body:has([data-sp-root]) .sp-app .sp-learn,body:has([data-sp-root]) .sp-app .sp-learn-grid,body:has([data-sp-root]) .sp-app .sp-player-col,body:has([data-sp-root]) .sp-app .sp-player,body:has([data-sp-root]) .sp-app .sp-lesson-info{box-sizing:border-box!important;min-width:0!important;max-width:100%!important}body:has([data-sp-root]) .sp-app .sp-stage{width:100%!important;margin:0!important}body:has([data-sp-root]) .sp-app .sp-learn-grid{display:grid!important;grid-template-columns:minmax(0,1fr)!important}body:has([data-sp-root]) .sp-app .sp-player video,body:has([data-sp-root]) .sp-app .sp-player iframe{display:block;max-width:100%!important}body:has([data-sp-root]) .sp-app .sp-screen.is-entering{animation:none!important}}</style>';
 }
 public static function assets(){
  $learner=self::page_has('shipaa_dashboard_v1');
  $admin=self::page_has('shipaa_command_v1');
  if($learner){
   wp_enqueue_style('shipaa-app',self::asset('shipaa-app.css'),array(),self::VER);
   wp_enqueue_style('shipaa-profile-integrated',self::asset('profile.css'),array('shipaa-app'),self::VER);
   wp_enqueue_script('shipaa-host-fit',self::asset('host-fit.js'),array(),self::VER,true);
   wp_enqueue_script('shipaa-app',self::asset('shipaa-app.js'),array(),self::VER,true);
   wp_enqueue_script('shipaa-profile-integrated',self::asset('profile.js'),array(),self::VER,true);
   wp_enqueue_style('shipaa-learning-packs-v2',self::asset('learning-packs.css'),array('shipaa-app'),self::VER);
   wp_enqueue_style('shipaa-experience-180',self::asset('experience.css'),array('shipaa-app'),self::VER);
   wp_enqueue_script('shipaa-experience-180',self::asset('experience.js'),array('shipaa-profile-integrated','shipaa-app'),self::VER,true);
   wp_localize_script('shipaa-experience-180','SHIPAA_EXP180',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('shipaa_avatar180')));
   wp_localize_script('shipaa-app','SHIPAA_APP',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce(SHIPAA_Studiare::NONCE)));
  }
  if($admin){
   wp_enqueue_style('shipaa-dashboard-v1',self::asset('dashboard.css'),array(),self::VER);
   wp_enqueue_script('shipaa-host-fit',self::asset('host-fit.js'),array(),self::VER,true);
   wp_enqueue_script('shipaa-dashboard-v1',self::asset('dashboard.js'),array(),self::VER,true);
   wp_localize_script('shipaa-dashboard-v1','SHIPAA_V1',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('shipaa_v1'),'isAdmin'=>current_user_can('manage_woocommerce')));
   wp_enqueue_script('shipaa-admin-dossier-v13',self::asset('admin-dossier.js'),array('shipaa-dashboard-v1'),self::VER,true);
   wp_enqueue_style('shipaa-admin-experience-180',self::asset('admin-experience.css'),array('shipaa-dashboard-v1'),self::VER);
  }
  // Public/mobile site navigation is exclusively managed by Code Snippets #75.
  // This plugin intentionally neither enqueues nor modifies the site's #sm-nav.

 }
 /** نام فایل‌ها نسخه‌دار است تا کش/CDN که پارامتر ?ver را نادیده می‌گیرد، فایل قدیمی نفرستد. */
 private static function asset($file){ $dot=strrpos($file,'.'); return plugins_url('assets/'.substr($file,0,$dot).'.'.str_replace('.','',self::VER).substr($file,$dot),__FILE__); }
 private static function i($k){ return SHIPAA_Learner_V3::icon($k); }

 /* ---------- مرکز فرمان ---------- */
 private static function shell($title,$sections,$badges=array()){
  $tabs=array('overview'=>array('نمای کلی','home'),'requests'=>array('صف تأیید','receipt'),'people'=>array('مخاطبان','user'),'courses'=>array('دوره‌ها','book'));
  ob_start();?><div class="shipaa-v1" dir="rtl" data-sh-v1 data-kind="admin">
   <aside class="sv-side" aria-label="منوی مرکز فرمان">
    <a class="sv-brand" href="<?php echo esc_url(home_url('/'));?>"><img src="<?php echo esc_url(SHIPAA_Learner_V3::LOGO);?>" alt="شیپا" width="120" height="52"><small>مرکز فرمان</small></a>
    <nav class="sv-nav"><span class="sv-nav-ind" aria-hidden="true"></span>
     <?php foreach($tabs as $key=>$t):?><button type="button" class="sv-navbutton" data-tab="<?php echo esc_attr($key);?>" aria-pressed="<?php echo $key==='overview'?'true':'false';?>"><span class="sv-nav-ic"><?php echo self::i($t[1]); if(!empty($badges[$key])):?><b class="sv-badge"><?php echo esc_html(number_format_i18n($badges[$key]));?></b><?php endif;?></span><span><?php echo esc_html($t[0]);?></span></button><?php endforeach;?>
    </nav>
    <div class="sv-side-foot">
     <?php $me=wp_get_current_user();$mi=function_exists('mb_substr')?mb_substr($me->display_name,0,1):substr($me->display_name,0,1); ?><div class="sv-me"><span class="sv-me-ava"><?php echo esc_html($mi);?></span><span><strong><?php echo esc_html($me->display_name);?></strong><small>مدیر شیپا</small></span></div>
     <a href="<?php echo esc_url(home_url('/my-learning/'));?>"><?php echo self::i('playc');?> نمای مخاطب</a>
     <a href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order'));?>"><?php echo self::i('external');?> سفارش‌های ووکامرس</a>
     <p class="sv-motto"><?php echo self::i('leaf');?> یادگیری، نقطه آغاز حرکت</p>
    </div>
   </aside>
   <main class="sv-main" id="shipaa-v1-main">
    <header class="sv-top"><a class="sv-top-logo" href="<?php echo esc_url(home_url('/'));?>"><img src="<?php echo esc_url(SHIPAA_Learner_V3::LOGO);?>" alt="شیپا" width="80" height="34"></a><div><span class="sv-eyebrow">شبکه یاریگران پیشرفت ایران</span><h1><?php echo esc_html($title);?></h1></div><span class="sv-dash-label"><span class="sv-live"></span> داده زنده ووکامرس</span></header>
    <?php foreach($sections as $id=>$html):?><section class="sv-panel <?php echo $id==='overview'?'is-active':'';?>" data-panel="<?php echo esc_attr($id);?>" <?php echo $id==='overview'?'':'hidden';?>><?php echo $html; // Escaped by individual renderers ?></section><?php endforeach; ?>
   </main>
   <nav class="sv-bottom" aria-label="منوی مرکز فرمان"><span class="sv-bottom-ind" aria-hidden="true"></span><?php foreach($tabs as $key=>$t):?><button type="button" data-tab="<?php echo esc_attr($key);?>" aria-pressed="<?php echo $key==='overview'?'true':'false';?>"><span class="sv-nav-ic"><?php echo self::i($t[1]); if(!empty($badges[$key])):?><b class="sv-badge"><?php echo esc_html(number_format_i18n($badges[$key]));?></b><?php endif;?></span><span><?php echo esc_html($t[0]);?></span></button><?php endforeach;?></nav>
   <?php echo SHIPAA_Admin_Dossier_V13::modal(); ?>
   <div class="sv-sheet" data-sv-sheet hidden role="dialog" aria-modal="true" aria-labelledby="sv-sheet-title"><div class="sv-sheet-back" data-sv-sheet-close></div><div class="sv-sheet-card"><span class="sv-sheet-grip" aria-hidden="true"></span><h3 id="sv-sheet-title" data-sv-sheet-title></h3><p data-sv-sheet-desc></p><label class="sv-check" data-sv-sheet-check-wrap><input type="checkbox" data-sv-sheet-check> <span>رسید و مبلغ را مستقلاً در ایتا و سوابق بانکی بررسی کرده‌ام.</span></label><label class="sv-field" data-sv-sheet-note-wrap hidden><span>دلیل نیاز به اصلاح</span><textarea data-sv-sheet-note rows="3" maxlength="600" placeholder="مثلاً: مبلغ رسید با مبلغ دوره هم‌خوانی ندارد"></textarea></label><label class="sv-check sv-check-soft" data-sv-sheet-share-wrap hidden><input type="checkbox" data-sv-sheet-share checked> <span>این توضیح در صفحه ثبت‌نام‌های مخاطب هم نمایش داده شود.</span></label><div class="sv-sheet-actions"><button type="button" class="sv-button" data-sv-sheet-ok>ثبت تصمیم</button><button type="button" class="sv-button sv-secondary" data-sv-sheet-close>انصراف</button></div></div></div>
   <div class="sv-toast" role="status" aria-live="polite" hidden></div>
  </div><?php return ob_get_clean();
 }
 public static function learner(){ return SHIPAA_Learner_V3::render(); }

 /* ---------- میانبرهای پیشخوان وردپرس ---------- */
 /** آدرس برگه مرکز فرمان: اول /shipaa-command/، وگرنه هر برگه‌ای که شورت‌کد را دارد. */
 public static function command_url($frag=''){
  $url=get_option('shipaa_command_url');
  if(!$url){
   $page=get_page_by_path('shipaa-command');
   if(!$page||!has_shortcode((string)$page->post_content,'shipaa_command_v1')){
    $found=get_posts(array('post_type'=>'page','post_status'=>'publish','posts_per_page'=>1,'s'=>'[shipaa_command_v1]','fields'=>'ids'));
    $page=$found?get_post($found[0]):$page;
   }
   $url=$page?get_permalink($page->ID):home_url('/shipaa-command/');
   update_option('shipaa_command_url',$url,false);
  }
  return $url.($frag?'#'.$frag:'');
 }
 private static function learn_url(){ $p=get_page_by_path('my-learning'); return $p?get_permalink($p->ID):home_url('/my-learning/'); }
 /** تعداد ثبت‌نام‌های منتظر (کش ۱ دقیقه‌ای؛ با هر سفارش تازه پاک می‌شود) */
 public static function pending_count(){
  $n=get_transient('shipaa_pending_count');
  if($n===false){ $n=count(self::pending_orders()); set_transient('shipaa_pending_count',$n,MINUTE_IN_SECONDS); }
  return (int)$n;
 }
 public static function admin_menu(){
  if(!current_user_can('manage_woocommerce'))return;
  $n=self::pending_count();
  $badge=$n?' <span class="awaiting-mod count-'.$n.'"><span class="pending-count">'.esc_html(number_format_i18n($n)).'</span></span>':'';
  $hook=add_menu_page('مرکز فرمان شیپا','مرکز فرمان شیپا'.$badge,'manage_woocommerce','shipaa-command',array(__CLASS__,'admin_menu_page'),'dashicons-welcome-learn-more',2);
  add_action('load-'.$hook,array(__CLASS__,'admin_menu_redirect'));
  add_submenu_page('shipaa-command','نمای کلی','نمای کلی','manage_woocommerce','shipaa-command',array(__CLASS__,'admin_menu_page'));
  add_submenu_page('shipaa-command','صف تأیید','صف تأیید'.$badge,'manage_woocommerce',self::command_url('requests'));
  add_submenu_page('shipaa-command','مخاطبان','مخاطبان','manage_woocommerce',self::command_url('people'));
  add_submenu_page('shipaa-command','دوره‌ها','دوره‌ها','manage_woocommerce',self::command_url('courses'));
  add_submenu_page('shipaa-command','خانه یادگیری','نمای مخاطب','manage_woocommerce',self::learn_url());
 }
 public static function admin_menu_redirect(){ delete_option('shipaa_command_url'); wp_safe_redirect(self::command_url()); exit; }
 public static function admin_menu_page(){ echo '<div class="wrap" dir="rtl"><h1>مرکز فرمان شیپا</h1><p><a class="button button-primary" href="'.esc_url(self::command_url()).'">باز کردن مرکز فرمان</a></p></div>'; }
 public static function admin_menu_css(){ echo '<style>#adminmenu .toplevel_page_shipaa-command .wp-menu-image:before{color:#7fd35a}#adminmenu .toplevel_page_shipaa-command>a{font-weight:700}</style>'; }
 public static function admin_bar($bar){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce'))return;
  $n=self::pending_count();
  $bar->add_node(array('id'=>'shipaa-command','title'=>'<span class="ab-icon dashicons dashicons-welcome-learn-more" style="top:2px"></span>مرکز فرمان شیپا'.($n?' <span style="background:#6c4cbd;color:#fff;border-radius:9px;padding:0 7px;margin-inline-start:4px">'.esc_html(number_format_i18n($n)).'</span>':''),'href'=>self::command_url()));
  $bar->add_node(array('parent'=>'shipaa-command','id'=>'shipaa-command-requests','title'=>'صف تأیید ثبت‌نام‌ها','href'=>self::command_url('requests')));
  $bar->add_node(array('parent'=>'shipaa-command','id'=>'shipaa-command-people','title'=>'مخاطبان','href'=>self::command_url('people')));
  $bar->add_node(array('parent'=>'shipaa-command','id'=>'shipaa-command-courses','title'=>'دوره‌ها','href'=>self::command_url('courses')));
  $bar->add_node(array('parent'=>'shipaa-command','id'=>'shipaa-learning','title'=>'خانه یادگیری (نمای مخاطب)','href'=>self::learn_url()));
 }
 public static function dashboard_widget(){
  if(!current_user_can('manage_woocommerce'))return;
  wp_add_dashboard_widget('shipaa_command_widget','مرکز فرمان شیپا',array(__CLASS__,'dashboard_widget_html'));
 }
 public static function dashboard_widget_html(){
  $n=self::pending_count();
  echo '<div dir="rtl" style="display:grid;gap:10px"><p style="margin:0;font-size:14px">'.($n?'<strong style="color:#6c4cbd">'.esc_html(number_format_i18n($n)).' ثبت‌نام</strong> منتظر بررسی است.':'صف تأیید خالی است ✓').'</p>'
   .'<p style="margin:0;display:flex;gap:8px;flex-wrap:wrap"><a class="button button-primary" href="'.esc_url(self::command_url()).'">ورود به مرکز فرمان</a>'
   .'<a class="button" href="'.esc_url(self::command_url('requests')).'">صف تأیید</a><a class="button" href="'.esc_url(self::command_url('people')).'">مخاطبان</a></p></div>';
 }
 private static function pending_orders(){
  $all=self::orders(array('status'=>array('on-hold','pending'),'limit'=>100));
  return array_values(array_filter($all,array(__CLASS__,'validated_order')));
 }
 private static function request_card($o,$compact=false){
  $names=array();foreach($o->get_items('line_item') as $item)$names[]=$item->get_name();
  $display=$o->get_formatted_billing_full_name();if(!$display){$u=get_userdata($o->get_customer_id());$display=$u?$u->display_name:'—';}
  $fix=$o->get_meta('_shipaa_review_state')==='needs_changes';
  $paid=$o->get_meta('_shipaa_paid_waiting')==='yes'||(bool)$o->get_date_paid();
  $state=$fix?'نیازمند اصلاح':($o->get_status()==='on-hold'?($paid?'پرداخت شد — منتظر تأیید شما':'رسید رسیده — منتظر بررسی'):'منتظر پرداخت');
  $initial=function_exists('mb_substr')?mb_substr($display,0,1):substr($display,0,1);
  $tone=$fix?'lilac':($o->get_status()==='on-hold'?'sky':'amber');
  $via=$o->get_created_via();$src=($via==='shipaa_registration'||$o->get_meta('_shipaa300')==='yes')?'ثبت‌نام شیپا':($via==='admin'?'ثبت در پیشخوان':'فروشگاه سایت');if(!$o->get_customer_id())$src.=' · مهمان';$fixnote=$fix?trim((string)$o->get_meta('_shipaa_review_note')):'';
  ob_start();?><article class="sv-request tone-<?php echo esc_attr($tone);?>" data-order-id="<?php echo esc_attr($o->get_id());?>">
   <span class="sv-req-ava" aria-hidden="true"><?php echo esc_html($initial);?></span>
   <div class="sv-req-main"><span class="sv-status <?php echo $fix?'is-lilac':($o->get_status()==='on-hold'?'is-sky':'is-pending');?>"><?php echo esc_html($state);?></span><h3><?php echo esc_html($display);?> <small>سفارش #<?php echo esc_html($o->get_id());?></small></h3><p><?php echo esc_html(implode('، ',$names));?></p><?php if($fixnote):?><small class="sv-req-note">پیام به مخاطب: «<?php echo esc_html($fixnote);?>»</small><?php endif;?><small class="sv-req-meta"><span class="sv-src"><?php echo esc_html($src);?></span> · <?php echo wp_kses_post($o->get_formatted_order_total());?> · <?php echo $o->get_date_created()?esc_html(human_time_diff($o->get_date_created()->getTimestamp(),time()).' پیش'):'—';?></small></div>
   <div class="sv-controls"><?php if($o->get_customer_id()):?><button type="button" class="sv-button sv-secondary" data-person-id="<?php echo esc_attr($o->get_customer_id());?>" aria-haspopup="dialog"><?php echo self::i('user');?> پرونده</button><?php endif;?><?php if(!$compact):?><button type="button" class="sv-button sv-approve" data-approve="<?php echo esc_attr($o->get_id());?>"><?php echo self::i('check');?> تأیید رسید</button><button type="button" class="sv-button sv-ghost" data-revise="<?php echo esc_attr($o->get_id());?>">نیازمند اصلاح</button><?php endif;?></div>
  </article><?php return ob_get_clean();
 }
 private static function recent_access($n){
  $out=array();
  foreach(self::orders(array('status'=>array('completed','processing'),'limit'=>40)) as $o){
   $c=SHIPAA_Access::course_items($o);if(!$c||!$o->get_customer_id())continue;
   $u=get_userdata($o->get_customer_id());
   $ts=$o->get_date_completed()?$o->get_date_completed()->getTimestamp():($o->get_date_created()?$o->get_date_created()->getTimestamp():time());
   $out[]=array('uid'=>(int)$o->get_customer_id(),'name'=>$u?$u->display_name:'—','course'=>implode('، ',array_map('get_the_title',$c)),'manual'=>$o->get_meta('_shipaa_manual_grant')==='yes','when'=>human_time_diff($ts,time()).' پیش');
   if(count($out)>=$n)break;
  }
  return $out;
 }
 private static function students_by_course(){
  $t=array();
  foreach(self::orders(array('status'=>array('completed','processing'),'limit'=>500)) as $o){$cid=(int)$o->get_customer_id();if(!$cid)continue;foreach(SHIPAA_Access::course_items($o) as $pid)$t[$pid][$cid]=true;}
  return array_map('count',$t);
 }
 private static function overview_admin($waiting){
  $users=count_users();$courses=self::course_ids();
  $total=(int)$users['total_users'];$n=count($waiting);$c=count($courses);
  $onhold=0;foreach($waiting as $o)if($o->get_status()==='on-hold')$onhold++;
  $lessons=0;foreach($courses as $pid)$lessons+=SHIPAA_Studiare::structure($pid)['count'];
  ob_start();?>
  <?php $me=wp_get_current_user();$myname=trim((string)get_user_meta($me->ID,'first_name',true))?:$me->display_name; ?>
  <div class="sv-hero"><i class="sv-hero-orb o1"></i><i class="sv-hero-orb o2"></i><div><span class="sv-eyebrow"><?php echo esc_html(SHIPAA_Learner_V3::greeting().'، '.$myname);?> <span class="sv-date" data-sv-date></span></span><h2>امروز <?php echo $n?esc_html(number_format_i18n($n)).' ثبت‌نام منتظر شماست':'صف تأیید خالی است ✓';?></h2><p>داده‌ها مستقیم از وردپرس، ووکامرس و استادیار خوانده می‌شوند؛ بدون آمار نمایشی.</p></div><?php if($n):?><button type="button" class="sv-button sv-hero-btn" data-tab="requests">بازکردن صف تأیید <?php echo self::i('arrow');?></button><?php endif;?></div>
  <div class="sv-metrics">
   <div class="t-green"><span class="sv-m-ic"><?php echo self::i('user');?></span><strong data-sv-count="<?php echo esc_attr($total);?>"><?php echo esc_html(number_format_i18n($total));?></strong><span>حساب ثبت‌شده</span></div>
   <div class="t-sky"><span class="sv-m-ic"><?php echo self::i('receipt');?></span><strong data-sv-count="<?php echo esc_attr($onhold);?>"><?php echo esc_html(number_format_i18n($onhold));?></strong><span>رسید منتظر بررسی</span></div>
   <div class="t-lilac"><span class="sv-m-ic"><?php echo self::i('clock');?></span><strong data-sv-count="<?php echo esc_attr($n-$onhold);?>"><?php echo esc_html(number_format_i18n($n-$onhold));?></strong><span>منتظر پرداخت</span></div>
   <div class="t-green"><span class="sv-m-ic"><?php echo self::i('book');?></span><strong data-sv-count="<?php echo esc_attr($c);?>"><?php echo esc_html(number_format_i18n($c));?></strong><span>دوره · <?php echo esc_html(number_format_i18n($lessons));?> جلسه</span></div>
  </div>
  <div class="sv-sec-head"><h2>تازه‌ترین درخواست‌ها</h2><?php if($n>3):?><button type="button" class="sv-link" data-tab="requests">همه <?php echo esc_html(number_format_i18n($n));?> مورد <?php echo self::i('arrow');?></button><?php endif;?></div>
  <div class="sv-list" data-sv-preview><?php if(!$waiting):?><div class="sv-empty"><?php echo self::i('check');?><strong>همه ثبت‌نام‌ها بررسی شده‌اند.</strong><span>درخواست جدید که برسد، همین‌جا دیده می‌شود.</span></div><?php endif; foreach(array_slice($waiting,0,3) as $o)echo self::request_card($o);?></div>
  <?php $recent=self::recent_access(6); ?>
  <div class="sv-sec-head"><h2>آخرین دوره‌های باز شده</h2><span class="sv-count-chip">بر اساس سفارش‌های تکمیل‌شده</span></div>
  <div class="sv-activity"><?php if(!$recent):?><div class="sv-empty"><strong>هنوز دوره‌ای باز نشده است.</strong></div><?php endif; foreach($recent as $r):?>
   <div class="sv-act"><span class="sv-act-dot <?php echo $r['manual']?'is-lilac':'is-green';?>"><?php echo self::i($r['manual']?'spark':'check');?></span><div><strong><?php echo esc_html($r['name']);?></strong><small><?php echo esc_html($r['course']);?></small></div><span class="sv-act-tag"><?php echo $r['manual']?'دسترسی دستی':'تأیید رسید';?></span><time><?php echo esc_html($r['when']);?></time><button type="button" class="sv-link" data-person-id="<?php echo esc_attr($r['uid']);?>">پرونده</button></div>
  <?php endforeach;?></div>
  <div class="sv-quick"><button type="button" data-tab="people"><?php echo self::i('search');?><strong>جست‌وجوی مخاطب</strong><small>نام، ایمیل یا موبایل</small></button><button type="button" data-tab="courses"><?php echo self::i('book');?><strong>دوره‌ها و جلسه‌ها</strong><small>اتصال استادیار</small></button><a href="<?php echo esc_url(SHIPAA_Learner_V3::SUPPORT);?>" target="_blank" rel="noopener"><?php echo self::i('chat');?><strong>پشتیبانی ایتا</strong><small>رسیدها و گفت‌وگوها</small></a></div>
  <?php return ob_get_clean();
 }
 private static function pending_html($orders){
  ob_start();?><div class="sv-sec-head"><div><h2 class="sv-heading">صف تأیید ثبت‌نام‌ها</h2><p class="sv-intro">همه سفارش‌های دوره (کارت‌به‌کارت، درگاه آنلاین، رایگان، صفحه ثبت‌نام شیپا) تا تأیید شما «در انتظار بررسی» می‌مانند. با تأیید، سفارش تکمیل و دسترسی استادیار باز می‌شود.</p></div><div class="sv-head-tools"><?php $gate=SHIPAA_Access::gate_on(); ?><button type="button" class="sv-gate<?php echo $gate?' is-on':'';?>" data-sv-gate aria-pressed="<?php echo $gate?'true':'false';?>"><span class="sv-gate-sw" aria-hidden="true"></span><span data-sv-gate-tx><?php echo $gate?'تأیید دستی ثبت‌نام‌ها: روشن':'تأیید دستی ثبت‌نام‌ها: خاموش';?></span></button><span class="sv-count-chip"><?php echo esc_html(number_format_i18n(count($orders)));?> مورد</span></div></div>
  <div class="sv-filter" role="group" aria-label="فیلتر صف"><button type="button" class="is-on" data-sv-filter="all">همه</button><button type="button" data-sv-filter="is-sky">رسید رسیده</button><button type="button" data-sv-filter="is-pending">منتظر پرداخت</button><button type="button" data-sv-filter="is-lilac">نیازمند اصلاح</button></div>
  <div class="sv-list" id="sv-requests" data-sv-ids="<?php echo esc_attr(implode(',',array_map(function($o){return $o->get_id();},$orders)));?>"><?php echo self::queue_list($orders);?></div><?php return ob_get_clean();
 }
 private static function queue_list($orders){
  ob_start(); if(!$orders):?><div class="sv-empty"><?php echo self::i('check');?><strong>صف تأیید خالی است.</strong><span>سفارش دوره معلقی پیدا نشد.</span></div><?php endif; foreach($orders as $o)echo self::request_card($o); return ob_get_clean();
 }
 /** بررسی زنده صف (هر ۲۰ ثانیه از مرکز فرمان) */
 public static function ajax_queue(){
  self::guard(); delete_transient('shipaa_pending_count'); $orders=self::pending_orders();
  $ids=array_map(function($o){return $o->get_id();},$orders);
  ob_start(); if(!$orders):?><div class="sv-empty"><?php echo self::i('check');?><strong>همه ثبت‌نام‌ها بررسی شده‌اند.</strong><span>درخواست جدید که برسد، همین‌جا دیده می‌شود.</span></div><?php endif; foreach(array_slice($orders,0,3) as $o)echo self::request_card($o); $preview=ob_get_clean();
  wp_send_json_success(array('ids'=>$ids,'count'=>count($ids),'list'=>self::queue_list($orders),'preview'=>$preview));
 }
 private static function people_html(){return SHIPAA_Admin_Dossier_V13::people_html();}
 private static function courses_html(){
  $ids=self::course_ids();$students=self::students_by_course();ob_start();?><div class="sv-sec-head"><div><h2 class="sv-heading">دوره‌ها و اتصال استادیار</h2><p class="sv-intro">تعداد جلسه‌ها از سرفصل‌های استادیار خوانده می‌شود. «پیش‌نمایش پلیر» همان چیزی را نشان می‌دهد که مخاطب می‌بیند.</p></div></div><div class="sv-courses"><?php foreach($ids as $pid){$s=SHIPAA_Studiare::structure($pid);?><article class="sv-course"><div class="sv-course-cover"><?php if($s['image']):?><img src="<?php echo esc_url($s['image']);?>" alt="" loading="lazy"><?php else: echo self::i('leaf'); endif;?></div><div class="sv-course-body"><strong><?php echo esc_html($s['title']);?></strong><small><?php echo esc_html(number_format_i18n(count($s['modules'])));?> بخش · <?php echo esc_html(number_format_i18n($s['count']));?> جلسه · شناسه <?php echo esc_html($pid);?></small><span class="sv-students"><?php echo self::i('user');?> <?php echo esc_html(number_format_i18n($students[$pid]??0));?> مخاطب با دسترسی</span><span class="sv-status <?php echo $s['count']?'is-active':'is-pending';?>"><?php echo $s['count']?'متصل به سرفصل‌ها':'سرفصل خالی';?></span></div><div class="sv-course-actions"><a class="sv-button sv-secondary" href="<?php echo esc_url(home_url('/my-learning/#/learn/'.$pid));?>"><?php echo self::i('play');?> پیش‌نمایش پلیر</a><a class="sv-link" href="<?php echo esc_url(admin_url('admin.php?page=shipaa-session-packs-v2&course='.$pid));?>">بسته‌های یادگیری</a><a class="sv-link" href="<?php echo esc_url(get_edit_post_link($pid)?:get_permalink($pid));?>">ویرایش <?php echo self::i('external');?></a></div></article><?php }?></div><?php if(!$ids):?><div class="sv-empty"><?php echo self::i('book');?><strong>هنوز دوره‌ای با علامت دوره استادیار منتشر نشده است.</strong></div><?php endif; return ob_get_clean();
 }
 public static function admin(){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce'))return '<p dir="rtl">این صفحه فقط برای مدیر مجاز قابل استفاده است.</p>';
  $waiting=self::pending_orders();
  return self::shell('مرکز فرمان شیپا',array('overview'=>self::overview_admin($waiting),'requests'=>self::pending_html($waiting),'people'=>self::people_html(),'courses'=>self::courses_html()),array('requests'=>count($waiting)));
 }
 private static function guard(){
  if(!is_user_logged_in()||!current_user_can('manage_woocommerce'))wp_send_json_error(array('message'=>'دسترسی مجاز نیست.'),403);
  if(!check_ajax_referer('shipaa_v1','nonce',false))wp_send_json_error(array('message'=>'اعتبار صفحه منقضی شده؛ صفحه را دوباره باز کنید.'),403);
 }
 public static function ajax_get(){SHIPAA_Admin_Dossier_V13::ajax_dossier();}
 public static function approve(){
  self::guard();$id=absint($_POST['order_id']??0);$order=function_exists('wc_get_order')?wc_get_order($id):false;
  if(!self::validated_order($order)||!in_array($order->get_status(),array('on-hold','pending'),true))wp_send_json_error(array('message'=>'درخواست برای تأیید معتبر نیست.'),409);
  if((string)($_POST['confirmed']??'')!=='yes')wp_send_json_error(array('message'=>'بررسی رسید باید صریحاً تأیید شود.'),400);
  $order->update_meta_data('_shipaa_approved','yes');$order->update_meta_data('_shipaa_approved_via','shipaa');
  $order->update_meta_data('_shipaa_receipt_approved_by',(int)get_current_user_id());
  $order->update_meta_data('_shipaa_receipt_approved_at',current_time('mysql',true));
  $order->delete_meta_data('_shipaa_review_state');$order->delete_meta_data('_shipaa_review_note');
  $order->save();
  $order->update_status('completed','رسید توسط مدیر شیپا خارج از سایت بررسی و تأیید شد.',true);
  // ثبت دسترسی واقعی و راستی‌آزمایی هم‌زمان (حتی اگر هوک ووکامرس اجرا نشده باشد)
  delete_transient('shipaa_pending_count');
  SHIPAA_Access::on_paid($order->get_id());
  $uid=(int)$order->get_customer_id();$tone='ok';$msgs=array();
  foreach(SHIPAA_Access::course_items($order) as $pid){$t=SHIPAA_Access::verify_text(SHIPAA_Access::verify($uid,$pid));if($t[0]!=='ok')$tone='warn';$msgs[]=get_the_title($pid).': '.$t[1];}
  SHIPAA_Admin_Dossier_V13::log($uid,'approve','تأیید رسید و باز شدن دوره — سفارش #'.$order->get_id());
  wp_send_json_success(array('message'=>'تأیید شد. '.implode(' | ',$msgs),'tone'=>$tone,'status'=>$order->get_status()));
 }
 public static function request_changes(){
  self::guard();$id=absint($_POST['order_id']??0);$order=function_exists('wc_get_order')?wc_get_order($id):false;
  if(!self::validated_order($order)||!in_array($order->get_status(),array('on-hold','pending'),true))wp_send_json_error(array('message'=>'درخواست معتبر نیست.'),409);
  $note=sanitize_textarea_field(wp_unslash($_POST['note']??''));if(mb_strlen($note)<4)wp_send_json_error(array('message'=>'دلیل اصلاح را وارد کنید.'),400);
  $order->update_meta_data('_shipaa_review_state','needs_changes');
  $share=(string)($_POST['share']??'')==='yes';
  if($share)$order->update_meta_data('_shipaa_review_note',$note);else $order->delete_meta_data('_shipaa_review_note');
  $order->update_meta_data('_shipaa_review_at',current_time('mysql',true));$order->save();$order->add_order_note('نیازمند اصلاح / توسط مدیر: '.$note,false);
  wp_send_json_success(array('message'=>$share?'ثبت شد؛ مخاطب «نیاز به اصلاح رسید» و توضیح شما را در صفحه ثبت‌نام‌ها می‌بیند.':'ثبت شد؛ مخاطب «نیاز به اصلاح رسید» را می‌بیند (توضیح فقط برای مدیران است).','status'=>$order->get_status()));
 }
}
SHIPAA_Dashboard_V1::boot();
